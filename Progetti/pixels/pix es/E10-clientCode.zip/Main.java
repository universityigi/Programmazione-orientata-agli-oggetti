
public class Main {

	public static void main(String[] args) {
		
		StatusDownloaderFrame frame = new StatusDownloaderFrame();
		frame.setVisible(true);
		frame.setSize(800, 600);
	}
}
