import java.io.*;

@SuppressWarnings({"unchecked"})
public class ProvaEserc3 extends TemplateProvaEserc {
    public static void main(String[] args) throws IOException {
        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInCoda(1, 1);
            lp.aggiungiInCoda(2, 2);
            lp.aggiungiInCoda(3, 3);
            lp.aggiungiInCoda(4, 4);
            confronta("[T1]", 4, lp.lunghezza());
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInCoda(1, 1);
            lp.aggiungiInCoda(2, 2);
            lp.aggiungiInCoda(3, 3);
            lp.aggiungiInCoda(4, 4);
            NodoPunto best = lp.piuVicino(5, 5);
            confronta("[T2]", true, best.x == 4 && best.y == 4);
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInCoda(1, 1);
            lp.aggiungiInCoda(2, 2);
            lp.aggiungiInCoda(3, 3);
            lp.aggiungiInCoda(4, 4);
            NodoPunto best = lp.piuVicino(4, 4);
            confronta("[T3]", true, best.x == 4 && best.y == 4);
        }
        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInCoda(1, 1);
            lp.aggiungiInCoda(2, 2);
            lp.aggiungiInCoda(3, 3);
            lp.aggiungiInCoda(4, 4);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            lp.print(new PrintStream(out));
            out.flush();
            String s = new String(out.toByteArray());

            confronta("[T4]", "<4.0;4.0><3.0;3.0><2.0;2.0><1.0;1.0>", s);
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            lp.print(new PrintStream(out));
            out.flush();
            String s = new String(out.toByteArray());

            confronta("[T5]", "", s);
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInCoda(1, 1);
            lp.aggiungiInCoda(2, 2);
            lp.aggiungiInCoda(3, 3);
            lp.aggiungiInCoda(4, 4);

            confronta("[T6]", "(1.0,1.0)(2.0,2.0)(3.0,3.0)(4.0,4.0)", toString(lp.init));
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            confronta("[T6/bis]", "", toString(lp.init));
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            confronta("[T7]", "", toString(lp.init));
        }
        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInCoda(1, 1);
            lp.aggiungiInCoda(1, 1);
            confronta("[T8]", "(1.0,1.0)(1.0,1.0)", toString(lp.init));
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInCoda(1, 1);
            lp.aggiungiInCoda(1, 1);
            lp.aggiungiInCoda(1, 1);
            lp.aggiungiInCoda(1, 1);
            lp.aggiungiInCoda(2, 2);
            lp.aggiungiInCoda(2, 2);
            lp.aggiungiInCoda(2, 2);
            lp.aggiungiInCoda(2, 2);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            lp.print(new PrintStream(out));
            out.flush();
            String s = new String(out.toByteArray());

            confronta("[T9]", "<2.0;2.0><2.0;2.0><2.0;2.0><2.0;2.0><1.0;1.0><1.0;1.0><1.0;1.0><1.0;1.0>", s);
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            lp.print(new PrintStream(out));
            out.flush();
            String s = new String(out.toByteArray());

            confronta("[T10]", "", s);
        }

    }

    private static String toString(NodoPunto p) {
        if (p == null) return "";
        return "(" + p.x + "," + p.y + ")" + toString(p.next);
    }
}
