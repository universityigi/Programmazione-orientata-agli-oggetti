import num.impl.*;

import java.io.*;

@SuppressWarnings({"unchecked"})
public class ProvaEserc4 extends TemplateProvaEserc {
    public static void main(String[] args) throws IOException {
        //=========================================================================================
        {
            verificaClasse("[T1]", "num.impl.Frazione");
            verificaClasse("[T2]", "num.impl.Intero");
            verificaClasse("[T3]", "num.impl.Operazione");
            verificaClasse("[T5]", "num.Numero");
        }

        //=========================================================================================
        {
            Intero i = new Intero(6);
            confronta("[T6]", 6, i.valore());
        }

        //=========================================================================================
        {
            Intero i = new Intero(6);
            confronta("[T7]", 6, i.getValore());
        }

        //=========================================================================================
        {
            Intero i = new Intero(60);
            confronta("[T8]", "60", i.toString());
        }

        //=========================================================================================
        {
            Frazione i = new Frazione(4, 10);
            confronta("[T9]", "4/10", i.toString());
        }

        //=========================================================================================
        {
            Frazione i = new Frazione(4, 10);
            confronta("[T10]", 0.4, i.valore(), 2);
        }

        //=========================================================================================
        {
            Frazione f1 = new Frazione(10, 10);
            Frazione inv = new Frazione(10, 10);
            Frazione i = f1.inversa();
            confronta("[T11]", i.toString(), inv.toString());
        }

        //=========================================================================================
        {
            Frazione f1 = new Frazione(18, 10);
            Frazione inv = new Frazione(10, 18);
            Frazione i = f1.inversa();
            confronta("[T12]", i.toString(), inv.toString());
        }

        //=========================================================================================
        {
            Operazione i = new Operazione(new Intero(4), new Intero(6), '+');
            confronta("[T13/1]", 10, i.valore());
        }

        //=========================================================================================
        {
            Operazione i = new Operazione(new Intero(4), new Intero(6), '+');
            confronta("[T13/2]", "(4+6)", i.toString());
        }

        //=========================================================================================
        {
            Operazione i =
                    new Operazione(
                            new Operazione(new Intero(4), new Operazione(new Intero(4), new Frazione(12, 6), '+'), '*'),
                            new Intero(6),
                            '+');

            confronta("[T14/1]", "((4*(4+12/6))+6)", i.toString());
        }

        //=========================================================================================
        {
            Operazione i =
                    new Operazione(
                            new Operazione(new Intero(4), new Operazione(new Intero(4), new Frazione(12, 6), '+'), '*'),
                            new Intero(6),
                            '+');

            confronta("[T14/2]", 30., i.valore());
        }

        //=========================================================================================
        {
            Operazione i = new Operazione(new Frazione(5, 10), new Frazione(10, 20), '/');

            confronta("[T15/1]", "(5/10/10/20)", i.toString());
            confronta("[T15/2]", 1, i.valore());
        }

    }

}
