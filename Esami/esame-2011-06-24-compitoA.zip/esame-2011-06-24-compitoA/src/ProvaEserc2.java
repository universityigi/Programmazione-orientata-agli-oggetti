import java.util.*;

public class ProvaEserc2  extends TemplateProvaEserc {

    public static void main(String[] args) {

        //TEST
        {
            String test = "PAperino";
            String ris = Eserc2.invertiMaiuscoloMinuscolo(test);
            confronta("(T1)", "paPERINO", ris);
        }

        //TEST
        {
            String test = "hello word";
            String ris = Eserc2.invertiMaiuscoloMinuscolo(test);
            confronta("(T2)", "HELLO WORD", ris);
        }

        //TEST
        {
            String test = "123 stella";
            String ris = Eserc2.invertiMaiuscoloMinuscolo(test);
            confronta("(T3)", "123 STELLA", ris);
        }

        //TEST
        {
            String test = "aBcDeFgHiLmNoPqRsTuVz";
            String ris = Eserc2.invertiMaiuscoloMinuscolo(test);
            confronta("(T4)", "AbCdEfGhIlMnOpQrStUvZ", ris);
        }

        //TEST
        {
            String test = "";
            String ris = Eserc2.invertiMaiuscoloMinuscolo(test);
            confronta("(T5)", "", ris);
        }

        //TEST
        {
            String test = "1234567890";
            String ris = Eserc2.invertiMaiuscoloMinuscolo(test);
            confronta("(T6)", "1234567890", ris);
        }

        //TEST
        {
            String test = "� una bella giornata, per� c'� l'esame.";
            String ris = Eserc2.invertiMaiuscoloMinuscolo(test);
            confronta("(T7)", "� UNA BELLA GIORNATA, PER� C'� L'ESAME.", ris);
        }

        //TEST
        {
            String test = "� UNA BELLA GIORNATA, PER� C'� L'ESAME.";
            String ris = Eserc2.invertiMaiuscoloMinuscolo(test);
            confronta("(T8)", "� una bella giornata, per� c'� l'esame.", ris);
        }

        //TEST
        {
            String test = "� UNA BELLA GIORNATA, PER� C'� L'ESAME.";
            String ris = Eserc2.invertiMaiuscoloMinuscolo(test);
            confronta("(T9)", "� una bella giornata, per� c'� l'esame.", ris);
        }

        //TEST
        {
            String[] test = new String[]{"A", "aB", "bCD", "eF", "aBcD"};
            String[] risAtteso = new String[]{"a", "Ab", "Bcd", "Ef", "AbCd"};
            String[] ris = Eserc2.invertiMaiuscoloMinuscoloArray(test.clone());
            confronta("(T10)", Arrays.toString(risAtteso), Arrays.toString(ris));
        }

        //TEST
        {
            String[] test = new String[]{};
            String[] risAtteso = new String[]{};
            String[] ris = Eserc2.invertiMaiuscoloMinuscoloArray(test.clone());
            confronta("(T11)", Arrays.toString(risAtteso), Arrays.toString(ris));
        }

        //TEST
        {
            String[] test = new String[]{""};
            String[] risAtteso = new String[]{""};
            String[] ris = Eserc2.invertiMaiuscoloMinuscoloArray(test.clone());
            confronta("(T12)", Arrays.toString(risAtteso), Arrays.toString(ris));
        }

        //TEST
        {
            String[] test = new String[]{"pippo", "PLUTO", "paperino", "Qui", "qUO", "qUa"};
            String[] risAtteso = new String[]{"PIPPO", "pluto", "PAPERINO", "qUI", "Quo", "QuA"};
            String[] ris = Eserc2.invertiMaiuscoloMinuscoloArray(test.clone());
            confronta("(T13)", Arrays.toString(risAtteso), Arrays.toString(ris));
        }

    }
}
