public class ProvaEserc1 extends TemplateProvaEserc {

    public static void main(String[] args) {
        verificaClasse("[T0]", "matrici.Eserc1");

        //TEST
        {
            int[][] A1 = {
                    {1, 2, 3, 4, 5},
                    {5, 1, 2, 3, 4},
                    {4, 5, 1, 2, 3},
                    {3, 4, 5, 1, 2},
                    {2, 3, 4, 5, 1}
            };
            int[][] A1_zero = {
                    {0, 2, 3, 4, 5},
                    {5, 0, 2, 3, 4},
                    {4, 5, 0, 2, 3},
                    {3, 4, 5, 0, 2},
                    {2, 3, 4, 5, 0}
            };

            int azzera = matrici.Eserc1.azzera(A1, new int[]{1, 9});
            confronta("[T1]", A1_zero, A1);
            confronta("[T2]:", 5, azzera);
        }

        //TEST 2
        {
            int[][] A2 = {
                    {1, 2, 3, 4, 5},
                    {5, 1, 2, 3, 4},
                    {4, 5, 1, 2, 3},
                    {3, 4, 5, 1, 2},
                    {2, 3, 4, 5, 1}
            };
            int[][] A2_zero = {
                    {0, 2, 3, 4, 0},
                    {0, 0, 2, 3, 4},
                    {4, 0, 0, 2, 3},
                    {3, 4, 0, 0, 2},
                    {2, 3, 4, 0, 0}
            };

            int azzera = matrici.Eserc1.azzera(A2, new int[]{1, 1, 1, 1, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, -1000, 5});
            confronta("[T3]", A2_zero, A2);
            confronta("[T4]", 10, azzera);
        }

        //TEST 3
        {
            int[][] A3 = {
                    {1, 2, 3, 4, 5},
            };
            int[][] A3_zero = {
                    {1, 2, 3, 4, 5}
            };

            int azzera = matrici.Eserc1.azzera(A3, new int[]{});
            confronta("[T5]", A3_zero, A3);
            confronta("[T6]", 0, azzera);
        }

        //TEST
        {
            int[][] A4 = {
                    {1, 2, 3, 4, 5, 6},
                    {6},
                    {5, 6, 1, 2}
            };
            int[][] A4_zero = {
                    {0, 2, 3, 4, 5, 0},
                    {0},
                    {5, 0, 0, 2}
            };

            int azzera = matrici.Eserc1.azzera(A4, new int[]{1, 6, 10});
            confronta("[T7]", A4_zero, A4);
            confronta("[T8]", 5, azzera);

        }

        //TEST
        {
            try {
                matrici.Eserc1.azzera(new int[0][5], new int[]{1, 6, 10});
                fail("[T9]", "Eccezione non rilanciata");
            } catch (matrici.eccezione.EccezioneMatrice e) {
                confronta("[T9-catch]", "Dimensioni non valide", e.getMessage());
            }

        }
        //TEST
        {
            try {
                matrici.Eserc1.azzera(new int[][]{{1, 2, 3}, {4, 5, 6}, {}}, new int[]{1, 2, 3});
                fail("[T10]", "Eccezione non rilanciata");
            } catch (matrici.eccezione.EccezioneMatrice e) {
                confronta("[T10-catch]", "Dimensioni non valide", e.getMessage());
            }

        }
    }

}
