import java.util.*;

public class ProvaEserc3 extends TemplateProvaEserc {

    static String _toString(NodoPersona n) {
        StringBuilder sb = new StringBuilder();
        while (n != null) {
            if (sb.length() > 0) {
                sb.append(",");
            }
            sb.append(n.nome).append(" ").append(n.cognome);
            n = n.next;
        }
        return "[" + sb + "]";
    }

    public static void main(String[] args) {
        ListaPersone lista1 = new ListaPersone();
        ListaPersone lista2 = new ListaPersone();

        confronta("(T1)", "[]", Arrays.toString(lista1.elencaNomi()));

        lista1.aggiungiInCoda("mario", "rossi");
        confronta("(T2)", lista1.init, "[mario rossi]");

        //TEST

        confronta("(T3)", "[mario]", Arrays.toString(lista1.elencaNomi()));

        //TEST

        lista1.aggiungiInCoda("franco", "nero");
        confronta("(T4)", lista1.init, "[mario rossi,franco nero]");

        //TEST

        lista1.aggiungiInCoda("armando", "verdi");
        confronta("(T5)", lista1.init, "[mario rossi,franco nero,armando verdi]");

        //TEST

        lista1.aggiungiInCoda("giulio", "verdi");
        confronta("(T6)", lista1.init,
                "[mario rossi,franco nero,armando verdi,giulio verdi]");

        //TEST

        lista1.aggiungiInCoda("ernesto", "verdi");
        confronta("(T7)", lista1.init,
                "[mario rossi,franco nero,armando verdi,giulio verdi,ernesto verdi]");

        //TEST

        confronta("(T8)", "[mario, franco, armando, giulio, ernesto]", Arrays.toString(lista1.elencaNomi())
                 );

        //TEST

        lista1.aggiungiInCoda("ernesto", "bianchi");
        confronta("(T9)", lista1.init,
                "[mario rossi,franco nero,armando verdi,giulio verdi,ernesto verdi,ernesto bianchi]");

        //TEST

        confronta("(T10)", "[mario, franco, armando, giulio, ernesto, ernesto]", Arrays.toString(lista1.elencaNomi())
                 );

        //TEST

        confronta("(T11)", 3, lista1.trova("verdi"));

        //TEST

        confronta("(T12)", 0, lista1.trova("gialli"));

        //TEST

        confronta("(T13)", 0, lista1.trova(""));

        //TEST

        confronta("(T14)", 0, lista1.trova("mario"));

        //TEST

        confronta("(T15)", 1, lista1.trova("nero"));

        //TEST

        confronta("(T16)", 0, lista1.trova("ernesto"));

        //TEST

        confronta("(T17)", 0, lista2.trova("verdi"));

        //TEST

        confronta("(T18)", "[]", Arrays.toString(lista2.elencaNomi()));

    }

    static void confronta(String msg, NodoPersona n1, String n2) {
        confronta(msg, n2, _toString(n1));
    }

}
