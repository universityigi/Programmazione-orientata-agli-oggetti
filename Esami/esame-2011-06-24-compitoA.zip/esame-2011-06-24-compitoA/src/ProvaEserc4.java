import java.util.*;

public class ProvaEserc4 extends TemplateProvaEserc {

    public static void main(String[] args) {
        StradaUrbana via_merulana = new StradaUrbana("via merulana", 1.5, 1, "Roma");
        StradaUrbana via_labicana = new StradaUrbana("via labicana", 0.5, 1, "Roma");
        StradaUrbana via_marsala = new StradaUrbana("via marsala", 2, 1, "Roma");
        StradaUrbana via_roma = new StradaUrbana("via roma", 4.5, 1, "Colleferro");

        StradaExtraurbana via_casilina = new StradaExtraurbana("via casilina", 250, 1);
        via_casilina.aggiungiCitta("La Borghesiana");
        via_casilina.aggiungiCitta("Roma");
        via_casilina.aggiungiCitta("Finocchio");
        via_casilina.aggiungiCitta("Valmontone");
        via_casilina.aggiungiCitta("Colleferro");
        via_casilina.aggiungiCitta("Anagni");
        via_casilina.aggiungiCitta("Frosinone");
        via_casilina.aggiungiCitta("Cassino");
        via_casilina.aggiungiCitta("Napoli");

        StradaExtraurbana via_appia = new StradaExtraurbana("via appia", 220, 2);
        via_appia.aggiungiCitta("Roma");
        via_appia.aggiungiCitta("Cisterna");
        via_appia.aggiungiCitta("Latina");
        via_appia.aggiungiCitta("Terracina");


        confronta("(T1)", true, via_casilina instanceof Strada);
        confronta("(T2)", true, via_merulana instanceof Strada);

        confronta("(T3)", "EXTRAURBANA via casilina - 1 - 250.0 Km - 90.0 Km/h", via_casilina.toString());
        confronta("(T4)", "EXTRAURBANA via appia - 2 - 220.0 Km - 90.0 Km/h", via_appia.toString());
        confronta("(T5)", "EXTRAURBANA via casilina - 1 - 250.0 Km - 90.0 Km/h", via_casilina.toString());

        confronta("(T6)", 50, via_marsala.getVelocitaMaxKmH());
        confronta("(T7)", 90, via_appia.getVelocitaMaxKmH());

        confronta("(T8)", "Roma", via_marsala.citta());
        confronta("(T9)", new String[]{"La Borghesiana", "Roma", "Finocchio", "Valmontone", "Colleferro", "Anagni","Frosinone","Cassino","Napoli"}, via_casilina.cittaAttraversate());
        confronta("(T10)", 90, via_appia.getVelocitaMaxKmH());

        {
            List<Strada> vie = new ArrayList<Strada>();
            vie.add(via_roma);
            vie.add(via_labicana);
            vie.add(via_marsala);
            confronta("(T11)", new String[]{"Colleferro", "Roma", "Roma",}, UtilitaStrade.elencoCitta(vie));
        }

        {
            List<Strada> vie = new ArrayList<Strada>();
            vie.add(via_roma);
            vie.add(via_labicana);
            vie.add(via_marsala);
            vie.add(via_casilina);
            confronta("(T12)", new String[]{"Colleferro", "Roma", "Roma", "La Borghesiana", "Roma", "Finocchio", "Valmontone", "Colleferro",
                    "Anagni","Frosinone","Cassino","Napoli"}, UtilitaStrade.elencoCitta(vie)
                     );
        }

        {
            List<Strada> vie = new ArrayList<Strada>();
            vie.add(via_roma);
            vie.add(via_labicana);
            vie.add(via_marsala);
            vie.add(via_casilina);
            confronta("(T13)", 257, UtilitaStrade.lunghezzaTotale(vie));
        }

        {
            List<Strada> vie = new ArrayList<Strada>();
            vie.add(via_roma);
            vie.add(via_labicana);
            vie.add(via_marsala);
            vie.add(via_merulana);
            vie.add(via_casilina);
            vie.add(via_appia);
            vie.add(via_casilina);
            confronta("(T14)", 728.5, UtilitaStrade.lunghezzaTotale(vie));
        }

    }

}
