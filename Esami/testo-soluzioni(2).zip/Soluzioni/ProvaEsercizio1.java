public class ProvaEsercizio1 extends TemplateProvaEserc{
    
    public static void main (String[] args){     
        String [][] matrix1= {
            {"a", "aaaaaa", "aaaaaa"},
            {"b", "bbbbbb", "bbbbbb"}
        };
        
        String [][] matrix2= {
            {"9"},
            {"0"},
            {"33"}
        };
        
        String [][] matrix3= {
            {"aaaaaa", "cccccc", "bb"},
            {"bbbbbb", "ccccc", "a"}
        };
        
        String [][] matrix4= {};
              
        int res1=Esercizio1.colonnaConMinorNumeroStringheMaggiori5(matrix1);
        int res2=Esercizio1.colonnaConMinorNumeroStringheMaggiori5(matrix2);
        int res3=Esercizio1.colonnaConMinorNumeroStringheMaggiori5(matrix3);
        int res4=Esercizio1.colonnaConMinorNumeroStringheMaggiori5(matrix4);
               
        int testCounter =1;
                    
        confronta("T"+testCounter, 0, res1);
        testCounter++;
        confronta("T"+testCounter, 0, res2);
        testCounter++;
        confronta("T"+testCounter, 2, res3);
        testCounter++;
        confronta("T"+testCounter, -1, res4);
        testCounter++;        
    }    
}
