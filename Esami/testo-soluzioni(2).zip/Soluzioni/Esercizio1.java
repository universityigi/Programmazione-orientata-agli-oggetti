public class Esercizio1 {   
    public static int colonnaConMinorNumeroStringheMaggiori5(String [][] matrix){
        int min=matrix.length;
        int minI=-1;
        if(matrix.length>0){
            int[] temp=new int[matrix[0].length];
            for(int j=0; j<matrix[0].length; j++){
                int somma=0;
                for(int i=0; i<matrix.length; i++){
                    if(matrix[i][j].length()>5)
                        somma++;
                }
                if(somma<=min){
                    min=somma;
                    minI=j;
                }
            }
        }
        return minI;
    }   
}
