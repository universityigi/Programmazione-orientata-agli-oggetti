public class NodoPersona{
    public String nome;
    public String cognome;
    public NodoPersona next;
}