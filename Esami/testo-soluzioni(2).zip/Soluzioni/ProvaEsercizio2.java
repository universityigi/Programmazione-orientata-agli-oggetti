public class ProvaEsercizio2 extends TemplateProvaEserc{
    
    public static void main (String[] args){
        checkRicorsione("[Ammissibilita\' soluzione]", "Esercizio2.java");
        int testCounter=1;
        String parola="ciao";
        confronta("T"+testCounter, "miao", Esercizio2.rimpiazzaCarattere(parola, 'c', 'm'));
        testCounter++;
        parola="sasso";
        confronta("T"+testCounter, "sassi", Esercizio2.rimpiazzaCarattere(parola, 'o', 'i'));
        testCounter++;
        parola="AAA";
        confronta("T"+testCounter, "aaa", Esercizio2.rimpiazzaCarattere(parola, 'A', 'a'));
        testCounter++;
        parola="B";
        confronta("T"+testCounter, "C", Esercizio2.rimpiazzaCarattere(parola, 'B', 'C'));
        testCounter++;
        parola="";
        confronta("T"+testCounter, "", Esercizio2.rimpiazzaCarattere(parola, 'o', 'i'));
        testCounter++;
    }    
}
