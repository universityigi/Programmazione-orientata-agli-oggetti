public class ListaPersone {
   public NodoPersona init; 
   public ListaPersone(){
        this.init=null;
    }
   public void aggiungiInCoda(String nome, String cognome){
       if (this.init==null){
           this.init=new NodoPersona();
           this.init.nome=nome;
           this.init.cognome=cognome;
           this.init.next=null;
       }
       else{
           NodoPersona l=this.init;
           while (l.next!=null)
              l=l.next;
           l.next= new NodoPersona();
           l.next.nome=nome;
           l.next.cognome=cognome;
           l.next.next=null;          
           }
   }
   
   public int trova(String c){
       int i=0;
       NodoPersona l=this.init;
       while (l!=null){
           if (l.cognome.equals(c))
               i++;
           l=l.next;          
       }
       return i;
   }
   public String[] elencaNomi(){
       int i=0;
       NodoPersona l=this.init;
       while (l!=null){
           i++;
           l=l.next;          
       }
       String[] lis=new String[i];
       l=this.init;
       for (i=0;i<lis.length;i++) {
           lis[lis.length-1-i]=l.nome;
           l=l.next;
       }
       return lis;
   }
    
}
