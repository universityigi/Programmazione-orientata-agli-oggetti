public class Eserc3 {

    //definire qui i metodi pubblici:

    public static boolean eVocale (char c) {
	    return (c=='a' || c=='e'|| c=='i'|| c=='o'|| c=='u');
    }


    //definire qui gli eventuali metodi privati:

    private static int contaVocali (String s, int pos) {
        if (pos==s.length()) return 0;
        if (eVocale(s.charAt(pos)))
		   return 1+contaVocali(s,pos+1);
		else   
		   return 0+contaVocali(s,pos+1);
    }


    public static boolean  ugualiVocaliConsonanti(String s)	{
	    if (s.length()%2==1)
		  return false;
	    int vocali=contaVocali(s,0);
        return vocali==s.length()/2;      
    }
}
