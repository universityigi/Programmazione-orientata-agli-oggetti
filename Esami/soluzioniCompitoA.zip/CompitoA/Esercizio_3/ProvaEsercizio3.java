
import java.io.*;

public class ProvaEsercizio3 extends TemplateProvaEserc {
public static void main(String[] args)  {
        checkRicorsione("ricorsione", "Eserc3.java");
        confronta("[T1]", false, Eserc3.ugualiVocaliConsonanti("cassa"));
		confronta("[T2]", false, Eserc3.ugualiVocaliConsonanti("cart"));
		confronta("[T3]", true, Eserc3.ugualiVocaliConsonanti("casa"));
}
   
}
