import java.io.*;
public class ProvaEsercizio1 extends TemplateProvaEserc {

    public static void main(String[] args) throws IOException {
	        Seminario s1 = new Seminario("SalaA", "2 maggio 2012");
		    Seminario s2 = new Seminario("SalaB", "3 maggio 2012", "L'arte di programmare in Java", "Prof. Beans");
                
                s1.aggiungiPartecipanti("prova_seminario.txt");
                              
				confronta("[T1]", "L'arte di programmare in Java", s2.getArgomento());
				
				confronta("[T2]", "Prof. Beans", s2.getRelatore());
				
				
				
				confronta("[T3]", 3, s1.getNumeroPartecipanti());
                
				confronta("[T4]", "Mario Rossi,Luigi Verdi,Nicola Bianchi", s1.getPartecipanti());
                
				confronta("[T5]", true, s1.setArgomento("Seminario di oggi"));
                
                confronta("[T6]", "Seminario di oggi", s1.getArgomento());
                
                confronta("[T7]", false, s1.aggiungiPartecipante("Mario Rossi"));
				
				confronta("[T8]", 3, s1.getNumeroPartecipanti());
                
                confronta("[T9]", true, s1.aggiungiPartecipante("Zio Paperone"));
				
				confronta("[T10]", 4, s1.getNumeroPartecipanti());
                
                confronta("[T11]", "Mario Rossi,Luigi Verdi,Nicola Bianchi,Zio Paperone", s1.getPartecipanti());
                
                confronta("[T12]", false, s1.cancellaPartecipante("Zio Paperino"));
				
			    confronta("[T13]", 4, s1.getNumeroPartecipanti());
                
                confronta("[T14]", true, s1.cancellaPartecipante("Luigi Verdi"));
				
				confronta("[T15]", 3, s1.getNumeroPartecipanti());
                
                confronta("[T16]", "Mario Rossi,Nicola Bianchi,Zio Paperone", s1.getPartecipanti());
    }
}
