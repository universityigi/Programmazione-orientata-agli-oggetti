import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class Seminario {

    private String[] partecipanti;
    private String argomento;
	private String relatore;
    private String sala;
    private String data;
    
    //definire qui i metodi pubblici della classe:

    public Seminario (String sala, String data) {
		this.partecipanti = new String[0];
        this.sala = sala;
        this.data = data;
        this.argomento=null;
		this.relatore=null;
    }
    
   public Seminario (String sala, String data, String argomento, String relatore) {
	   	this.partecipanti = new String[0];
        this.sala = sala;
        this.data = data;
        this.argomento=argomento;
		this.relatore=relatore;
    }
   
   public void aggiungiPartecipanti (String nomeFileInput) throws IOException {
        FileInputStream f = new FileInputStream (nomeFileInput);
        InputStreamReader in = new InputStreamReader(f);
        BufferedReader br = new BufferedReader(in);
        String line = br.readLine();
        while (line!=null){
			aggiungiPartecipante(line);
			line = br.readLine();
        }
        br.close();
        in.close();
        f.close();        
    }
    
   public boolean aggiungiPartecipante(String partecipante) {
       if(esiste(partecipante))
           return false;
       String []nuovalista = new String[partecipanti.length+1];
       for(int i=0;i<partecipanti.length;i++)
           nuovalista[i] = partecipanti[i];
       nuovalista[nuovalista.length-1]=partecipante;
       partecipanti=nuovalista;
       return true;
   }   

  public boolean cancellaPartecipante(String partecipante) { // cancella un partecipante, controllando che gi� non sia stato inserito. Si assuma che non esistano due partecipanti con lo stesso nome e cognome
      for(int i=0;i<partecipanti.length;i++)
          if(partecipanti[i].equals(partecipante)){
              partecipanti[i]="";
              return true;
          }
      return false;
  
  }
  public int getNumeroPartecipanti() { // restituisce un intero contenente il numero dei partecipanti
     int numero=0;
	 for(int i=0;i<partecipanti.length;i++)
          if(partecipanti[i].length()>0)
              numero++;
	 return numero;
     }
  public String getArgomento() { // restituisce l'argomento del Seminario
     return this.argomento;
     }
  public String getRelatore() { // restituisce il relatore del Seminario
     return this.relatore;
     }	 
  
  public String getPartecipanti() { // restituisce una stringa contenente tutti i partecipanti concatenati tra di loro e separati da virgole nel formato <nome><spazio><cognome><,><nome><spazio><cognome><,>...
        String lista=this.partecipanti[0];
        for (int i=1;i<partecipanti.length; i++)
		    if (partecipanti[i]!="")
            lista=lista+","+partecipanti[i];
        return lista;
    }
 public boolean setArgomento(String argomento){ // inserisce l'argomento del Seminario. Se l'argomento gi� esiste NON lo modifica e restituisce false; se l'argomento non esiste lo aggiunge  e restituisce true.
        if (this.argomento!=null)
            return false;
        else{
            this.argomento=argomento;
            return true;
        }           
    }
    
public boolean getPartecipante(String partecipante) { // restituisce true se il partecipante � iscritto alla Seminario
  return true;
} 

public boolean esiste(String partecipante){
     for (int i=0;i<partecipanti.length; i++)
        if(partecipanti[i].equals(partecipante))
                return true;
    return false;

    }
}
