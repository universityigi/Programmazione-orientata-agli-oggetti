public class Matrice {

   private static boolean nordSud(int[][] mat, int i, int j){
       
       return mat[i][j]==mat[i-1][j]+mat[i+1][j];
   }

    public static int contaRigheNordSud(int[][] mat) {
        int righeNS = 0;
        int elemNS;
        for (int i=1; i<mat.length-1; i++) {
            elemNS=0;
            for (int j=0; j<mat[0].length; j++) {           
                if(nordSud(mat,i,j))
                    elemNS++;
            }
            if (elemNS>1)
                righeNS++;
        }
        return righeNS;
    }
}
