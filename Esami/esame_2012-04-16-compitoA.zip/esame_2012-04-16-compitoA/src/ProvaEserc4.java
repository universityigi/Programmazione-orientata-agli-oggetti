import pista.*;
import pista.impl.*;
import pista.util.*;

import java.io.*;
import java.util.*;

@SuppressWarnings({"unchecked"})
public class ProvaEserc4 extends TemplateProvaEserc {

    public static void main(String[] args) throws IOException {
        //=========================================================================================
        {
            verificaClasse("[T1]", "pista.util.Utility");
        }

        //=========================================================================================
        {
            verificaClasse("[T2]", "pista.Segmento");
        }

        //=========================================================================================
        {
            verificaClasse("[T3]", "pista.impl.SegmentoCurvilineo");
        }

        //=========================================================================================
        {
            verificaClasse("[T5]", "pista.impl.SegmentoRettilineo");
        }


        //=========================================================================================
        {

            SegmentoRettilineo r = new SegmentoRettilineo(100);
            confronta("[T6]", 100, r.lunghezza(), 2);
        }

        //=========================================================================================
        {

            SegmentoRettilineo r = new SegmentoRettilineo(1);
            confronta("[T7]", 1, r.lunghezza(), 2);
        }


        //=========================================================================================
        {

            SegmentoRettilineo r1 = new SegmentoRettilineo(50);
            SegmentoRettilineo r2 = new SegmentoRettilineo(5);
            SegmentoRettilineo r3 = new SegmentoRettilineo(5);
            SegmentoRettilineo r4 = new SegmentoRettilineo(10);
            SegmentoRettilineo r5 = new SegmentoRettilineo(10);
            SegmentoRettilineo r6 = new SegmentoRettilineo(10);
            SegmentoRettilineo r7 = new SegmentoRettilineo(10);
            confronta("[T8]", 100, Utility.lunghezza(asList((Segmento) r1, r2, r3, r4, r5, r6, r7)), 2);
        }


        //=========================================================================================
        {

            SegmentoCurvilineo r = new SegmentoCurvilineo(4);
            confronta("[T9]", 6.28, r.lunghezza(), 2);
        }

        //=========================================================================================
        {

            SegmentoCurvilineo r = new SegmentoCurvilineo(2);
            confronta("[T10]", 3.14, r.lunghezza(), 2);
        }

        //=========================================================================================
        {

            SegmentoRettilineo r1 = new SegmentoRettilineo(50);
            SegmentoCurvilineo r2 = new SegmentoCurvilineo(5);
            SegmentoRettilineo r3 = new SegmentoRettilineo(5);
            SegmentoRettilineo r4 = new SegmentoRettilineo(10);
            SegmentoCurvilineo r5 = new SegmentoCurvilineo(10);
            SegmentoRettilineo r6 = new SegmentoRettilineo(10);
            SegmentoRettilineo r7 = new SegmentoRettilineo(10);
            confronta("[T11]", 108.56, Utility.lunghezza(asList((Segmento) r1, r2, r3, r4, r5, r6, r7)), 2);
        }


        //=========================================================================================
        {
            SegmentoRettilineo r1 = new SegmentoRettilineo(50);
            SegmentoCurvilineo r2 = new SegmentoCurvilineo(5);
            SegmentoRettilineo r3 = new SegmentoRettilineo(5);
            SegmentoRettilineo r4 = new SegmentoRettilineo(10);
            SegmentoCurvilineo r5 = new SegmentoCurvilineo(10);
            SegmentoRettilineo r6 = new SegmentoRettilineo(10);
            SegmentoRettilineo r7 = new SegmentoRettilineo(10);
            confronta("[T12]", 2, Utility.curve(asList((Segmento) r1, r2, r3, r4, r5, r6, r7)));
        }


        //=========================================================================================
        {
            List<Segmento> l = new ArrayList<Segmento>();
            for (int i = 0; i < 20; i++) {
                l.add(new SegmentoRettilineo(i * 10));
                l.add(new SegmentoCurvilineo(i * 10));
                l.add(new SegmentoRettilineo(i * 10));
            }

            confronta("[T13]", 20, Utility.curve(l));
        }


        //=========================================================================================
        {
            List<Segmento> l = new ArrayList<Segmento>();
            for (int i = 0; i < 20; i++) {
                l.add(new SegmentoRettilineo(i * 10));
                l.add(new SegmentoCurvilineo(i * 10));
                l.add(new SegmentoRettilineo(i * 10));
            }

            confronta("[T13]", 6784.51, Utility.lunghezza(l), 2);
        }


    }

}
