@SuppressWarnings({"unchecked"})
public class ProvaEserc1 extends TemplateProvaEserc {
    public static void main(String[] args) {
        //=========================================================================================
        {
            try {
                confronta("[T1]", new int[]{2}, Eserc1.selezionaColonna(new int[][]{{1, 2, 3, 4, 5}}, 1));
            } catch (InvalidColumnException e) {
                fail("[T1]", "Exception non corretta");
            }
        }
        //=========================================================================================
        {
            try {
                confronta("[T2]", new int[]{1, 1, 1, 1}, Eserc1.selezionaColonna(
                        new int[][]{
                                {1, 2, 3, 4, 5},
                                {1, 2, 3, 4, 5},
                                {1, 2, 3, 4, 5},
                                {1, 2, 3, 4, 5}
                        }, 0));
            } catch (InvalidColumnException e) {
                fail("[T2]", "Exception non corretta");
            }
        }
        //=========================================================================================
        {
            try {
                confronta("[T3]", new int[]{1, 1, 5, 3}, Eserc1.selezionaColonna(
                        new int[][]{
                                {1, 2, 3, 4, 5},
                                {1, 2, 3, 4, 5},
                                {5, 2, 3, 4, 5},
                                {3, 2, 3, 4, 5}
                        }, 0));
            } catch (InvalidColumnException e) {
                fail("[T3]", "Exception non corretta");
            }
        }
        //=========================================================================================
        {
            try {
                confronta("[T4]", new int[]{}, Eserc1.selezionaColonna(
                        new int[][]{

                        }, 0));
            } catch (InvalidColumnException e) {
                fail("[T4]", "Exception non corretta");
            }
        }
        //=========================================================================================
        {
            try {
                confronta("[T3]", new int[]{5, 5, 5, 5, 5, 5, 5, 5, 5}, Eserc1.selezionaColonna(
                        new int[][]{
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5}

                        }, 0));
            } catch (InvalidColumnException e) {
                fail("[T5]", "Exception non corretta");
            }
        }
        //=========================================================================================
        {
            try {
                Eserc1.selezionaColonna(
                        new int[][]{
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5}

                        }, 5);
                fail("[T6]", "Exception non rilanciata");
            } catch (InvalidColumnException e) {
                confronta("[T6]", "colonna non valida", e.getMessage());
            }
        }
        //=========================================================================================
        {
            try {
                Eserc1.selezionaColonna(
                        new int[][]{
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5}

                        }, -1);

                fail("[T7]", "Exception non rilanciata");
            } catch (InvalidColumnException e) {
                confronta("[T7]", "colonna non valida", e.getMessage());
            }
        }
        //=========================================================================================
        {
            try {
                Eserc1.selezionaColonna(
                        new int[][]{
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5},
                                {5, 5, 5, 5, 5}

                        }, 20);

                fail("[T8]", "Exception non rilanciata");
            } catch (InvalidColumnException e) {
                confronta("[T8]", "colonna non valida", e.getMessage());
            }
        }
        //=========================================================================================
        {
            try {
                Eserc1.selezionaColonna(
                        new int[][]{
                                {},
                        }, 0);

                fail("[T9]", "Exception non rilanciata");
            } catch (InvalidColumnException e) {
                confronta("[T9]", "colonna non valida", e.getMessage());
            }
        }
        //=========================================================================================
        {
            try {
                confronta("[T10]", new int[]{1}, Eserc1.selezionaColonna(
                        new int[][]{
                                {1},
                        }, 0));
            } catch (InvalidColumnException e) {
                fail("[T10]", "Exception non corretta");
            }
        }
        //=========================================================================================
        {
            try {
                confronta("[T11]", new int[]{9, 9, 9, 9, 9, 9, 9, 9, 9}, Eserc1.selezionaColonna(
                        new int[][]{
                                {9},
                                {9},
                                {9},
                                {9},
                                {9},
                                {9},
                                {9},
                                {9},
                                {9},
                        }, 0));

            } catch (InvalidColumnException e) {
                fail("[T11]", "Exception non corretta");
            }
        }


        //=========================================================================================
        {
            checkRicorsione("[T12]", "Eserc1.java");
        }
    }
}
