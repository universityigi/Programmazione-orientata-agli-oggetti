import java.io.*;

@SuppressWarnings({"unchecked"})
public class ProvaEserc3 extends TemplateProvaEserc {
    public static void main(String[] args) throws IOException {
        //=========================================================================================
        {
            ListaStudenti lp = new ListaStudenti();
            lp.aggiungiInTesta("1", "bruno rossi", 5, 5);
            lp.aggiungiInTesta("2", "enzo gironi", 8, 14);
            lp.aggiungiInTesta("3", "bruno gallo", 3, 17);
            lp.aggiungiInTesta("4", "giacomo verdi", 2, 20);
            lp.aggiungiInTesta("5", "marco bianco", 8, 8);
            lp.aggiungiInTesta("6", "mario rossi", 5, 10);
            confronta("[T1]", 6, lp.lunghezza());
        }
        //=========================================================================================
        {
            ListaStudenti lp = new ListaStudenti();
            lp.aggiungiInTesta("1", "bruno rossi", 5, 5);
            confronta("[T2]", 1, lp.lunghezza());
        }

        //=========================================================================================
        {
            ListaStudenti lp = new ListaStudenti();
            confronta("[T3]", 0, lp.lunghezza());
        }

        //=========================================================================================
        {
            ListaStudenti lp = new ListaStudenti();
            lp.aggiungiInTesta("1", "bruno rossi", 5, 5);
            lp.aggiungiInTesta("2", "enzo gironi", 8, 14);
            lp.aggiungiInTesta("3", "bruno gallo", 3, 17);
            lp.aggiungiInTesta("4", "giacomo verdi", 2, 20);
            lp.aggiungiInTesta("5", "marco bianco", 8, 8);
            lp.aggiungiInTesta("6", "mario rossi", 5, 10);
            confronta("[T4]", 3, lp.contaPromossi());
        }

        //=========================================================================================
        {
            ListaStudenti lp = new ListaStudenti();
            lp.aggiungiInTesta("1", "bruno rossi", 5, 5);
            lp.aggiungiInTesta("2", "enzo gironi", 8, 14);
            lp.aggiungiInTesta("3", "bruno gallo", 3, 17);
            lp.aggiungiInTesta("4", "giacomo verdi", 2, 20);
            lp.aggiungiInTesta("5", "marco bianco", 8, 8);
            lp.aggiungiInTesta("6", "mario rossi", 5, 10);
            confronta("[T5]", new String[]{"4", "3", "2"}, lp.listaPromossi());
        }


        //=========================================================================================
        {
            ListaStudenti lp = new ListaStudenti();
            lp.aggiungiInTesta("1", "bruno rossi", 5, 15);
            confronta("[T6]", "<1:5-15>", lp.init.toString());
        }

        //=========================================================================================
        {
            ListaStudenti lp = new ListaStudenti();
            lp.aggiungiInTesta("2", "bruno rossi", 6, 7);
            lp.aggiungiInTesta("1", "mario rossi", 5, 15);
            confronta("[T7]", "<2:6-7>", lp.init.next.toString());
        }

        //=========================================================================================
        {
            ListaStudenti lp = new ListaStudenti();
            lp.aggiungiInTesta("2", "bruno rossi", 6, 7);
            lp.aggiungiInTesta("1", "mario rossi", 5, 15);
            lp.aggiungiInTesta("4", "mario rossi", 5, 15);
            lp.aggiungiInTesta("5", "mario rossi", 5, 15);
            confronta("[T7/2]", "<4:5-15>", lp.init.next.toString());
        }

        //=========================================================================================
        {
            ListaStudenti lp = new ListaStudenti();
            confronta("[T8]", 0, lp.contaPromossi());
        }

        //=========================================================================================
        {
            ListaStudenti lp = new ListaStudenti();
            confronta("[T8]", new String[]{}, lp.listaPromossi());
        }

        //=========================================================================================
        {
            ListaStudenti lp = new ListaStudenti();
            lp.aggiungiInTesta("1", "bruno rossi", 5, 15);
            lp.aggiungiInTesta("2", "enzo gironi", 8, 14);
            lp.aggiungiInTesta("3", "bruno gallo", 3, 17);
            lp.aggiungiInTesta("4", "giacomo verdi", 2, 20);
            lp.aggiungiInTesta("5", "marco bianco", 8, 18);
            lp.aggiungiInTesta("6", "mario rossi", 5, 19);
            confronta("[T9]", 6, lp.contaPromossi());
        }

        //=========================================================================================
        {
            ListaStudenti lp = new ListaStudenti();
            lp.aggiungiInTesta("1", "bruno rossi", 5, 15);
            lp.aggiungiInTesta("2", "enzo gironi", 8, 14);
            lp.aggiungiInTesta("3", "bruno gallo", 3, 17);
            lp.aggiungiInTesta("4", "giacomo verdi", 2, 20);
            lp.aggiungiInTesta("5", "marco bianco", 8, 18);
            lp.aggiungiInTesta("6", "mario rossi", 5, 19);
            confronta("[T10]", new String[]{"6", "5", "4", "3", "2", "1"}, lp.listaPromossi());
        }
    }

}
