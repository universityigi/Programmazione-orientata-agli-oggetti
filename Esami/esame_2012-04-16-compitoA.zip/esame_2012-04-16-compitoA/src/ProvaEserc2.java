import java.io.*;
import java.util.*;

@SuppressWarnings({"unchecked"})
public class ProvaEserc2 extends TemplateProvaEserc {

    private static final File dizionario = new File("dizionario");
//    private static final File dizionario = new File("C:\\DATA\\universita\\Corsi\\Fondamenti I\\AA 2010-2011\\esami\\correttoreEsami\\esami\\esame_2012-04-16-compitoA\\src\\dizionario.txt");

    public static void main(String[] args) throws IOException {
        //=========================================================================================
        {
            confronta("[T1]", new int[]{2, 2, 7, 2}, Eserc2.codificaT9("casa"));
        }

        //=========================================================================================
        {
            confronta("[T2]", new int[]{2, 2, 2, 2}, Eserc2.codificaT9("aaaa"));
        }

        //=========================================================================================
        {
            confronta("[T3]", new int[]{3, 7, 2, 6, 3}, Eserc2.codificaT9("esame"));
        }

        //=========================================================================================
        {
            confronta("[T4]", new int[]{7, 7, 6, 8, 2}, Eserc2.codificaT9("prova"));
        }

        //=========================================================================================
        {
            confronta("[T5]", new int[]{9, 8, 9, 9, 8, 7, 7, 6}, Eserc2.codificaT9("zuzzurro"));
        }

        //=========================================================================================
        {
            confronta("[T6]", new int[]{7, 5, 8, 8, 6}, Eserc2.codificaT9("pluto"));
        }

        //=========================================================================================
        {
            confronta("[T7]", Arrays.asList("rosta"), Eserc2.trovaCorrispondenzeT9(new int[]{7, 6, 7, 8, 2}, dizionario));
        }

        //=========================================================================================
        {
            confronta("[T8]", Arrays.asList("dado"), Eserc2.trovaCorrispondenzeT9(new int[]{3, 2, 3, 6}, dizionario));
        }
        //=========================================================================================
        {
            confronta("[T9]", new ArrayList<String>(), Eserc2.trovaCorrispondenzeT9(new int[]{1, 2}, dizionario));
        }

        //=========================================================================================
        {
            confronta("[T10]", new ArrayList<String>(), Eserc2.trovaCorrispondenzeT9(new int[]{0, 0, 1, 1, 1, 1, 1, 1, 0}, dizionario));
        }

        //=========================================================================================
        {
            confronta("[T10/bis]", new ArrayList<String>(), Eserc2.trovaCorrispondenzeT9(new int[]{}, dizionario));
        }

        //=========================================================================================
        {
            confronta("[T11]", new ArrayList<String>(), Eserc2.trovaCorrispondenzeT9(new int[]{2, 2, 3, 3, 2, 2}, dizionario));
        }

        //=========================================================================================
        {
            confronta("[T12]", Arrays.asList("a", "b", "c"), Eserc2.trovaCorrispondenzeT9(new int[]{2}, dizionario));
        }

        //=========================================================================================
        {
            confronta("[T13]", Arrays.asList("poi"), Eserc2.trovaCorrispondenzeT9(new int[]{7, 6, 4}, dizionario));
        }

        //=========================================================================================
        {
            confronta("[T14]", Arrays.asList("dai"), Eserc2.trovaCorrispondenzeT9(new int[]{3, 2, 4}, dizionario));
        }

        //=========================================================================================
        {
            confronta("[T15]", Arrays.asList("prova"), Eserc2.trovaCorrispondenzeT9(new int[]{7, 7, 6, 8, 2}, dizionario));
        }
        //=========================================================================================
        {
            confronta("[T16]", Arrays.asList("g", "h", "i"), Eserc2.trovaCorrispondenzeT9(new int[]{4}, dizionario));
        }


    }
}
