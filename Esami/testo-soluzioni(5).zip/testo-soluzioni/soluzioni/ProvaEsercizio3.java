
import java.util.LinkedList;
import java.util.List;

public class ProvaEsercizio3 extends TemplateProvaEserc{
    public static void main(String[] args) {
		Studente s1 = new Studente("Mario", "Rossi");
                s1.addEsame("fisica");
                s1.addEsame("fi");
                s1.addEsame("analisi");
                s1.addEsame("analisi");
                confronta("[T1] ", "fisica fi analisi", s1.toString() );
               
                List<String> l1 = new LinkedList();
		l1.add("fisica");l1.add("chimica");
               
                confronta("[T2] ",1, s1.quanti(l1));
                
                l1 = new LinkedList();
		l1.add("fisica1");l1.add("chimica1");
                confronta("[T3] ", 0, s1.quanti(l1));
                
                l1 = new LinkedList();
                confronta("[T4] ", 0, s1.quanti(l1));
                
                confronta("[T4] ", false, s1.addEsame("fisica"));
                
		
    }
}
