
import java.util.LinkedList;
import java.util.List;

public class Studente {
    private String nome;
    private String cognome;
    
    private  List<String> esami;

    public Studente(String nome, String Cognome) {
        this.nome=nome;
        this.cognome=cognome;
        this.esami=new LinkedList();
	}
    public boolean addEsame(String e){  
        if (esami.contains(e))
            return false;
        return esami.add(e);
    }
    
    public int quanti(List<String> el){
        int quanti=0;
        System.out.println(el.size());
        for(int i=0; i<el.size();i++) {
            if (esami.contains(el.get(i))) {
           quanti++;
               
            }
        }
        return quanti;      
    }
    
    

	public String toString() {
		String r = "";
		for (int k=0; k<esami.size(); k++) {
			r += esami.get(k)+" ";
		}
		return r.trim();
	}
}
