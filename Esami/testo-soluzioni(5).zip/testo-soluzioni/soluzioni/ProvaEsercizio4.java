import java.io.*;
import java.util.*;

public class ProvaEsercizio4 extends TemplateProvaEserc {
    public static void main(String[] args) throws IOException {
		int tnum = 0;
                Integer n;
		
		List<Integer> l1 = new LinkedList();
                List<Integer> l2 = new LinkedList();
                
		l1.add(4);l1.add(3);l1.add(2);l1.add(1);	// 4321	
   	
		n = Esercizio4.creaIntero(l1);		
		confronta("[T" + tnum++ +"]", 4321, n); 

		l1 = new LinkedList();
                l1.add(9);
                n = Esercizio4.creaIntero(l1);
		confronta("[T" + tnum++ +"]", 9, n); 
		
		l1 = Esercizio4.creaLista(314);
                l2 = new LinkedList();
                l2.add(3);l2.add(1);l2.add(4);
			
		confronta("[T" + tnum++ +"]", l2, l1); 
                
                l1 = Esercizio4.creaLista(5);
                l2 = new LinkedList();
                l2.add(5);
			
		confronta("[T" + tnum++ +"]", l2, l1); 
		
		//l1 = Esercizio4.creaLista("");
		//s = estraiStringa(l1);
		//confronta("[T" + tnum++ +"]", "", Esercizio4.creaStringa(l1)); 		
    }
	
	private static String estraiStringa(List<Character> l){
		String s = "";
		Iterator<Character> it = l.iterator();
		while (it.hasNext()){
			s += it.next().toString();
		}
		return s;
	}
}
