import java.util.*;



public class Esercizio4{
	
	public static Integer creaIntero(List<Integer> lista){
		Integer num=0;
                              
                for (int i=0; i< lista.size(); i++) {
                num=num+lista.get(lista.size-i-1)*(int)(Math.pow(10,i));
            }
                
                return num;    
	}
	
	public static List<Integer> creaLista(Integer n){
                LinkedList<Integer> risultato = new LinkedList<Integer>();
                int i=10; 
                int cifra;
                if (n==0)
                    risultato.add(0);
                while (n>0){
                    cifra=n%10;
                    n=n/10;
                    risultato.add(cifra);           
                }
                    
	
		return risultato;
	}
}
