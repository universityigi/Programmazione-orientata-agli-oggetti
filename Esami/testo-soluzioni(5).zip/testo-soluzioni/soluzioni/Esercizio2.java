public class Esercizio2{
	public static boolean sommaATre(int[] v){
                if (v.length<3)
                        return false;
		return sommaATre(v,2);
	}
	
	private static boolean sommaATre(int[] v, int i){
		if (i > v.length-1){
			return true;
		}
		if (v[i] != v[i-1]+v[i-2]){
			return false;
		}
		return sommaATre(v,i+1);
	}
	
	public static boolean sommaATre(int[][] m){
	    if (m.length==0) return false;
		return sommaATre(m,0);
	}
	
	private static boolean sommaATre(int[][] m, int i){
		if (m.length <= i) {
			return true;
		}
		return (sommaATre(m[i]) && sommaATre(m,++i));
	}
}


