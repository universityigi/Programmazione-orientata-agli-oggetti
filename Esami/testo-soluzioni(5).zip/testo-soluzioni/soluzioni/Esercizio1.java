public class Esercizio1{
	public static char[][] impilaMatrici(char[][] m1, char[][] m2){
		int r, c;
                int r1=0, r2=0;
                int c1=0, c2=0;
                
		if (m1.length > 0) {
			r1 = m1.length;
                        c1 = m1[0].length;
		}
		if (m2.length > 0) {
			r2 = m2.length;
                        c2 = m2[0].length;
		}
			
		if (c1 > c2){
			c = c1;
		}
		else{
			c = c2;
		}		
		
		r = r1 + r2;
		
		char[][] risultato = new char[r][c];

		for (int i = 0; i < r ; i++) {
			for (int j = 0; j < c; j++) {
				risultato[i][j] = '.';
				if (i < r1 && j < c1) {
					risultato[i][j] = m1[i][j];
				}
				if (i >= r1 && j < c2){
					risultato[i][j] = m2[i-r1][j];
				}
			}
		}

		return risultato;
	}
}