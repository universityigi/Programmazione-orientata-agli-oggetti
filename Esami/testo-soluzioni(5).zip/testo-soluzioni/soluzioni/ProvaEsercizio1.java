public class ProvaEsercizio1 extends TemplateProvaEserc{

	public static boolean confrontaMatrici(char[][] m1, char[][] m2){
		if (m1.length != m2.length){
			return false;
		}
		if (m1.length == 0 && m2.length == 0){
			return true;
		}
		if (m1[0].length != m2[0].length){
			return false;
		}
		if (m1[0].length == 0 && m2[0].length == 0){
			return true;
		}
		for (int i = 0; i < m1.length; i++){
			for (int j = 0; j < m1[i].length; j++){
				if (m1[i][j] != m2[i][j]) {
					return false;
				}
			}
		}
		return true;
	}
	
	public static void stampaMatrice(char[][] m){
		for (int i = 0; i < m.length; i++){
			for (int j = 0; j < m[i].length; j++){
				System.out.print(m[i][j] + " ");				
			}
			System.out.println();
		}
	}		
	
	public static void main(String[] args){
		char[][] m1 = {
			{'a', 'a', 'a'},
			{'a', 'a', 'a'},
			{'a', 'a', 'a'},
			{'a', 'a', 'a'}
		};
		
		char[][] m2 = {
			{'b', 'b'},
			{'b', 'b'}
		};
		
		char[][] atteso1 = {
			{'b', 'b', '.'},
			{'b', 'b', '.'},
			{'a', 'a', 'a'},
			{'a', 'a', 'a'},
			{'a', 'a', 'a'},
			{'a', 'a', 'a'}
		};
		
		char[][] atteso2 = {
			{'a', 'a', 'a'},
			{'a', 'a', 'a'},
			{'a', 'a', 'a'},
			{'a', 'a', 'a'},
			{'b', 'b', '.'},
			{'b', 'b', '.'}
		};

		
		char[][] vuota = {};
		
		
		char[][] m = Esercizio1.impilaMatrici(m2,m1);
		
        confronta("T1", true, confrontaMatrici(m,atteso1));
		System.out.println();
		System.out.println("risultato = "); 
		stampaMatrice(m);
		System.out.println();
		System.out.println("risultato atteso = "); 
		stampaMatrice(atteso1);
		System.out.println();
		
		m = Esercizio1.impilaMatrici(m1,m2);	
		confronta("T2", true, confrontaMatrici(m,atteso2));
		System.out.println();
		System.out.println("risultato = "); 
		stampaMatrice(m);
		System.out.println();
		System.out.println("risultato atteso = "); 
		stampaMatrice(atteso2);
		System.out.println();
		
		
		m = Esercizio1.affiancaMatrici(m1,vuota);
		confronta("T3", true, confrontaMatrici(m,m1));
		System.out.println();
		System.out.println("risultato = "); 
		stampaMatrice(m);
		System.out.println();
		System.out.println("risultato atteso = "); 
		stampaMatrice(m1);
		System.out.println();
		
		m = Esercizio1.affiancaMatrici(vuota, m1);
		confronta("T4", true, confrontaMatrici(m,m1));
		System.out.println();
		System.out.println("risultato = "); 
		stampaMatrice(m);
		System.out.println();
		System.out.println("risultato atteso = "); 
		stampaMatrice(m1);
		System.out.println();
		
		m = Esercizio1.affiancaMatrici(vuota, vuota);
		confronta("T5", true, confrontaMatrici(m,vuota));
		System.out.println();
		System.out.println("risultato = "); 
		stampaMatrice(m);
		System.out.println();
		System.out.println("risultato atteso = "); 
		stampaMatrice(vuota);
		System.out.println();
	}	
}
