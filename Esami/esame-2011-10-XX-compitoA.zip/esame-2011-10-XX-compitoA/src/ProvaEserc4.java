import geom.*;
import geom.impl.*;
import geom.util.*;

import java.util.*;

@SuppressWarnings({"unchecked"})
public class ProvaEserc4 extends TemplateProvaEserc {
    public static void main(String[] args) {
        //=========================================================================================
        {
            confronta("[T1]", true, FiguraPiana.class.isAssignableFrom(Rettangolo.class));
        }
        //=========================================================================================
        {
            confronta("[T2]", true, FiguraPiana.class.isAssignableFrom(TrapezioRettangolo.class));
        }
        //=========================================================================================
        {
            confronta("[T3]", true, FiguraPiana.class.isAssignableFrom(TriangoloRettangolo.class));
        }
        //=========================================================================================
        {
            confronta("[T4]", false, TrapezioRettangolo.class.isAssignableFrom(TriangoloRettangolo.class));
        }
        //=========================================================================================
        {
            verificaClasse("[T5]", "geom.impl.TrapezioRettangolo");
        }
        //=========================================================================================
        {
            verificaClasse("[T6]", "geom.impl.TriangoloRettangolo");
        }
        //=========================================================================================
        {
            verificaClasse("[T7]", "geom.impl.Rettangolo");
        }
        //=========================================================================================
        {
            verificaClasse("[T8]", "geom.FiguraPiana");
        }
        //=========================================================================================
        {
            verificaClasse("[T9]", "geom.util.Utilita");
        }

        //=========================================================================================
        {
            Rettangolo r = new Rettangolo(10, 20);
            confronta("[T10]", 200, r.area());
        }
        //=========================================================================================
        {
            Rettangolo r = new Rettangolo(10, 20);
            confronta("[T11]", 10, r.base());
        }
        //=========================================================================================
        {
            Rettangolo r = new Rettangolo(10, 20);
            confronta("[T12]", 20, r.altezza());
        }
        //=========================================================================================
        {
            Rettangolo r = new Rettangolo(10, 20);
            confronta("[T12]", 60, r.perimetro());
        }
        //=========================================================================================
        {
            Rettangolo r = new Rettangolo(10, 20);
            confronta("[T13]", 4, r.numeroLati());
        }
        //=========================================================================================
        {
            TriangoloRettangolo r = new TriangoloRettangolo(10, 10);
            confronta("[T14]", 50, r.area(), 2);
        }
        //=========================================================================================
        {
            TriangoloRettangolo r = new TriangoloRettangolo(10, 10);
            confronta("[T15]", 34.14, r.perimetro(), 2);
        }
        //=========================================================================================
        {
            TriangoloRettangolo r = new TriangoloRettangolo(10, 10);
            confronta("[T16]", 14.14, r.ipotenusa(), 2);
        }
        //=========================================================================================
        {
            TriangoloRettangolo r = new TriangoloRettangolo(10, 10);
            confronta("[T17]", 3, r.numeroLati());
        }
        //=========================================================================================
        {
            TrapezioRettangolo r = new TrapezioRettangolo(10, 20, 5);
            confronta("[T18]", 75, r.area(), 2);
        }
        //=========================================================================================
        {
            TrapezioRettangolo r = new TrapezioRettangolo(10, 20, 5);
            confronta("[T18]", 7.07, r.lato(), 2);
        }
        //=========================================================================================
        {
            TrapezioRettangolo r = new TrapezioRettangolo(10, 20, 5);
            confronta("[T19]", 44.14, r.perimetro(), 2);
        }
        //=========================================================================================
        {
            List<FiguraPiana> ff = new ArrayList<FiguraPiana>();
            ff.add(new Rettangolo(100, 5));
            ff.add(new Rettangolo(100, 5));
            ff.add(new TriangoloRettangolo(100, 5));
            ff.add(new TrapezioRettangolo(10, 20, 2));

            confronta("[T20]", 500 + 500 + 250 + 30, Utilita.areaTotale(ff), 2);
        }
        //=========================================================================================
        {
            List<FiguraPiana> ff = new ArrayList<FiguraPiana>();
            Rettangolo r1 = new Rettangolo(100, 5);
            Rettangolo r2 = new Rettangolo(100, 5);
            TriangoloRettangolo r3 = new TriangoloRettangolo(100, 5);
            TrapezioRettangolo r4 = new TrapezioRettangolo(10, 20, 2);
            ff.add(r1);
            ff.add(r2);
            ff.add(r3);
            ff.add(r4);

            confronta("[T21]", Arrays.asList((FiguraPiana) r3), Utilita.selezionaFigure(ff, 3));
        }
        //=========================================================================================
        {
            List<FiguraPiana> ff = new ArrayList<FiguraPiana>();
            Rettangolo r1 = new Rettangolo(100, 5);
            Rettangolo r2 = new Rettangolo(100, 5);
            TriangoloRettangolo r3 = new TriangoloRettangolo(100, 5);
            TrapezioRettangolo r4 = new TrapezioRettangolo(10, 20, 2);
            ff.add(r1);
            ff.add(r2);
            ff.add(r3);
            ff.add(r4);

            confronta("[T22]", new ArrayList<FiguraPiana>(), Utilita.selezionaFigure(ff, 2));
        }
        //=========================================================================================
        {
            List<FiguraPiana> ff = new ArrayList<FiguraPiana>();
            Rettangolo r1 = new Rettangolo(100, 5);
            Rettangolo r2 = new Rettangolo(100, 5);
            TriangoloRettangolo r3 = new TriangoloRettangolo(100, 5);
            TrapezioRettangolo r4 = new TrapezioRettangolo(10, 20, 2);
            ff.add(r1);
            ff.add(r2);
            ff.add(r3);
            ff.add(r4);

            confronta("[T23]", Arrays.asList(r1, r2, r4), Utilita.selezionaFigure(ff, 4));
        }

        //=========================================================================================
        {
            List<FiguraPiana> ff = new ArrayList<FiguraPiana>();
            confronta("[T24]", new ArrayList<FiguraPiana>(), Utilita.selezionaFigure(ff, 2));
        }
    }
}
