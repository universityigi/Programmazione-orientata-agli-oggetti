import java.io.*;
import java.util.*;

@SuppressWarnings({"unchecked"})
public class ProvaEserc3 extends TemplateProvaEserc {
    public static void main(String[] args) {
        final File filePersonaggi = new File("personaggi.txt");
//        final File filePersonaggi = new File(
//                "D:\\data\\universita\\Corsi\\Fondamenti I\\AA 2010-2011\\esami\\correttoreEsami\\esami\\esame-2011-10-XX-compitoA\\src\\personaggi.txt");

        //=========================================================================================
        {
            ListaStringhe l = new ListaStringhe();
            l.aggiungiInCoda("pippo");
            l.aggiungiInCoda("pluto");
            l.aggiungiInCoda("paperino");

            List<String> ris = Arrays.asList("pippo", "pluto", "paperino");
            confronta("[T1]", ris, extractValues(l.init));
        }
        //=========================================================================================
        {
            ListaStringhe l = new ListaStringhe();

            List<String> ris = Arrays.asList();
            confronta("[T2]", ris, extractValues(l.init));
        }
        //=========================================================================================
        {
            ListaStringhe l = new ListaStringhe();
            l.aggiungiInCoda("pippo");
            l.aggiungiInCoda("pluto");
            l.aggiungiInCoda("paperino");

            confronta("[T3]", 3, l.lunghezza());
        }
        //=========================================================================================
        {
            ListaStringhe l = new ListaStringhe();
            confronta("[T4]", 0, l.lunghezza());
        }

        //=========================================================================================
        {
            ListaStringhe l = new ListaStringhe();
            List<String> ris = new ArrayList<String>();
            for (int i = 0; i < 100; i++) {
                l.aggiungiInCoda("" + i);
                ris.add("" + i);
            }
            confronta("[T3/B]", 100, l.lunghezza());
        }
        //=========================================================================================
        {
            ListaStringhe l = new ListaStringhe();
            List<String> ris = new ArrayList<String>();
            for (int i = 0; i < 100; i++) {
                l.aggiungiInCoda("" + i);
                ris.add("" + i);
            }
            confronta("[T3/C]", ris, extractValues(l.init));
        }

        //=========================================================================================
        {
            ListaStringhe l = new ListaStringhe();
            try {
                l.aggiungiDaFile(filePersonaggi);

                List<String> ris = Arrays.asList("pippo",
                        "pluto",
                        "paperino",
                        "qui",
                        "quo",
                        "qua",
                        "nonna papera",
                        "zio paperone",
                        "paperoga");
                confronta("[T5]", ris, extractValues(l.init));
            } catch (IOException e) {
                fail("[T5]", "Exception inaspettata");
            }
        }

        //=========================================================================================
        {
            ListaStringhe l = new ListaStringhe();
            try {
                l.aggiungiDaFile(new File("INESISTENTE"));
                fail("[T6]", "Eccezione non rilanciata");
            } catch (IOException e) {
                success("[T6]", "Eccezione rilanciata correttamente");
            }
        }
    }

    private static List<String> extractValues(NodoStringa n) {
        List<String> l = new ArrayList<String>();
        for (; n != null; n = n.next)
            l.add(n.elem);
        return l;
    }
}
