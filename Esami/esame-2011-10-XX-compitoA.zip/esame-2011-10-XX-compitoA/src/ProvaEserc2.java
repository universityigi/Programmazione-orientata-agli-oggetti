import java.util.*;
@SuppressWarnings({"unchecked"})
public class ProvaEserc2 extends TemplateProvaEserc {
    public static void main(String[] args) {
        //=========================================================================================
        {
            List<Object> l = new ArrayList<Object>(Arrays.asList("pippo", "pluto", new Object(), "paperino", 123, 10L));
            List<String> ris = Arrays.asList("pippo", "pluto", "paperino");
            confronta("[T1]", ris.toString(), "" + Eserc2.cercaStringhe(l));
        }
        //=========================================================================================
        {
            List<Object> l = new ArrayList<Object>(Arrays.asList(12, new Object(), 3.5, 123, 10L));
            List<String> ris = Arrays.asList();
            confronta("[T2]", ris.toString(), "" + Eserc2.cercaStringhe(l));
        }
        //=========================================================================================
        {
            List<Object> l = new ArrayList<Object>();
            List<String> ris = Arrays.asList();
            confronta("[T3]", ris.toString(), "" + Eserc2.cercaStringhe(l));
        }
        //=========================================================================================
        {
            List<Object> l = new ArrayList<Object>(
                    Arrays.asList(1, 2, 3, 4, '1', '2', '3', '4', "1", "2", "3", "4", null));
            List<String> ris = Arrays.asList("1", "2", "3", "4");
            confronta("[T4]", ris.toString(), "" + Eserc2.cercaStringhe(l));
        }
        //=========================================================================================
        {
            List<Object> l = new ArrayList<Object>(Arrays.asList("*"));
            List<String> ris = Arrays.asList("*");
            confronta("[T5]", ris, Eserc2.cercaStringhe(l));
        }
        //=========================================================================================
        {
            List<Object> l = new ArrayList<Object>(Arrays.asList("x", null, "1", null));
            List<String> ris = Arrays.asList("x", "1");
            confronta("[T6]", ris, Eserc2.cercaStringhe(l));
        }
        //=========================================================================================
        {
            List<Integer> l = new ArrayList<Integer>(Arrays.asList(1, 2, 3, 4, 3));
            Eserc2.rimuoviElementi(l.iterator(), 3);
            List<Integer> ris = Arrays.asList(1, 2, 4);
            confronta("[T7]", ris, l);
        }
        //=========================================================================================
        {
            List<Integer> l = new ArrayList<Integer>(Arrays.asList(1, 2, 3, 4, 3));
            Eserc2.rimuoviElementi(l.iterator(), 12);
            List<Integer> ris = Arrays.asList(1, 2, 3, 4, 3);
            confronta("[T8]", ris, l);
        }
        //=========================================================================================
        {
            List<Integer> l = new ArrayList<Integer>(Arrays.asList(1, 1, 1, 1, 1, 1, 1, 1, 1));
            Eserc2.rimuoviElementi(l.iterator(), 1);
            List<Integer> ris = Arrays.asList();
            confronta("[T9]", ris, l);
        }
        //=========================================================================================
        {
            List<Integer> l = new ArrayList<Integer>();
            Eserc2.rimuoviElementi(l.iterator(), 1);
            List<Integer> ris = Arrays.asList();
            confronta("[10]", ris, l);
        }
        //=========================================================================================
        {
            List<Integer> l = new ArrayList<Integer>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));
            Eserc2.rimuoviElementi(l.iterator(), 1);
            List<Integer> ris = Arrays.asList(2, 3, 4, 5, 6, 7, 8, 9, 10);
            confronta("[11]", ris, l);
        }

    }
}
