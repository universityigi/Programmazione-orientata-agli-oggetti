
public class EccezioneMatrici extends RuntimeException {
	public EccezioneMatrici(String s) { super(s); }
}
