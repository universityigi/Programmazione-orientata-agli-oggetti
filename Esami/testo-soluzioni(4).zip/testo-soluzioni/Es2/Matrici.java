
public class Matrici{
	
	public static int[][] generaMatriceABlocchi(int[][] A, int[][] B) {
		if (A.length!=A[0].length || B.length!=B[0].length || A.length!= B.length || A[0].length!=B[0].length)
			throw new EccezioneMatrici("Dimensione matrici errata");
		
		int sizeM = A.length;
		int n = 2 * sizeM;
		int[][] C = new int[n][n];
		
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < n; j++) {
				if(i < sizeM && j < sizeM)
					C[i][j] = A[i][j];
				else if(i >= sizeM && j >= sizeM)
					C[i][j] = A[i - sizeM][j - sizeM];
				else if(j >=sizeM)
					C[i][j] = B[i][j - sizeM];
				else
					C[i][j] = B[i - sizeM][j];
			}
		}
		
		return C;
	}
	
	public static int sommaElementiDiagonalePrincipale(int[][] A) {
		if (A.length != A[0].length)
			throw new EccezioneMatrici("Dimensione matrici errata");
		int n = A[0].length;
		
		int sum = 0;
		
		for(int i = 0; i < n; i++) {
			sum += A[i][i];
		}
		
		return sum;		
	}	
	
}
