public class ProvaEsercizio2 extends TemplateProvaEserc {
	
    public static void main(String[] args) {
        
        int[][] A1 = {
                {1,2,3},
                {1,2,3},
                {1,2,3}
            };

        int[][] A2 = {
                {4,5,6},
                {4,5,6},
                {4,5,6}
            };
        
        int[][] B1 = {
                {7,8,9},
                {7,8,9},
                {7,8,9}
            };
            
        int[][] B2 = {
			{10,11},
			{10,11}
		};

        int[][] T1 = {
                { 1, 2, 3, 1, 2, 3 },
                { 1, 2, 3, 1, 2, 3 },
                { 1, 2, 3, 1, 2, 3 },
                { 1, 2, 3, 1, 2, 3 },
                { 1, 2, 3, 1, 2, 3 },
                { 1, 2, 3, 1, 2, 3 }
            };

        int[][] T2 = {
                { 1, 2, 3, 4, 5, 6 },
                { 1, 2, 3, 4, 5, 6 },
                { 1, 2, 3, 4, 5, 6 },
                { 4, 5, 6, 1, 2, 3 },
                { 4, 5, 6, 1, 2, 3 },
                { 4, 5, 6, 1, 2, 3 }
            };
        
        int[][] T3 = {
                { 7, 8, 9, 1, 2, 3 },
                { 7, 8, 9, 1, 2, 3 },
                { 7, 8, 9, 1, 2, 3 },
                { 1, 2, 3, 7, 8, 9 },
                { 1, 2, 3, 7, 8, 9 },
                { 1, 2, 3, 7, 8, 9 }
            };
        
        int[][] C1 = Matrici.generaMatriceABlocchi(A1, A1);
        int[][] C2 = Matrici.generaMatriceABlocchi(A1, A2);
        int[][] C3 = Matrici.generaMatriceABlocchi(B1, A1);
        
        int tnum = 0;
        confronta("[" + tnum++ + "]", toString(T1), toString(C1));
        confronta("[" + tnum++ + "]", toString(T2), toString(C2));
        confronta("[" + tnum++ + "]", toString(T3), toString(C3));

        
        try {
				Matrici.generaMatriceABlocchi(A1, B2);
				System.out.println("ERR");
        }
        catch (Exception e) {
				confronta("[" + tnum++ +"]","Dimensione matrici errata", e.getMessage());
        }
        

        try {
				Matrici.generaMatriceABlocchi(B2, A2);
				System.out.println("ERR");
        }
        catch (Exception e) {
				confronta("["+ tnum++ +"]","Dimensione matrici errata", e.getMessage());
        }
        
        
        confronta("["+ tnum++ + "]", 12, Matrici.sommaElementiDiagonalePrincipale(C2));
        
        int [][] C4 = Matrici.generaMatriceABlocchi(B2,B2);
        
        confronta("["+ tnum++ + "]", 42, Matrici.sommaElementiDiagonalePrincipale(C4));

    }


	static String toString(int[][] A) {
		String r="";
		for (int i=0; i<A.length; i++) {
			for (int j=0; j<A[0].length; j++) { 
				r+= A[i][j]+" ";
			}
			r += "\n";
		}
		return r;
	}

}
