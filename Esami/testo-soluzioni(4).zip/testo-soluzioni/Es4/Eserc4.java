

public class Eserc4 {

    public static int contaOccorrenzeVettore(int []vet, int elem, int idx) {
		if(idx < vet.length) {
			if(vet[idx] == elem) {
				return contaOccorrenzeVettore(vet, elem, idx+1) + 1;
			} else {
				return contaOccorrenzeVettore(vet, elem, idx+1);
			}
		} else {
			return 0;
		}
	}
	
	public static int numOccorrenzeVettore(int []vet, int elem) {
		return contaOccorrenzeVettore(vet, elem, 0);
	}
	
	public static int contaOccorrenzeMatrice(int [][]mat, int elem, int idx) {
		if(idx < mat.length) {
			return contaOccorrenzeVettore(mat[idx], elem, 0) + contaOccorrenzeMatrice(mat, elem, idx + 1);
		} else {
			return 0;
		}
	}
	
	public static int numOccorrenzeMatrice(int [][]mat, int elem)  {
		return contaOccorrenzeMatrice(mat, elem, 0);
	}

}
