
import java.io.*;

public class ProvaEsercizio4 extends TemplateProvaEserc {

private static int []v1 = {3, 4, 1, 4, 4, 5};
private static int []v2 = {};
private static int []v3 = {4, 4, 4, 4};	

private static int [][]mat1 = { {1, 2, 3},
								 {4, 4, 5},
								 {4, 6, 4}
							 };

private static int [][]mat2 = { {},
								 {},
								 {}
							 };

private static int [][]mat3 = { {1, 2, 3},
								 {4, 5, 6},
								 {7, 8, 9}
							 };

	
	public static void main(String[] args)  {
		checkRicorsione("ricorsione", "Eserc4.java");
		confronta("[T1]", 3, Eserc4.numOccorrenzeVettore(v1, 4));
		confronta("[T2]", 0, Eserc4.numOccorrenzeVettore(v2, 3));
		confronta("[T3]", 4, Eserc4.numOccorrenzeVettore(v3, 4));
		confronta("[T4]", 4, Eserc4.numOccorrenzeMatrice(mat1, 4));
		confronta("[T5]", 0, Eserc4.numOccorrenzeMatrice(mat2, 2));
		confronta("[T6]", 0, Eserc4.numOccorrenzeMatrice(mat3, 0));
	}
   
}
