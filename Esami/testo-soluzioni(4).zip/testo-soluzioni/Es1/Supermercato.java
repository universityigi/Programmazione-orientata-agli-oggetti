import java.util.*;


public class Supermercato {
    
    private String responsabile;
    private String indirizzo;
    private HashSet<Prodotto> prodotti;
    private double incasso;
    
    public Supermercato (String responsabile, String indirizzo ) {
	this.responsabile = responsabile;
	this.indirizzo = indirizzo;
	this.prodotti = new HashSet<Prodotto>();
	this.incasso = 0.;
    }
    
    public String getResponsabile() {
	return responsabile;
    }

    public String getIndirizzo() {
	return indirizzo;
    }

    public Prodotto getProdotto(String codice) {
	Iterator<Prodotto> it = prodotti.iterator();
	while (it.hasNext()){
	    Prodotto p = it.next();
	    if (p.getCodice().equals(codice))
		return p;
	}
	return null;
    }

    public boolean addProdotto(String codice,  String nome, int confezioni, double prezzo){
	Prodotto old = getProdotto(codice);
	if (old == null){
	    prodotti.add(new Prodotto(codice, nome, confezioni, prezzo));
            return true;
        }
        else{
			old.addConfezioni(confezioni);
            return false;
        }
    }
    
    public boolean vendiProdotto(String codice, int q){
	Prodotto old = getProdotto(codice);
	if (old == null) {
            return false;
        }
        else
            if (old.getNumeroDiConfezioni()-1>0){
                old.addConfezioni(-q);
				incasso += (q * old.getPrezzo());
                return true;
            }   
        return false;
        }

    public double getIncasso() {
	return incasso;
    }
}
