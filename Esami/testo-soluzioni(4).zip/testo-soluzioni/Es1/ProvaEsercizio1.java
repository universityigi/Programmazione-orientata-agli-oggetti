import java.io.*;
public class ProvaEsercizio1 extends TemplateProvaEserc {
    public static void main(String[] args) throws IOException {
	               
	String r1 = "Mario Rossi";
	String i1 = "via le mani dal naso 8";

	String c1 = "01";
	String c2 = "02";
	String c3 = "03";
	String c4 = "04";
	String c5 = "01";
	String c6 = "06";  
    String c7 = "07"; 
                
    String m1 = "latte";
	String m2 = "orzo";
	String m3 = "pane";
	String m4 = "uova";
	String m5 = "latte";
	String m6 = "pasta";

        
    int n1=1;
	int n2=22;
    int n3=0;
    int n4=4;
    int n5=55;
    int n6=6;
    
    double p1=2.99;
    double p2=4.00;
    double p3=1.50;
    double p4=0.99;
    double p5=2.99;
    double p6=1.04;
                
	

	int tnum = 0;
	Supermercato f = new Supermercato(r1, i1);
	confronta("[T" + tnum++ +"]", f.getResponsabile(), r1); 
	confronta("[T" + tnum++ +"]", f.getIndirizzo(), i1); 

	boolean bb1 = f.addProdotto(c1, m1, n1, p1);
	boolean bb2 = f.addProdotto(c2, m2, n2, p2);
    boolean bb3 = f.addProdotto(c3, m3, n3, p3);
    boolean bb4 = f.addProdotto(c4, m4, n4, p4);
    boolean bb5 = f.addProdotto(c5, m5, n5, p5);
    boolean bb6 = f.addProdotto(c6, m6, n6, p6);
        
    confronta("[T" + tnum++ +"]", true, bb1); 
    confronta("[T" + tnum++ +"]", false, bb5); 
        
	Prodotto p = f.getProdotto(c1);
	confronta("[T" + tnum++ +"]", m1, p.getNome());        
    confronta("[T" + tnum++ +"]", 56, p.getNumeroDiConfezioni()); 
        
    p = f.getProdotto(c2);
    confronta("[T" + tnum++ +"]", 22, p.getNumeroDiConfezioni());
       
    f.vendiProdotto(c2, 1);
    confronta("[T" + tnum++ +"]", 21, p.getNumeroDiConfezioni());
       
    confronta("[T" + tnum++ +"]", true, f.vendiProdotto(c2, 2));
       
    
    confronta("[T" + tnum++ +"]", false, f.vendiProdotto(c3, 1)); 
    
    
    confronta("[T" + tnum++ +"]", true, f.vendiProdotto(c5, 3));
        
    confronta("[T" + tnum++ +"]", false, f.vendiProdotto(c7, 1));
    
    
    confronta("[T" + tnum++ +"]", 20.97, f.getIncasso());
        


    }
}
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author BeppeSan
 */
