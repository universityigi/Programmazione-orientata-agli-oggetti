import java.io.*;
import java.util.*;

public class ProvaEsercizio3  extends TemplateProvaEserc{
	
	private static int []l1 = {1, 2, 3, 4, 5};
	private static int []l2 = {1, 1, 1, 1, 1};
	private static int []l3 = {2, 2, 5, 5, 6};
	private static int []l4 = {6, 6, 2, 1, 1};
	private static int []l5 = {3, 3, 1, 4, 4};
	
	private static int []l6 = {4, 4, 4, 4, 4};
	private static int []l7 = {3, 2, 1, 4, 6};
	private static int []l8 = {5, 3, 1, 4, 5};
	private static int []l9 = {6, 6, 6, 6, 6};
	private static int []l10 = {5, 3, 1, 6, 6};
	
	public static void main(String[] args)  throws IOException {
		Dadi d1 = new Dadi();
		d1.lancia(new Lancio(l1));
		d1.lancia(new Lancio(l6));
		d1.lancia(new Lancio(l2));
		d1.lancia(new Lancio(l7));
		d1.lancia(new Lancio(l3));
		d1.lancia(new Lancio(l8));
		d1.lancia(new Lancio(l4));
		d1.lancia(new Lancio(l9));
		d1.lancia(new Lancio(l5));
		d1.lancia(new Lancio(l10));

		confronta("[T1]", 71, d1.punteggioA());
		confronta("[T2]", 105, d1.punteggioB());
		confronta("[T3]", false, d1.lancia(new Lancio(l1)));
		confronta("[T4]", 71, d1.punteggioA());
	}
}
