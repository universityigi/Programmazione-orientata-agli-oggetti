import java.io.*;
import java.util.*;

public class Lancio {
	private int punteggioCorrente[];
	
	public Lancio(int []punteggioCorrente){
		this.punteggioCorrente = punteggioCorrente;
	}
	
	public int[] getConfigurazioneCorrente(){
		return punteggioCorrente;
	}
}
