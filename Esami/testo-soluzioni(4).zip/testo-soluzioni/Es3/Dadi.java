import java.io.*;
import java.util.*;

public class Dadi {
	public List<Lancio> giocatoreA;
	public List<Lancio> giocatoreB;
	
	public Dadi(){
		giocatoreA = new ArrayList<Lancio>();
		giocatoreB = new ArrayList<Lancio>();
	}
	
	public boolean lancia(Lancio l){
		if (giocatoreB.size() == 5){
			return false;
		}
		if (giocatoreA.size() == giocatoreB.size()){
			giocatoreA.add(l);
		}
		else{
			giocatoreB.add(l);
		}
		return true;
	}
	
	public int risultato(){
		if(punteggioA() > punteggioB()){
			return 1;
		}
		if(punteggioA() < punteggioB()){
			return 2;
		}
		return 0;
	}
	
	public int punteggioA(){
		return punteggio(giocatoreA);
	}
	
	public int punteggioB(){
		return punteggio(giocatoreB);
	}
	
	
	private int punteggio(List<Lancio> g){
		int punti = 0;
		Iterator it = g.iterator();		
		while(it.hasNext()){
			Lancio l = (Lancio) it.next();
			if (l != null){
				int []p = l.getConfigurazioneCorrente();
				
				for(int i = 0; i < p.length; i++)
					punti+=p[i];				
			}
		}
		return punti;
	}	
}
