import java.io.*;
public class ProvaEsercizio1 extends TemplateProvaEserc {

    public static void main(String[] args) throws IOException {
	        Concerto s1 = new Concerto("SalaA", "2 maggio 2012");
		Concerto s2 = new Concerto("SalaB", "3 maggio 2012", "Classica", "Antonio Vivaldi");
                
                s1.aggiungiPersonaggiInvitati("prova_Concerto.txt");
                              
				confronta("[T1]", "Classica", s2.getGenere());
				
				confronta("[T2]", "Antonio Vivaldi", s2.getArtista());
				
				confronta("[T3]", 3, s1.getNumeroInvitati());
                
				confronta("[T4]", "Mario Rossi,Luigi Verdi,Nicola Bianchi", s1.getInvitati());
                
				confronta("[T5]", true, s1.setGenere("Pop"));
                
                confronta("[T6]", "Pop", s1.getGenere());
                
                confronta("[T7]", false, s1.aggiungiNuovoInvitato("Mario Rossi"));
				
				confronta("[T8]", 3, s1.getNumeroInvitati());
                
                confronta("[T9]", true, s1.aggiungiNuovoInvitato("Zio Paperone"));
				
				confronta("[T10]", 4, s1.getNumeroInvitati());
                
                confronta("[T11]", "Mario Rossi,Luigi Verdi,Nicola Bianchi,Zio Paperone", s1.getInvitati());
                
                confronta("[T12]", false, s1.cancellaInvitato("Zio Paperino"));
				
			    confronta("[T13]", 4, s1.getNumeroInvitati());
                
                confronta("[T14]", true, s1.cancellaInvitato("Luigi Verdi"));
				
				confronta("[T15]", 3, s1.getNumeroInvitati());
                
                confronta("[T16]", "Mario Rossi,Nicola Bianchi,Zio Paperone", s1.getInvitati());
    }
}
