import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class Concerto {

    private String [] invitati;
    private String  genere;
    private String  artista;
    private String sala;
    private String data;
    
    //definire qui i metodi pubblici della classe:

    public Concerto (String sala, String data) {
        this.sala = sala;
        this.data = data;
        this.genere=null;
		this.artista=null;
        invitati=new String[0];
    }
    
   public Concerto (String sala, String data, String genere, String artista) {
        this.sala = sala;
        this.data = data;
        this.genere=genere;
		this.artista=artista;
		invitati=new String[0];
    }
   
   public void aggiungiPersonaggiInvitati (String nomeFileInput) throws IOException {
        FileInputStream f = new FileInputStream (nomeFileInput);
        InputStreamReader in = new InputStreamReader(f);
        BufferedReader br = new BufferedReader(in);
        String line = br.readLine();
        while (line!=null){
            aggiungiNuovoInvitato(line);
            line = br.readLine();
        }
        br.close();
        in.close();
        f.close();
    }
    
   public boolean aggiungiNuovoInvitato(String nome) {
       if(esiste(nome))
           return false;
       String []nuovalista = new String[invitati.length+1];
       for(int i=0;i<invitati.length;i++)
           nuovalista[i] = invitati[i];
       nuovalista[nuovalista.length-1]=nome;
       invitati=nuovalista;
       return true;
   }
   

  public boolean cancellaInvitato(String nome) { // cancella un partecipante, controllando che gi� non sia stato inserito. Si assuma che non esistano due partecipanti con lo stesso nome e cognome
      for(int i=0;i<invitati.length;i++)
          if(invitati[i].equals(nome)){
              invitati[i]="";
              return true;
          }
      return false;
  
  }
  public int getNumeroInvitati() { // restituisce un intero contenente il numero dei partecipanti
     int numero=0;
	 for(int i=0;i<invitati.length;i++)
          if(invitati[i].length()>0)
              numero++;
	 return numero;
     }
  public String getGenere() { // restituisce il genere del concerto
     return this.genere;
     }
  public String getArtista() { // restituisce l'esecutore del concerto
     return this.artista;
     }	 
  
  public String getInvitati() { // restituisce una stringa contenente tutti i partecipanti concatenati tra di loro e separati da virgole nel formato <nome><spazio><cognome><,><nome><spazio><cognome><,>...
        if (invitati.length == 0)
			return "";
	  	String lista=invitati[0];
        for (int i=1;i<invitati.length; i++)
		    if (invitati[i]!="")
            lista=lista+","+invitati[i];
        return lista;
    }
 public boolean setGenere(String argomento){ // inserisce il genere del concerto. Se l'argomento gi� esiste NON lo modifica e restituisce false; se l'argomento non esiste lo aggiunge  e restituisce true.
        if (this.genere!=null)
            return false;
        else{
            this.genere=argomento;
            return true;
        }           
    }
    
public boolean getInvitato(String partecipante) { // restituisce true se il partecipante � invitato
  return true;
} 

public  boolean esiste(String partecipante){
     for (int i=0;i<invitati.length; i++)
        if(invitati[i].equals(partecipante))
                return true;
    return false;

    }
}
