public class Matrice {

   private static boolean estOvest(int[][] mat, int i, int j){
       
       return mat[i][j]==mat[i][j-1]+mat[i][j+1];
   }

    public static int contaColonneEstOvest(int[][] mat) {
        int colonneEO = 0;
        int elemEO;
        for (int j=1; j<mat[0].length-1; j++) {
            elemEO=0;
            for (int i=0; i<mat.length; i++) {           
                if(estOvest(mat,i,j))
                    elemEO++;
            }
            if (elemEO>1)
                colonneEO++;
        }
        return colonneEO;
    }
    
    public static void stampaMatrice (int[][] m){
        System.out.println("=============================\n");
        for (int i=0; i<m.length; i++){
            for (int j=0; j<m[0].length; j++){
                System.out.print(m[i][j]+" ");
            }
            System.out.println();
        }
        System.out.println("=============================\n");
    }
}
