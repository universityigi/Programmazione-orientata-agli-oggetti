import java.io.*;
public class ProvaEsercizio2 extends TemplateProvaEserc {
 
    public static int[][] leggiMatriceDaFile(String nomeFile)throws IOException{
        FileInputStream f = new FileInputStream (nomeFile);
        InputStreamReader is = new InputStreamReader(f);
        BufferedReader in = new BufferedReader(is);
         int righe=Integer.parseInt(in.readLine());
         int colonne=Integer.parseInt(in.readLine());

         int[][] mat=new int[righe][colonne];
          for(int i=0;i<mat.length;i++)
            for (int j=0;j<mat[i].length;j++){
                 mat[i][j]=Integer.parseInt(in.readLine());
            }
         in.close();
         is.close();
         f.close();
         return mat;
    }
    
    

    
    public static void main(String[] args) throws IOException {
        int[][] m = leggiMatriceDaFile("Matrice1.txt");
        //Matrice.stampaMatrice(m);
        confronta("[T1]", 1, Matrice.contaColonneEstOvest(m));
        m = leggiMatriceDaFile("Matrice2.txt");
        //Matrice.stampaMatrice(m);
        confronta("[T2]", 0, Matrice.contaColonneEstOvest(m));
        m = leggiMatriceDaFile("Matrice3.txt");
        //Matrice.stampaMatrice(m);
        confronta("[T3]", 2, Matrice.contaColonneEstOvest(m));
    }
}