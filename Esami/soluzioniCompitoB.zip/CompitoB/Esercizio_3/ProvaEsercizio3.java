
import java.io.*;

public class ProvaEsercizio3 extends TemplateProvaEserc {
public static void main(String[] args)  {
        checkRicorsione("ricorsione", "Eserc3.java");
        confronta("[T1]", 2, Eserc3.contaCarattere("cassa", 'a'));
	confronta("[T2]", 0, Eserc3.contaCarattere("cart", 'z'));
	confronta("[T3]", 4, Eserc3.contaCarattere("aabbaa", 'a'));
}
   
}
