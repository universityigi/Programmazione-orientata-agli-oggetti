

public class Eserc3 {

    

    public static int contaCarattere (String s, char c){
		if(s.length()>0){
			char current = s.charAt(0);
                        String nuova = s.substring(1);
			if(current == c){
                            return Eserc3.contaCarattere(nuova, c)+1;
			}
                        else{
                            return Eserc3.contaCarattere(nuova, c);
                        }
		}
		else{
			return 0;
		}
	
	
	}
}
