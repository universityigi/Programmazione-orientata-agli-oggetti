public class ProvaEserc3 extends TemplateProvaEserc {
    public static void main(String[] args) {
        {
            ListaGenerica<String> l1 = new ListaGenerica<String>();
            confronta("[T1]", 0, l1.occorrenze("pippo"));
            confronta("[T2]", true, l1.init == null);

            l1.aggiungiInCoda("pippo");
            l1.aggiungiInCoda("pluto");
            l1.aggiungiInCoda("paperino");

            confronta("[T3]", 1, l1.occorrenze("pippo"));
            confronta("[T4]", 1, l1.occorrenze("pluto"));
            confronta("[T5]", 1, l1.occorrenze("paperino"));
        }

        {
            ListaGenerica<Integer> l1 = new ListaGenerica<Integer>();
            ListaGenerica<Integer> l2 = new ListaGenerica<Integer>();
            ListaGenerica<String> l3 = new ListaGenerica<String>();
            for (int i = 0; i < 10; i++) {
                l1.aggiungiInCoda(i);
                l2.aggiungiInCoda(i);
                l3.aggiungiInCoda("" + i);
            }
            confronta("[T6]", true, l1.equals(l2));
            confronta("[T7]", false, l1.equals(l3));
            confronta("[T8]", false, l1.equals(null));
            confronta("[T8_1]", false, l1.equals("xxx"));

            confronta("[T9]", "[0,1,2,3,4,5,6,7,8,9]", _toString(l1.init));
        }

        {
            ListaGenerica<Integer> l1 = new ListaGenerica<Integer>();
            ListaGenerica<Integer> l2 = new ListaGenerica<Integer>();
            for (int i = 0; i < 10; i++) {
                l1.aggiungiInCoda(i);
                l2.aggiungiInCoda(0);
            }
            confronta("[T10]", false, l1.equals(l2));
            confronta("[T11]", 1, l1.occorrenze(0));
            confronta("[T12]", 0, l1.occorrenze(-10));
            confronta("[T13]", 0, l2.occorrenze(1));
            confronta("[T14]", 10, l2.occorrenze(0));
            confronta("[T15]", "[0,0,0,0,0,0,0,0,0,0]", _toString(l2.init));
        }

        {
            ListaGenerica<Integer> l1 = new ListaGenerica<Integer>();
            ListaGenerica<Integer> l2 = new ListaGenerica<Integer>();
            l1.aggiungiInCoda(1);
            l1.aggiungiInCoda(2);
            l1.aggiungiInCoda(3);
            l1.aggiungiInCoda(4);
            l1.aggiungiInCoda(5);

            l2.aggiungiInCoda(1);
            l2.aggiungiInCoda(2);
            l2.aggiungiInCoda(3);
            l2.aggiungiInCoda(4);

            confronta("[T16]", false, l1.equals(l2));
            confronta("[T17]", false, l2.equals(l1));
        }

        {
            ListaGenerica<Integer> l1 = new ListaGenerica<Integer>();
            ListaGenerica<Integer> l2 = new ListaGenerica<Integer>();
            l1.aggiungiInCoda(1);
            l1.aggiungiInCoda(2);
            l1.aggiungiInCoda(3);
            l1.aggiungiInCoda(4);
            l1.aggiungiInCoda(5);

            l2.aggiungiInCoda(1);
            l2.aggiungiInCoda(2);
            l2.aggiungiInCoda(3);
            l2.aggiungiInCoda(4);
            l2.aggiungiInCoda(4);

            confronta("[T18]", false, l1.equals(l2));
            confronta("[T19]", false, l2.equals(l1));
        }
        {
            ListaGenerica<Integer> l1 = new ListaGenerica<Integer>();
            ListaGenerica<Integer> l2 = new ListaGenerica<Integer>();
            l1.aggiungiInCoda(1);
            l1.aggiungiInCoda(2);
            l1.aggiungiInCoda(3);
            l1.aggiungiInCoda(4);
            l1.aggiungiInCoda(5);

            l2.aggiungiInCoda(1);
            l2.aggiungiInCoda(2);
            l2.aggiungiInCoda(3);
            l2.aggiungiInCoda(5);
            l2.aggiungiInCoda(4);

            confronta("[T20]", false, l1.equals(l2));
            confronta("[T21]", false, l2.equals(l1));
        }

        {
            ListaGenerica<Integer> l1 = new ListaGenerica<Integer>();
            try {
                l1.aggiungiInCoda(null);
                fail("[T22]","Il metodo doveva rilanciare una eccezione");
            } catch (NullPointerException e) {

            }

        }
    }

    static String _toString(NodoGenerico<?> n) {
        StringBuilder sb = new StringBuilder();
        while (n != null) {
            if (sb.length() > 0) {
                sb.append(",");
            }
            sb.append(n.elem);
            n = n.next;
        }
        return "[" + sb + "]";
    }
}
