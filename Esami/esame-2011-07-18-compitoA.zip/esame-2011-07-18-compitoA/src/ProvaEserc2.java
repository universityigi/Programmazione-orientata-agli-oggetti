public class ProvaEserc2 extends TemplateProvaEserc {
    public static void main(String[] args) {
        //==============================================================================
        {
            confronta("[T1]", "cosso", Eserc2.cifra("cassa", 'a', 'o'));

        }

        //==============================================================================
        {
            confronta("[T2]", "paperina", Eserc2.cifra("paperino", 'o', 'a'));
        }

        //==============================================================================
        {
            confronta("[T3]", "nanerino", Eserc2.cifra("paperino", 'p', 'n'));
        }

        //==============================================================================
        {
            confronta("[T4]", "paperino", Eserc2.cifra("paperino", 's', 't'));
        }

        //==============================================================================
        {
            confronta("[T5]", "", Eserc2.cifra("", 's', 't'));
        }

        //==============================================================================
        {
            confronta("[T6]", "ccccccccccccccccbcccccccccccccccc",
                    Eserc2.cifra("aaaaaaaaaaaaaaaabcccccccccccccccc", 'a', 'c'));
        }

        //==============================================================================
        {
            String[] s = new String[]{"xyz", "xabc", "x123"};
            Eserc2.cifraArray(s, 'x', '*');
            confronta("[T7]", new String[]{"*yz", "*abc", "*123"}, s);
        }

        //==============================================================================
        {
            String[] s = new String[]{"xyz", "xabc", "x123"};
            Eserc2.cifraArray(s, '1', '*');
            confronta("[T8]", new String[]{"xyz", "xabc", "x*23"}, s);
        }

        //==============================================================================
        {
            String[] s = new String[]{"xyz", "xabc", "x123"};
            Eserc2.cifraArray(s, 'z', '*');
            confronta("[T9]", new String[]{"xy*", "xabc", "x123"}, s);
        }

        //==============================================================================
        {
            String[] s = new String[]{"xyz", "xabc", "x123"};
            Eserc2.cifraArray(s, 't', '*');
            confronta("[T10]", new String[]{"xyz", "xabc", "x123"}, s);
        }

        //==============================================================================
        {
            String[] s = new String[]{"xyz", "xabc", "x123"};
            Eserc2.cifraArray(s, 'a', 'a');
            confronta("[T11]", new String[]{"xyz", "xabc", "x123"}, s);
        }

        //==============================================================================
        {
            String[] s = new String[]{};
            Eserc2.cifraArray(s, 'a', 'a');
            confronta("[T12]", new String[]{}, s);
        }

        //==============================================================================
        {
            String[] s = new String[]{"aaaaaaaaaaaaaaaaaa","aaaaaaaaaaa","aaaaaaa"};
            Eserc2.cifraArray(s, 'a', '*');
            confronta("[T13]", new String[]{"******************","***********","*******"}, s);
        }

    }
}
