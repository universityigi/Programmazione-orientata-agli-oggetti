public class ProvaEserc1 extends TemplateProvaEserc {
    public static void main(String[] args) throws EccezioneQuadratoMagico {

        //=========================================================================================
        {
            int[][] m2 = new int[][]{
                    {2, 2, 2},
                    {2, 2, 2},
                    {2, 2, 2}
            };
            confronta("[T2]", 6, Eserc1.quadratoMagico(m2));
        }

        //=========================================================================================
        {
            int[][] m3 = new int[][]{
                    {1, 6, 5},
                    {8, 4, 0},
                    {3, 2, 7}
            };
            confronta("[T3]", 12, Eserc1.quadratoMagico(m3));
        }

        //=========================================================================================
        {
            int[][] m4 = new int[][]{
                    {1, 6, 5},
                    {8, 4, 0},
                    {3, 2, 7, 0}
            };
            try {
                Eserc1.quadratoMagico(m4);
                fail("[T4]", "L'eccezione EccezioneQuadratoMagico non e' stata rilanciata");
            } catch (EccezioneQuadratoMagico eccezioneQuadratoMagico) {
                confronta("[T4-catch]", "Non e' un quadrato magico", eccezioneQuadratoMagico.getMessage());
            }
        }

        //=========================================================================================
        {
            int[][] m5 = new int[][]{
                    {1, 6, 5, 0},
                    {8, 4, 0, 0},
                    {3, 2, 7, 0}
            };

            try {
                Eserc1.quadratoMagico(m5);
                fail("[T5]", "L'eccezione EccezioneQuadratoMagico non e' stata rilanciata");
            } catch (EccezioneQuadratoMagico eccezioneQuadratoMagico) {
                confronta("[T5-catch]", "Non e' un quadrato magico", eccezioneQuadratoMagico.getMessage());
            }
        }

        //=========================================================================================
        {
            int[][] m7 = new int[][]{
                    {1, 2, 3, 4},
                    {2, 3, 4, 1},
                    {3, 4, 1, 2},
                    {4, 1, 2, 3}
            };
            try {
                Eserc1.quadratoMagico(m7);
                fail("[T7]", "L'eccezione EccezioneQuadratoMagico non e' stata rilanciata");
            } catch (EccezioneQuadratoMagico eccezioneQuadratoMagico) {
                confronta("[T7-catch]", "Non e' un quadrato magico", eccezioneQuadratoMagico.getMessage());
            }
        }

        //=========================================================================================
        {
            int[][] m8 = new int[][]{};
            confronta("[T8]", 0, Eserc1.quadratoMagico(m8));
        }
    }
}
