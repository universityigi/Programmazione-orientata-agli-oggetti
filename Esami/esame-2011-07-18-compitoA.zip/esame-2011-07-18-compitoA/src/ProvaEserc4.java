import funzioni.*;
import funzioni.impl.*;

public class ProvaEserc4 extends TemplateProvaEserc {
    @SuppressWarnings("unchecked")
    public static void main(String[] args) {
        funzioni.impl.Costante c1 = new funzioni.impl.Costante(4.5);
        funzioni.impl.Costante c2 = new funzioni.impl.Costante(20.5);
        funzioni.impl.Costante c3 = new funzioni.impl.Costante(50);
        funzioni.impl.Costante c4 = new funzioni.impl.Costante(25);

        funzioni.impl.FunzioneAritmetica somma = new funzioni.impl.FunzioneAritmetica(c1, '+', c2);
        funzioni.impl.FunzioneAritmetica diff = new funzioni.impl.FunzioneAritmetica(c1, '-', c2);
        funzioni.impl.FunzioneRADQ rad = new funzioni.impl.FunzioneRADQ(somma);

        FunzioneRADQ arg1 = new FunzioneRADQ(new FunzioneAritmetica(
                new Costante(10), '*', new Costante(1000))
        );
        funzioni.impl.FunzioneAritmetica f = new FunzioneAritmetica(
                arg1,
                '/',
                new Costante(5)
        );

        verificaClasse("[T0]", "funzioni.Funzione");
        verificaClasse("[T0]", "funzioni.impl.Costante");
        verificaClasse("[T0]", "funzioni.impl.FunzioneAritmetica");
        verificaClasse("[T0]", "funzioni.impl.FunzioneRADQ");
        //controllo appartenenza ai package (non compila altrimenti)

        confronta("[T1]", true, c1 instanceof Funzione);
        confronta("[T2]", false, FunzioneAritmetica.class.isInstance(c1));
        confronta("[T3]", true, somma instanceof Funzione);
        confronta("[T4]", true, rad instanceof Funzione);

        confronta("[T5]", 20, f.calcola());
        confronta("[T6]", 4.5, c1.calcola());
        confronta("[T7]", 25, somma.calcola());

        confronta("[T8]", "4.5+20.5", somma.toString());
        confronta("[T9]", "RADQ(10*1000)/5", f.toString());
        confronta("[T10]", "50", c3.toString());
        confronta("[T11]", "4.5", c1.toString());
        confronta("[T12]", "5/6.5", new FunzioneAritmetica(new Costante(5), '/', new Costante(6.5)).toString());
        FunzioneRADQ fComp = new FunzioneRADQ(
                new FunzioneRADQ(
                        new FunzioneRADQ(
                                new FunzioneAritmetica(
                                        new FunzioneRADQ(new Costante(25)),
                                        '*',
                                        new Costante(5.5))))
        );
        confronta("[T13]", "RADQ(RADQ(RADQ(RADQ(25)*5.5)))",
                fComp.toString());
        confronta("[T14]", -16, diff.calcola());
        confronta("[T15]", 20, new FunzioneAritmetica(new Costante(50), '-',
                new FunzioneAritmetica(new Costante(20), '+', new FunzioneRADQ(new Costante(100)))).calcola());

    }
}
