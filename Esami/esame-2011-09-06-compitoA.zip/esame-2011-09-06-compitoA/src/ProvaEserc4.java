import msg.*;
import msg.impl.*;
import msg.util.*;

import java.util.*;

public class ProvaEserc4 extends TemplateProvaEserc {
    public static void main(String[] args) {
        Email e = new Email("stefano.millozzi@gmail.com", "studente@infustod.it");
        e.setTesto("Ciao mondo");

        InstantMessage i = new InstantMessage("Luca", "Marco", "luca81-jabber.com", "marco79-jabber.com");
        i.setTesto("Ciao cosa fai?");

        confronta("[T1]", "stefano.millozzi", e.getMittente());
        confronta("[T2]", "studente", e.getDestinatario());
        confronta("[T3]", "Ciao mondo", e.getTesto());
        confronta("[T4]", "EMAIL@gmail.com-From:stefano.millozzi@gmail.com-To:studente@infustod.it-Txt:Ciao mondo",
                e.invia("gmail.com"));
        confronta("[T5]", true, e.flagInviato());

        confronta("[T6-1]", true, (Object) e instanceof Email);
        confronta("[T6-2]", true, (Object) e instanceof Messaggio);
        confronta("[T6-3]", false, (Object) e instanceof InstantMessage);

        confronta("[T7-1]", false, (Object) i instanceof Email);
        confronta("[T7-2]", true, (Object) i instanceof Messaggio);
        confronta("[T7-3]", true, (Object) i instanceof InstantMessage);

        confronta("[T8]", "IM-From:luca81-jabber.com-To:marco79-jabber.com-Txt:Ciao cosa fai?", i.invia());
        confronta("[T9]", true, i.flagInviato());

        //===========================================
        {
            Email e1 = new Email("stefano@gmail.com", "prova@libero.it");
            Email e2 = new Email("matteo@gmail.com", "prova@libero.it");
            InstantMessage s1 = new InstantMessage("stefano", "prova", "stefano123", "provaXYZ");
            InstantMessage i1 = new InstantMessage("stefano", "prova", "stefano123", "provaXYZ");
            confronta("[T10]", new ArrayList<Messaggio>(),
                    Utilita.inviatiDa(new Messaggio[]{e1, e2, s1, i1}, "stefano"));
            confronta("[T11]", new ArrayList<Messaggio>(),
                    Utilita.inviatiDa(new Messaggio[]{e1, e2, s1, i1}, "prova"));
            e1.invia("");
            e2.invia("");
            s1.invia();
            i1.invia();
            confronta("[T12]", asList(e1, s1, i1),
                    Utilita.inviatiDa(new Messaggio[]{e1, e2, s1, i1}, "stefano"));
        }

        confronta("[T13]", "Email:stefano.millozzi,studente,Ciao mondo", e.toString());
        confronta("[T14]", "InstantMessage:Luca,Marco,Ciao cosa fai?", i.toString());
        verificaClasse("[T15/1]", "msg.Messaggio");
        verificaClasse("[T15/2]", "msg.impl.Email");
        verificaClasse("[T15/3]", "msg.impl.InstantMessage");
        verificaClasse("[T15/4]", "msg.util.Utilita");

        Email e2 = new Email("pippo@gmail@pluto.com", "studente@infustod.it");
        confronta("[T16]", "pippo", e2.getMittente());
    }
}
