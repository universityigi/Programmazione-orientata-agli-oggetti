import java.io.*;
import java.util.*;

public class ProvaEserc2 extends TemplateProvaEserc {
    public static void main(String[] args) {
        try {
            final Dizionario d2 = new Dizionario("file-inesistente.txt");
            final Dizionario d1 = new Dizionario("dizionario.txt");

            //=========================================================================================
            {
                confronta("[T1]", 0, d1.riconosciFrase(Arrays.asList("braccobaldo").iterator()));
            }
            //=========================================================================================
            {
                confronta("[T2]", 1, d1.riconosciFrase(Arrays.asList("acrobata").iterator()));
            }
            //=========================================================================================
            {
                confronta("[T2]", 0, d1.riconosciFrase(Arrays.asList("Acrobata").iterator()));
            }
            //=========================================================================================
            {
                confronta("[T4]", 1, d1.riconosciFrase(Arrays.asList("Zurigo").iterator()));
            }
            //=========================================================================================
            {
                confronta("[T5]", 0, d1.riconosciFrase(Arrays.asList("Zurig").iterator()));
            }
            //=========================================================================================
            {
                List<String> s = new ArrayList<String>();
                s.add("Zurigo");
                confronta("[T6]", d1.iniziaPer("Zurig"), s);
            }
            //=========================================================================================
            {
                List<String> s = new ArrayList<String>();
                s.add("zoom");
                s.add("zoomando");
                s.add("zoomare");
                s.add("zoomato");
                s.add("zoometria");
                s.add("zoomorfismo");
                s.add("zoomorfo");

                confronta("[T7]", d1.iniziaPer("zoom"), s);
            }
            //=========================================================================================
            {
                List<String> s = new ArrayList<String>();
                confronta("[T8]", d1.iniziaPer("zoomm"), s);
            }
            //=========================================================================================
            {
                List<String> s = new ArrayList<String>();
                s.add("accalappiatore");
                confronta("[T9]", d1.iniziaPer("accalappiatore"), s);
            }
            //=========================================================================================
            {
                List<String> s = new ArrayList<String>();
                confronta("[T10]", d1.iniziaPer("accalappix"), s);
            }
            //=========================================================================================
            {
                List<String> frase = new ArrayList<String>();
                frase.add("il");
                frase.add("cane");
                frase.add("deve");
                frase.add("mangiare");
                frase.add("tanto");
                confronta("[T11]", d1.riconosciFrase(frase.iterator()), 5);
            }
            //=========================================================================================
            {
                List<String> frase = new ArrayList<String>();
                for (int i = 0; i < 20; i++)
                    frase.add("a");
                confronta("[T12]", d1.riconosciFrase(frase.iterator()), 20);
            }
            //=========================================================================================
            {
                List<String> frase = new ArrayList<String>();
                for (int i = 0; i < 10; i++)
                    frase.add("zuppiera");
                confronta("[T13]", d1.riconosciFrase(frase.iterator()), 10);
            }

            //=========================================================================================
            {
                List<String> frase = new ArrayList<String>();
                frase.add("il");
                frase.add("cane");
                frase.add("123");
                frase.add("4354");
                frase.add("bianco");
                confronta("[T15]", d1.riconosciFrase(frase.iterator()), 3);
            }

            //=========================================================================================
            {
                List<String> frase = new ArrayList<String>();
                confronta("[T16]", d1.riconosciFrase(frase.iterator()), 0);
            }

            //=========================================================================================
            {
                List<String> frase = new ArrayList<String>();
                frase.add("predat");
                frase.add("alfabet");
                frase.add("sconosciut");
                frase.add("vallat");
                confronta("[T17]", d1.riconosciFrase(frase.iterator()), 0);
            }

            //=========================================================================================
            {
                List<String> s = new ArrayList<String>();
                confronta("[T18]", d1.iniziaPer("*"), s);
            }

            //=========================================================================================
            {
                try {
                    d2.iniziaPer("*");
                    fail("[T19]", "Il metodo non ha rilanciato l'eccezione");
                } catch (IOException e) {
                    success("[T19]", "Eccezione rilanciata correttamente");
                }
            }

            //=========================================================================================
            {
                try {
                    List<String> s = new ArrayList<String>();
                    s.add("***");
                    d2.riconosciFrase(s.iterator());
                    fail("[T20]", "Il metodo non ha rilanciato l'eccezione");
                } catch (IOException e) {
                    success("[T20]", "Eccezione rilanciata correttamente");
                }
            }
        } catch (IOException e) {
            throw new IllegalArgumentException(e);
        }

    }
}
