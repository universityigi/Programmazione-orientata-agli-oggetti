public class ProvaEserc1 extends TemplateProvaEserc {
    public static void main(String[] args) {
        //=========================================================================================
        {
            int[] m1 = new int[]{2, 2, 2};
            int[] m2 = new int[]{2, 2, 2};
            int[] ris = new int[]{4, 4, 4};
            confronta("[T1]", Eserc1.somma(m1, m2), ris);
        }
        //=========================================================================================
        {
            int[] m1 = new int[]{2, 2, 2};
            int[] m2 = new int[]{2, 2, 2, 2};
            try {
                Eserc1.somma(m1, m2);
                fail("[T2]", "Eccezione non rilanciata");
            } catch (VettoreException e) {
                confronta("[T2]", e.getMessage(), "Dimensioni differenti");

            }
        }
        //=========================================================================================
        {
            int[] m1 = null;
            int[] m2 = new int[]{2, 2, 2};
            try {
                Eserc1.somma(m1, m2);
                fail("[T3]", "Eccezione non rilanciata");
            } catch (VettoreException e) {
                confronta("[T3]", e.getMessage(), "Vettore nullo");
            }
        }
        //=========================================================================================
        {
            int[] m1 = null;
            int[] m2 = null;
            try {
                Eserc1.somma(m1, m2);
                fail("[T4]", "Eccezione non rilanciata");
            } catch (VettoreException e) {
                confronta("[T4]", e.getMessage(), "Vettore nullo");
            }
        }
        //=========================================================================================
        {
            int[] m1 = new int[]
                    {2, 2, 2};
            int[] m2 = new int[]
                    {};
            try {
                Eserc1.somma(m1, m2);
                fail("[T5]", "Eccezione non rilanciata");
            } catch (VettoreException e) {
                confronta("[T5]", e.getMessage(), "Dimensioni differenti");

            }
        }
        //=========================================================================================
        {
            int[] m1 = new int[]
                    {1, 2, 3};
            int[] m2 = new int[]
                    {3, 2, 1};
            int[] ris = new int[]
                    {4, 4, 4};
            confronta("[T6]", Eserc1.somma(m1, m2), ris);
        }
        //=========================================================================================
        {
            int[] m1 = new int[]{
                    ,
            };
            int[] m2 = new int[]{
                    ,
            };
            int[] ris = new int[]{
                    ,
            };
            confronta("[T7]", Eserc1.somma(m1, m2), ris);
        }

        //=========================================================================================
        {
            int[] m1 = new int[]{1, 1, 1};
            int[] m2 = new int[]{0, 0, 0};
            int[] ris = new int[]{1, 1, 1};
            confronta("[T8]", Eserc1.somma(m1, m2), ris);
        }

        //=========================================================================================
        {
            int[] m1 = new int[]{1};
            int[] m2 = new int[]{100};
            int[] ris = new int[]{101};
            confronta("[T9]", Eserc1.somma(m1, m2), ris);
        }
        //=========================================================================================
        {
            int[] m1 = new int[]{2, 2, 2};
            int[] m2 = new int[]{2};
            try {
                Eserc1.somma(m1, m2);
                fail("[T10]", "Eccezione non rilanciata");
            } catch (VettoreException e) {
                confronta("[T10]", e.getMessage(), "Dimensioni differenti");

            }
        }

        //=========================================================================================
        {
            int[] m1 = new int[]
                    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
            int[] m2 = new int[]
                    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
            int[] ris = new int[]
                    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2};
            confronta("[T11]", Eserc1.somma(m1, m2), ris);
        }

        //=========================================================================================
        {
            checkRicorsione("[T12]","Eserc1.java");
        }

    }
}
