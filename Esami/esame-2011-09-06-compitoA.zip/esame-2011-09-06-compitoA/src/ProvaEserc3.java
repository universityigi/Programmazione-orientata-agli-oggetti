import java.util.*;

public class ProvaEserc3 extends TemplateProvaEserc {
    private static List<Integer> extractSortedNonZeroValues(NodoMatrice n) {
        List<Integer> l = new ArrayList<Integer>();
        for (; n != null; n = n.next)
            if (n.elem != 0)
                l.add(n.elem);
        Collections.sort(l);
        return l;
    }

    public static void main(String[] args) {
        //=========================================================================================
        {
            MatriceSparsa mat = new MatriceSparsa(5, 5);
            confronta("[T1]", 0, mat.get(0, 0));

            mat.set(0, 0, 10);
            confronta("[T2]", 10, mat.get(0, 0));

            mat.set(0, 0, 20);
            confronta("[T3]", 20, mat.get(0, 0));

            confronta("[T4]", extractSortedNonZeroValues(mat.init), asList(20));

            mat.set(0, 0, 0);
            confronta("[T5]", 0, mat.get(0, 0));

            try {
                mat.get(10, 3);
                fail("[T6]", "Eccezione non rilanciata");
            } catch (IllegalArgumentException e) {
                success("[T6]", "Eccezione rilanciata correttamente");
            }
            try {
                mat.get(5, 5);
                fail("[T7]", "Eccezione non rilanciata");
            } catch (IllegalArgumentException e) {
                success("[T7]", "Eccezione rilanciata correttamente");
            }
            try {
                mat.get(2, 7);
                fail("[T8]", "Eccezione non rilanciata");
            } catch (IllegalArgumentException e) {
                success("[T8]", "Eccezione rilanciata correttamente");
            }
        }

        //=========================================================================================
        {
            MatriceSparsa mat = new MatriceSparsa(3, 2);
            confronta("[T8/1]", mat.getRows(), 3);
            confronta("[T8/2]", mat.getCols(), 2);
            int i = 0;
            for (int r = 0; r < mat.getRows(); r++) {
                for (int c = 0; c < mat.getCols(); c++) {
                    i++;
                    mat.set(r, c, i);
                }
            }
            confronta("[T9]", extractSortedNonZeroValues(mat.init), asList(1, 2, 3, 4, 5, 6));

            i = 10;
            for (int r = 0; r < mat.getRows(); r++) {
                for (int c = 0; c < mat.getCols(); c++) {
                    i++;
                    mat.set(r, c, i);
                }
            }
            confronta("[T10]", extractSortedNonZeroValues(mat.init), asList(11, 12, 13, 14, 15, 16));

            for (int r = 0; r < mat.getRows(); r++) {
                for (int c = 0; c < mat.getCols(); c++) {
                    i++;
                    mat.set(r, c, 0);
                }
            }
            confronta("[T11]", extractSortedNonZeroValues(mat.init), new ArrayList<Integer>());

        }

        //=========================================================================================
        {
            MatriceSparsa mat = new MatriceSparsa(3, 2);
            confronta("[T12]", extractSortedNonZeroValues(mat.init), new ArrayList<Integer>());
            int i = 1;
            for (int r = 0; r < mat.getRows(); r++) {
                for (int c = 0; c < mat.getCols(); c++) {
                    confronta("[T13/" + i + "]", 0, mat.get(r, c));
                    i++;
                }
            }
        }

        //=========================================================================================
        {
            MatriceSparsa mat = new MatriceSparsa(3, 2);
            int i = 1;
            ArrayList<Integer> s = new ArrayList<Integer>();
            for (int r = 0; r < mat.getRows(); r++) {
                for (int c = 0; c < mat.getCols(); c++) {
                    int atteso = r * 100 + c;
                    if (atteso != 0)
                        s.add(atteso);
                    mat.set(r, c, r * 100 + c);
                }
            }

            for (int r = 0; r < mat.getRows(); r++) {
                for (int c = 0; c < mat.getCols(); c++) {
                    int atteso = r * 100 + c;
                    confronta("[T14/" + i + "]", atteso, mat.get(r, c));
                    i++;
                }
            }
            Collections.sort(s);
            confronta("[T15]", extractSortedNonZeroValues(mat.init), s);
        }

        //=========================================================================================
        {
            MatriceSparsa mat = new MatriceSparsa(1, 1);
            mat.set(0, 0, -123);
            confronta("[T16]", -123, mat.get(0, 0));

        }

    }
}
