import java.util.*;

public class ProvaEserc2 extends TemplateProvaEserc {
    public static void main(String[] args) {
        {
            List<Integer> l1 = creaLista(20, 15, 14, 10, 10, 8, 7, 4);
            List<Integer> l2 = creaLista(12, 10, 9, 6, 4, 2, 1);
            List<Integer> listaAttesa = creaLista(20, 15, 14, 12, 10, 10, 10, 9, 8, 7, 6, 4, 4, 2, 1);
            List<Integer> ris = Eserc2.fusioneOrdinata(l1, l2);
            confronta("[T1]", listaAttesa.toString(), "" + ris);
        }

        {
            List<Integer> l1 = creaLista(20, 15, 14, 10, 10, 8, 7, 4);
            List<Integer> l2 = creaLista();
            List<Integer> listaAttesa = creaLista(20, 15, 14, 10, 10, 8, 7, 4);
            List<Integer> ris = Eserc2.fusioneOrdinata(l1, l2);
            confronta("[T2]", listaAttesa.toString(), "" + ris);
        }

        {
            List<Integer> l1 = creaLista();
            List<Integer> l2 = creaLista(20, 15, 14, 10, 10, 8, 7, 4);
            List<Integer> listaAttesa = creaLista(20, 15, 14, 10, 10, 8, 7, 4);
            List<Integer> ris = Eserc2.fusioneOrdinata(l1, l2);
            confronta("[T3]", listaAttesa.toString(), "" + ris);
        }

        {
            List<Integer> l1 = creaLista();
            List<Integer> l2 = creaLista();
            List<Integer> listaAttesa = creaLista();
            List<Integer> ris = Eserc2.fusioneOrdinata(l1, l2);
            confronta("[T4]", listaAttesa.toString(), "" + ris);
        }

        {
            List<Integer> l1 = creaLista(9, 8, 7, 6, 5, 4, 3, 2, 1);
            List<Integer> l2 = creaLista(0, -1, -2, -3, -4, -5);
            List<Integer> listaAttesa = creaLista(9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5);
            List<Integer> ris = Eserc2.fusioneOrdinata(l1, l2);
            confronta("[T5]", listaAttesa.toString(), "" + ris);
        }

        {
            List<Integer> l1 = creaLista(0, -1, -2, -3, -4, -5);
            List<Integer> l2 = creaLista(9, 8, 7, 6, 5, 4, 3, 2, 1);
            List<Integer> listaAttesa = creaLista(9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5);
            List<Integer> ris = Eserc2.fusioneOrdinata(l1, l2);
            confronta("[T6]", listaAttesa.toString(), "" + ris);
        }

        {
            List<Integer> l1 = creaLista(0, 0, 0, 0);
            List<Integer> l2 = creaLista(1, 1, 1, 1);
            List<Integer> listaAttesa = creaLista(1, 1, 1, 1, 0, 0, 0, 0);
            List<Integer> ris = Eserc2.fusioneOrdinata(l1, l2);
            confronta("[T7]", listaAttesa.toString(), "" + ris);
        }

        {
            List<Integer> l1 = creaLista(0, 0, 0, 0);
            List<Integer> l2 = creaLista(0, 0, 0, 0);
            List<Integer> listaAttesa = creaLista(0, 0, 0, 0, 0, 0, 0, 0);
            List<Integer> ris = Eserc2.fusioneOrdinata(l1, l2);
            confronta("[T8]", listaAttesa.toString(), "" + ris);
        }

        {
            List<Integer> l1 = creaLista(10, 20, 30, 40, 50);
            List<Integer> listaAttesa = creaLista(30, 40, 50);
            List<Integer> ris = Eserc2.maggiori(l1.iterator(), 25);
            confronta("[T9]", listaAttesa.toString(), "" + ris);
        }

        {
            List<Integer> l1 = creaLista(5, 9, 3, 4, 12, 12, 7);
            List<Integer> listaAttesa = creaLista(9, 12, 12, 7);
            List<Integer> ris = Eserc2.maggiori(l1.iterator(), 5);
            confronta("[T10]", listaAttesa.toString(), "" + ris);
        }

        {
            List<Integer> l1 = creaLista();
            List<Integer> listaAttesa = creaLista();
            List<Integer> ris = Eserc2.maggiori(l1.iterator(), 5);
            confronta("[T11]", listaAttesa.toString(), "" + ris);
        }

        {
            List<Integer> l1 = creaLista(1, 2, 3, 4, 53, 2, 65, 34, 3, 2, 3, 5, 3);
            List<Integer> listaAttesa = creaLista();
            List<Integer> ris = Eserc2.maggiori(l1.iterator(), 500);
            confronta("[T12]", listaAttesa.toString(), "" + ris);
        }

        {
            List<Integer> l1 = creaLista(0, 0, 0, 0, 0);
            List<Integer> l2 = creaLista();
            List<Integer> listaAttesa = creaLista(0, 0, 0, 0, 0);
            List<Integer> ris = Eserc2.fusioneOrdinata(l1, l2);
            confronta("[T13]", listaAttesa.toString(), "" + ris);
        }

        {
            List<Integer> l1 = creaLista(0, 0, 0, 0, 0);
            List<Integer> l2 = creaLista(1, 1, 1, 1, 1, 1);
            List<Integer> listaAttesa = creaLista(1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0);
            List<Integer> ris = Eserc2.fusioneOrdinata(l1, l2);
            confronta("[T14]", listaAttesa.toString(), "" + ris);
        }

        {
            List<Integer> l1 = creaLista();
            List<Integer> l2 = creaLista(1, 1, 1, 1, 1, 1);
            List<Integer> listaAttesa = creaLista(1, 1, 1, 1, 1, 1);
            List<Integer> ris = Eserc2.fusioneOrdinata(l1, l2);
            confronta("[T15]", listaAttesa.toString(), "" + ris);
        }

    }

    //crea una lista di valori a partire da un vettore di interi
    private static List<Integer> creaLista(int... valori) {
        List<Integer> lista = new ArrayList<Integer>();
        for (int i = 0; i < valori.length; i++) {
            int v = valori[i];
            lista.add(v);
        }
        return lista;
    }
}
