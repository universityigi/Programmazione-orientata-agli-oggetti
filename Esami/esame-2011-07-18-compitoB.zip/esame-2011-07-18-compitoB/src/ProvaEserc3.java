public class ProvaEserc3 extends TemplateProvaEserc {
    static String _toString(NodoAutovettura n) {
        StringBuilder sb = new StringBuilder();
        while (n != null) {
            if (sb.length() > 0) {
                sb.append(",");
            }
            sb.append(n.targa).append(" ").append(n.tipo);
            n = n.next;
        }
        return "[" + sb + "]";
    }

    public static void main(String[] args) {
        //====================================================
        {
            verificaClasse("[T1]", "NodoAutovettura");
            verificaClasse("[T2]", "ListaAutovetture");
        }

        //====================================================
        {
            ListaAutovetture l = new ListaAutovetture();
            l.aggiungiInCoda("xyz222cc", "berlina");
            confronta("[T3]", _toString(l.init), "[xyz222cc berlina]");

            l.aggiungiInCoda("aef113dd", "berlina");
            confronta("[T4]", _toString(l.init), "[xyz222cc berlina,aef113dd berlina]");

            l.aggiungiInCoda("aa111bb", "fuoristrada");
            confronta("[T5]", _toString(l.init), "[xyz222cc berlina,aef113dd berlina,aa111bb fuoristrada]");

            confronta("[T6]", new String[]{"xyz222cc", "aef113dd", "aa111bb"}, l.elencaTarghe());

            confronta("[T7]", 2, l.trovaTipoAuto("berlina"));

            confronta("[T8]", 1, l.trovaTipoAuto("fuoristrada"));

            confronta("[T9]", 0, l.trovaTipoAuto("moto"));
        }

        //====================================================
        {
            ListaAutovetture l = new ListaAutovetture();
            l.aggiungiInCoda("targa_1", "berlina");
            l.aggiungiInCoda("targa_2", "berlina");
            l.aggiungiInCoda("targa_3", "berlina");
            l.aggiungiInCoda("targa_4", "berlina");
            l.aggiungiInCoda("targa_5", "berlina");
            l.aggiungiInCoda("targa_6", "berlina");
            l.aggiungiInCoda("targa_7", "berlina");
            l.aggiungiInCoda("targa_8", "berlina");
            l.aggiungiInCoda("targa_9", "berlina");
            confronta("[T10]", _toString(l.init), "[targa_1 berlina,targa_2 berlina,targa_3 berlina," +
                    "targa_4 berlina,targa_5 berlina,targa_6 berlina,targa_7 berlina,targa_8 berlina,targa_9 berlina]");
            confronta("[T11]", 9, l.trovaTipoAuto("berlina"));
            confronta("[T12]",
                    new String[]{"targa_1", "targa_2", "targa_3", "targa_4", "targa_5", "targa_6", "targa_7", "targa_8", "targa_9"},
                    l.elencaTarghe());
        }

        //====================================================
        {
            ListaAutovetture l = new ListaAutovetture();
            confronta("[T13]", new String[0], l.elencaTarghe());
            confronta("[T14]", 0, l.trovaTipoAuto("berlina"));
        }

        //====================================================
        {
            ListaAutovetture l = new ListaAutovetture();
            l.aggiungiInCoda("targa", "berlina");
            l.aggiungiInCoda("targa", "berlina");
            l.aggiungiInCoda("targa", "berlina");
            l.aggiungiInCoda("targa", "berlina");
            l.aggiungiInCoda("targa", "berlina");
            l.aggiungiInCoda("targa", "berlina");
            l.aggiungiInCoda("targa", "berlina");
            l.aggiungiInCoda("targa", "berlina");
            l.aggiungiInCoda("targa", "berlina");
            confronta("[T15]", _toString(l.init), "[targa berlina,targa berlina,targa berlina," +
                    "targa berlina,targa berlina,targa berlina,targa berlina,targa berlina,targa berlina]");
            confronta("[T16]", 9, l.trovaTipoAuto("berlina"));
        }
    }
}
