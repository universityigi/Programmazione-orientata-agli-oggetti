import java.util.*;

public class ProvaEserc4 extends TemplateProvaEserc {
    public static void main(String[] args) {
        //==================================================
        {
            final OnLineVideoStream ovs = new OnLineVideoStream("Wasabi", 400, 300, 15);
            final DiskVideoStream dvs = new DiskVideoStream("Cars", 800, 600, 25);
            confronta("[T1]", true, ovs instanceof VideoStream);
            confronta("[T2]", true, dvs instanceof VideoStream);

            confronta("[T3]", 25, dvs.getFPS());
            confronta("[T4]", 15, ovs.getFPS());
            confronta("[T5]", 600, dvs.height);
            confronta("[T6]", 400, ovs.width);

            ovs.setBitrate(64 * 1024);
            ovs.setNumFrames(100);
            confronta("[T7]", 64 * 1024, ovs.getBitrate());
            confronta("[T8]", 3 * 400 * 300, ovs.frameSize());
            confronta("[T9]", 549, ovs.getDuration());

            dvs.setFilename("cars.avi");
            dvs.setSize(1024 * 1024 * 1024);

            confronta("[T10]", "cars.avi", dvs.getFilename());
            confronta("[T11]", 1024 * 1024 * 1024, dvs.getSize());
            confronta("[T12]", 1440000, dvs.frameSize());
            confronta("[T13]", 29, dvs.getDuration());
        }

        //==================================================
        {
            final OnLineVideoStream v1 = new OnLineVideoStream("Wasabi", 400, 300, 5);
            v1.setBitrate(100000);
            v1.setNumFrames(10);

            final OnLineVideoStream v5 = new OnLineVideoStream("Wasabi2", 400, 300, 5);
            v5.setBitrate(100000);
            v5.setNumFrames(10);

            final DiskVideoStream v2 = new DiskVideoStream("Cars", 500, 200, 10);
            v2.setFilename("cars.mp4");
            v2.setSize(700 * 1024 * 1024);

            final DiskVideoStream v3 = new DiskVideoStream("Wall-e", 200, 100, 7);
            v3.setFilename("wall-e.mp4");
            v3.setSize(800 * 1024 * 1024);

            final DiskVideoStream v4 = new DiskVideoStream("Galline in fuga", 200, 100, 7);
            v4.setFilename("fuga.mp4");
            v4.setSize(700 * 1024 * 1024);

            confronta("[T14]", 36, v1.getDuration());
            confronta("[T15]", 244, v2.getDuration());
            confronta("[T16]", 1997, v3.getDuration());

            //================================================================
            {
                LinkedList<VideoStream> l = new LinkedList<VideoStream>();
                l.add(v1);
                l.add(v2);
                l.add(v3);
                confronta("[T17]", 2277, VideoStreamUtil.totalDuration(l));
                confronta("[T18]", "" + Arrays.asList(v1), "" + VideoStreamUtil.onLine(l));
            }

            //================================================================
            {
                LinkedList<VideoStream> l2 = new LinkedList<VideoStream>();
                l2.add(v1);
                l2.add(v2);
                l2.add(v3);
                l2.add(v4);
                confronta("[T19]", 4024, VideoStreamUtil.totalDuration(l2));
            }

            //================================================================
            {
                LinkedList<VideoStream> l2 = new LinkedList<VideoStream>();
                l2.add(v2);
                l2.add(v3);
                l2.add(v4);
                confronta("[T20]", "" + new LinkedList<VideoStream>(), "" + VideoStreamUtil.onLine(l2));
            }

            //================================================================
            {
                LinkedList<VideoStream> l2 = new LinkedList<VideoStream>();
                l2.add(v1);
                l2.add(v2);
                l2.add(v3);
                l2.add(v4);
                l2.add(v5);
                confronta("[T21]", "" + Arrays.asList(v1, v5), "" + VideoStreamUtil.onLine(l2));
            }

        }
    }
}
