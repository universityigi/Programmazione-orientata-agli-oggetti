import matrici.*;

public class ProvaEserc1 extends TemplateProvaEserc {
    public static void main(String[] args) {
        //==============================================================================
        {
            int[] simboli = new int[]{3, 4, 2, 1};

            int[][] mat = new int[][]{
                    {1, 2, 3, 4},
                    {2, 3, 4, 1},
                    {3, 4, 1, 2},
                    {4, 1, 2, 3},
            };
            confronta("[T1]", 8, Eserc1.controlloUguaglianza(mat, simboli));
        }

        //==============================================================================
        {
            int[] simboli = new int[]{3, 4, 2, 1};

            int[][] mat = new int[][]{
                    {1, 2, 3, 4},
                    {2, 3, 4, 1},
                    {3, 4, 1, 2},
                    {5, 5, 5, 5},
            };
            confronta("[T2]", 3, Eserc1.controlloUguaglianza(mat, simboli));
        }

        //==============================================================================
        {
            int[] simboli = new int[]{3, 4, 2, 1};

            int[][] mat = new int[][]{
                    {1, 2, 3, 4},
                    {2, 3, 4, 1},
                    {3, 4, 1, 2},
                    {4, 4, 4, 4},
            };
            confronta("[T3]", 4, Eserc1.controlloUguaglianza(mat, simboli));
        }

        //==============================================================================
        {
            int[] simboli = new int[]{3, 4, 2, 1};

            int[][] mat = new int[][]{
                    {4, 2, 3, 4},
                    {2, 3, 4, 1},
                    {3, 4, 1, 2},
                    {4, 1, 4, 4},
            };
            confronta("[T4]", 3, Eserc1.controlloUguaglianza(mat, simboli));
        }

        //==============================================================================
        {
            int[] simboli = new int[]{1, 2, 3};

            int[][] mat = new int[][]{
                    {1, 2, 3},
                    {1, 2, 3},
                    {1, 2, 3}
            };
            confronta("[T5]", 3, Eserc1.controlloUguaglianza(mat, simboli));
        }

        //==============================================================================
        {
            int[] simboli = new int[]{5, 4, 3, 2, 1};

            int[][] mat = new int[][]{
                    {1, 2, 3, 4, 5},
                    {1, 2, 3, 4, 5},
                    {1, 2, 3, 4, 5},
                    {1, 2, 3, 4, 5},
                    {1, 2, 3, 4, 5}
            };
            confronta("[T6]", 5, Eserc1.controlloUguaglianza(mat, simboli));
        }

        //==============================================================================
        {
            int[] simboli = new int[]{5, 4, 3, 2, 1};

            int[][] mat = new int[][]{
                    {1, 2, 3, 4, 4},
                    {1, 2, 3, 4, 4},
                    {1, 2, 3, 4, 4},
                    {1, 2, 3, 4, 4},
                    {1, 2, 3, 4, 4}
            };
            confronta("[T7]", 0, Eserc1.controlloUguaglianza(mat, simboli));
        }

        //==============================================================================
        {
            int[] simboli = new int[]{5, 4, 3, 2, 1};

            int[][] mat = new int[][]{
                    {1, 2, 3, 4, 5},
                    {12, 4, 5, 6, 7},
                    {1, 3, 3, 4, 4},
                    {1, 2, 3, 4, 5},
                    {1, 5, 3, 4, 4}
            };
            confronta("[T8]", 2, Eserc1.controlloUguaglianza(mat, simboli));
        }

        //==============================================================================
        {
            int[] simboli = new int[]{1, 2, 3, 4};
            int[][] mat = new int[][]{{1, 2, 3}, {1, 2, 3}, {1, 2, 3}};
            try {
                Eserc1.controlloUguaglianza(mat, simboli);
                fail("[T9]", "Il metodo non ha rilanciato l'eccezione");
            } catch (IllegalArgumentException ex) {
                confronta("[T9-catch]", "Dimensioni errate", ex.getMessage());
            }
        }

        //==============================================================================
        {
            int[] simboli = new int[]{1, 2, 3};
            int[][] mat = new int[][]{{1, 2, 3}, {1, 2, 3}};
            try {
                Eserc1.controlloUguaglianza(mat, simboli);
                fail("[T10]", "Il metodo non ha rilanciato l'eccezione");
            } catch (IllegalArgumentException ex) {
                confronta("[T10-catch]", "Dimensioni errate", ex.getMessage());
            }
        }

        //==============================================================================
        {
            int[] simboli = new int[]{};
            int[][] mat = new int[][]{};
            confronta("[T11]", 0, Eserc1.controlloUguaglianza(mat, simboli));
        }

        //==============================================================================
        {
            int[] simboli = new int[]{1};
            int[][] mat = new int[][]{{1}};
            confronta("[T12]", 2, Eserc1.controlloUguaglianza(mat, simboli));
        }

    }
}