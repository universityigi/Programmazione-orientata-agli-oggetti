import java.util.*;

public class Esercizio4{
	public static <T1,T2> List<String> sommaListe(List<T1> l1, List<T2> l2){
		List<String> risultato = new ArrayList<String>();
		
		int max = l1.size();
		if (l2.size() > l1.size()) {
			max = l2.size();
		}
		
		for (int i = 0; i < max; i++){
			String nuova;
			if (i < l1.size() && i < l2.size()) {
				nuova = l1.get(i).toString() + l2.get(i).toString();
			}
			else{
				if (i < l1.size()){
					nuova = l1.get(i).toString();
				}
				else{
					nuova = l2.get(i).toString();
				}
			}
			risultato.add(nuova);
		}
		return risultato;
	}
	
	public static <E> Collection<E> eliminaDuplicati(Collection<E> c){
		Set<E> risultato = new HashSet<E>();
		risultato.addAll(c);
		return risultato;
	}	
}

