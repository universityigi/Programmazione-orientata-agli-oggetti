public class ProvaEsercizio3 extends TemplateProvaEserc{
	
	public static void main(String[] args){
		PozzoSenzaFondo p1 = new PozzoSenzaFondo();
		
        confronta("T1", false, p1.contiene(new Integer(0)));
	
		p1.aggiungi(new Integer(0));
        confronta("T2", true, p1.contiene(new Integer(0)));
        confronta("T3", false, p1.contiene(new Integer(2)));
		
        confronta("T4", true, p1.ultimo().equals(new Integer(0)));

		p1.aggiungi(new Integer(1));
        confronta("T5", true, p1.ultimo().equals(new Integer(1)));

		p1.aggiungi(new Integer(2));
		
		PozzoSenzaFondo p2 = new PozzoSenzaFondo();
		p2.aggiungi(new Integer(5));
		p2.aggiungi(new Integer(6));
		p2.aggiungi(new Integer(5));
        confronta("T6", true, p1.equals(p2));
        confronta("T7", true, p1.hashCode() == p2.hashCode());

		p2.aggiungi(new Integer(5));
        confronta("T8", false, p1.equals(p2));
		
		p1.aggiungi(new Integer(5));
		p1.aggiungi(new Integer(5));
		p1.aggiungi(new Integer(5));
		p1.aggiungi(new Integer(5));
        confronta("T9", false, p2.equals(p1));
		
		PozzoSenzaFondo p3 = (PozzoSenzaFondo) p2.clone();
		
        confronta("T10", true, p3.equals(p2));

		boolean ok = p3.contiene(new Integer(5)) && p3.contiene(new Integer(6));
        confronta("T11", true, ok);
		
        confronta("T12", true, p3 != p2);
		
	}	
}
