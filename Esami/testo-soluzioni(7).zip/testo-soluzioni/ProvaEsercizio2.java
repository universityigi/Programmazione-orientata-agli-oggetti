public class ProvaEsercizio2 extends TemplateProvaEserc{
	
	public static void main(String[] args){
        checkRicorsione("[Ammissibilita\' soluzione]", "Esercizio2.java");
		int[] v1 = {};
        confronta("T1", true, Esercizio2.palindromo(v1));

		int[] v2 = {1};
        confronta("T2", true, Esercizio2.palindromo(v2));
	
		int[] v3 = {1,1};
        confronta("T3", true, Esercizio2.palindromo(v3));
	
		int[] v4 = {1,2,1};
        confronta("T4", true, Esercizio2.palindromo(v4));
				
		int[] v5 = {1,2,2,1};
        confronta("T5", true, Esercizio2.palindromo(v5));
		
		int[] v6 = {1,2};
        confronta("T6", false, Esercizio2.palindromo(v6));
		
		int[] v7 = {1,2,2};
        confronta("T7", false, Esercizio2.palindromo(v7));
		
		int[] v8 = {2,2,1};
        confronta("T8", false, Esercizio2.palindromo(v8));
		
		int[] v9 = {2,2,1,2,1};
        confronta("T9", false, Esercizio2.palindromo(v9));
		
		int[] v10 = {1,2,1,2,2};
        confronta("T10", false, Esercizio2.palindromo(v10));
		
		int[][] m1 = {};
        confronta("T11", true, Esercizio2.palindroma(m1));
		
		int[][] m2 = {{1}};
        confronta("T12", true, Esercizio2.palindroma(m2));
		
		int[][] m3 = {{1,2}};
        confronta("T13", false, Esercizio2.palindroma(m3));

		int[][] m4 = {{1,2,1},{1,3,1},{1,1,1}};
        confronta("T14", true, Esercizio2.palindroma(m4));
	
		int[][] m5 = {{1,2,1},{1,3,1},{1,1,2}};
        confronta("T15", false, Esercizio2.palindroma(m5));	
	}	
}
