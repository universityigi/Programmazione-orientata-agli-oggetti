import java.util.*;

public class ProvaEsercizio4 extends TemplateProvaEserc{
	
	public static void main(String[] args){
		List<Integer> l1 = new LinkedList<Integer>();
		
		l1.add(new Integer(0));
		l1.add(new Integer(1));
		l1.add(new Integer(2));
		l1.add(new Integer(3));
		l1.add(new Integer(4));
		
		List<String> l2 = new LinkedList<String>();
		
		l2.add("a");
		l2.add("b");
		l2.add("c");
		l2.add("d");
		l2.add("e");
		
		List<String> l3 = new LinkedList<String>();

		l3.add("0a");
		l3.add("1b");
		l3.add("2c");
		l3.add("3d");
		l3.add("4e");
		
		List<String> l = new LinkedList<String>(Esercizio4.sommaListe(l1,l2));
        confronta("T1", true, l.equals(l3));
		
		l1.add(new Integer(9));
		l = new LinkedList<String>(Esercizio4.sommaListe(l1,l2));
        confronta("T2", false, l3.equals(l));
		
		l3.add("9");
		l = new LinkedList<String>(Esercizio4.sommaListe(l1,l2));
        confronta("T3", true, l3.equals(l));

		l2.add("d");
		l2.add("e");
		l3.set(5,"9d");
		l3.add("e");
		l = new LinkedList<String>(Esercizio4.sommaListe(l1,l2));
        confronta("T4", true, l3.equals(l));
		
		List<String> l4 = new LinkedList<String>();
		l = new LinkedList<String>(Esercizio4.sommaListe(l2,l4));
        confronta("T5", true, l2.equals(l));

		l = new LinkedList<String>(Esercizio4.sommaListe(l4,l2));
        confronta("T6", true, l2.equals(l));
		
		l = new LinkedList<String>(Esercizio4.sommaListe(l4,l4));
        confronta("T7", true, l4.equals(l));
		
		Collection<String> c = Esercizio4.eliminaDuplicati(l2);
        confronta("T8", 2, l2.size() - c.size());
		
		boolean ok = c.contains("a") && c.contains("b") && c.contains("c") && c.contains("d") && c.contains("e");
        confronta("T9", true, ok);
		
		c = Esercizio4.eliminaDuplicati(c);
		ok = c.contains("a") && c.contains("b") && c.contains("c") && c.contains("d") && c.contains("e");
        confronta("T10", true, ok);
		
	}
}





