public class Esercizio2{
	public static boolean palindromo(int[] v){
		return palindromo(v,0,v.length-1);
	}
	
	private static boolean palindromo(int[] v, int i, int f){
		if (f-i < 1){
			return true;
		}
		if (v[i] != v[f]){
			return false;
		}
		return palindromo(v,i+1,f-1);
	}
	
	public static boolean palindroma(int[][] m){
		return palindroma(m,0);
	}
	
	private static boolean palindroma(int[][] m, int i){
		if (m.length <= i) {
			return true;
		}
		return (palindromo(m[i]) && palindroma(m,++i));
	}
}


