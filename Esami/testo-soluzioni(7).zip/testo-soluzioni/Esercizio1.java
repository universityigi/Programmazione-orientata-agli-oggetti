public class Esercizio1{
	public static char[][] affiancaMatrici(char[][] m1, char[][] m2){
		int r, c;
		
		if (m1.length > m2.length){
			r = m1.length;
		}
		else{
			r = m2.length;
		}
		
		int c1=0, c2=0;
		
		if (m1.length > 0) {
			c1 = m1[0].length;
		}
		if (m2.length > 0) {
			c2 = m2[0].length;
		}
		
		c = c1 + c2;
		
		char[][] risultato = new char[r][c];

		for (int i = 0; i < r ; i++) {
			for (int j = 0; j < c; j++) {
				risultato[i][j] = '.';
				if (i < m1.length && j < c1) {
					risultato[i][j] = m1[i][j];
				}
				if (i < m2.length && j >= c1){
					risultato[i][j] = m2[i][j - c1];
				}
			}
		}

		return risultato;
	}
}