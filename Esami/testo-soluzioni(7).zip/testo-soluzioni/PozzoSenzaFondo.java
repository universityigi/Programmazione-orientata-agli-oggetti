class NodoLista{
	Object info;
	NodoLista next;
	
	public NodoLista(Object i, NodoLista n){
		info = i;
		next = n;
	}
}


public class PozzoSenzaFondo implements Cloneable{
	private NodoLista init;
	
	public PozzoSenzaFondo(){
		init = null;
	}
	
	public void aggiungi(Object o){
		// inserimento in testa
		init = new NodoLista(o,init);
	}
	
	public Object ultimo(){
		Object risultato = null;
		if (init != null){
			risultato = init.info;
		}
		return risultato;
	}
	
	public boolean contiene(Object o){
		NodoLista aux = init;
		while (aux != null) {
			if (aux.info.equals(o)){
				return true;
			}
			aux = aux.next;
		}
		return false;
	}
	
	public boolean equals(Object o){
		if ( o==null || !getClass().equals(o.getClass())){
			return false;
		}
		PozzoSenzaFondo p = (PozzoSenzaFondo) o;
		
		return quantiElementi() == p.quantiElementi();
	}
	
	public Object clone(){
		PozzoSenzaFondo risultato = null;
		try {
			risultato = (PozzoSenzaFondo) super.clone();
		}
		catch (CloneNotSupportedException e) {
			throw new InternalError(e.toString());
		}
		
		NodoLista generatore = new NodoLista(null,init);
		NodoLista aux = generatore;
		while(aux.next != null){
			aux.next = new NodoLista(aux.next.info,aux.next.next);
			aux = aux.next;
		}
		risultato.init = generatore.next;
		return risultato;
	}
	
	private int quantiElementi(){
		int risultato = 0;
		NodoLista aux = init;
		
		while (aux != null) {
			risultato++;
			aux = aux.next;
		}
		return risultato;
	}
	
	public int hashCode(){
		return quantiElementi();
	}
}


