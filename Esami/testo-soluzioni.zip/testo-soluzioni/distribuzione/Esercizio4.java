import java.util.*;

public class Esercizio4{
	
	public static String creaStringa(List<Character> lista){
		/* Da completare */
	}
	
	public static List<Character> creaLista(String s){
		/* Da completare */
	}
}
