import java.io.*;
import java.util.*;

public class ProvaEsercizio4 extends TemplateProvaEserc {
    public static void main(String[] args) throws IOException {
		int tnum = 0;
		
		List<Character> l1 = new LinkedList();
		l1.add('b');l1.add('u');l1.add('o');l1.add('n');
		l1.add('g');l1.add('i');l1.add('o');l1.add('r');l1.add('n');l1.add('o');
		
		String s = "buongiorno";
		
		String s1 = Esercizio4.creaStringa(l1);
		
		confronta("[T" + tnum++ +"]", s, s1); 

		l1 = new LinkedList();
		confronta("[T" + tnum++ +"]", "", Esercizio4.creaStringa(l1)); 
		
		l1 = Esercizio4.creaLista(s);
		s1 = estraiStringa(l1);
		
		confronta("[T" + tnum++ +"]", s, s1); 
		
		l1 = Esercizio4.creaLista("");
		s = estraiStringa(l1);
		confronta("[T" + tnum++ +"]", "", Esercizio4.creaStringa(l1)); 		
    }
	
	private static String estraiStringa(List<Character> l){
		String s = "";
		Iterator<Character> it = l.iterator();
		while (it.hasNext()){
			s += it.next().toString();
		}
		return s;
	}
}
