import java.io.*;
public class ProvaEsercizio1 extends TemplateProvaEserc {
    public static void main(String[] args) throws IOException {
		int tnum = 0;
		String n1 = "I Municipio";
		String i1 = "Via del Corso, 1";
		Biblioteca b1 = new Biblioteca(n1, i1, 2,1);
		
		String l1 = "Il nome della rosa";
		confronta("[T" + tnum++ +"]", 0, b1.quanteCopieLibro(l1)); 
		
		boolean r = b1.aggiungiLibro(l1);
		confronta("[T" + tnum++ +"]", r, true); 
		confronta("[T" + tnum++ +"]", 1, b1.quanteCopieLibro(l1)); 
	
		r = b1.aggiungiLibro(l1);
		confronta("[T" + tnum++ +"]", r, true); 
		confronta("[T" + tnum++ +"]", 2, b1.quanteCopieLibro(l1)); 
		
		r = b1.aggiungiLibro(l1);
		confronta("[T" + tnum++ +"]", r, false); 
		confronta("[T" + tnum++ +"]", 2, b1.quanteCopieLibro(l1)); 

		r = b1.rimuoviLibro(l1);
		confronta("[T" + tnum++ +"]", r, true); 
		confronta("[T" + tnum++ +"]", 1, b1.quanteCopieLibro(l1)); 
		
		String l2 = "Il giocatore";
		confronta("[T" + tnum++ +"]", 0, b1.quanteCopieLibro(l2)); 
		
		r = b1.aggiungiLibro(l2);
		confronta("[T" + tnum++ +"]", r, true); 
		confronta("[T" + tnum++ +"]", 1, b1.quanteCopieLibro(l1)); 
		confronta("[T" + tnum++ +"]", 1, b1.quanteCopieLibro(l2)); 
		confronta("[T" + tnum++ +"]", false, b1.aggiungiLibro("")); 
		
    }
}
