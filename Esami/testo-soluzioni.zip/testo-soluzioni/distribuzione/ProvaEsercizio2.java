import java.io.*;
import locali.*;

public class ProvaEsercizio2 extends TemplateProvaEserc {
    public static void main(String[] args) throws IOException {
		int tnum = 0;
		
		int piano =1;
		int nfinestre = 2;
		int nporte = 1;
		int capienza = 10;
		
		Locale l1 = new Ufficio(piano, nfinestre,nporte,capienza);
		confronta("[T" + tnum++ +"]", false, l1.sicuro()); 
		
		Locale l2 = new Ufficio(piano, nfinestre,nporte+1,capienza);
		confronta("[T" + tnum++ +"]", true, l2.sicuro()); 
		
		Locale l3 = new Ufficio(0, nfinestre,nporte,capienza);
		confronta("[T" + tnum++ +"]", true, l3.sicuro()); 

		Locale l4 = new SalaRiunioni(0, nfinestre, nporte, capienza);
		confronta("[T" + tnum++ +"]", false, l4.sicuro());
		
		Locale l5 = new SalaRiunioni(0, nfinestre, nporte+2, capienza);
		confronta("[T" + tnum++ +"]", true, l5.sicuro());
    }
}
