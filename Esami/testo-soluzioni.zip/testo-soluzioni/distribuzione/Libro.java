public class Libro{
	private String titolo;
	
	public Libro(String titolo){
		this.titolo = titolo;
	}
	
	public String getTitolo(){
		return titolo;
	}
}