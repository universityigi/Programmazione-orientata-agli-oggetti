import java.io.*;
import java.util.*;

public class ProvaEsercizio3 extends TemplateProvaEserc {
    public static void main(String[] args) throws IOException {
		int tnum = 0;
		
		MultiInsieme m = new MultiInsieme();
		confronta("[T" + tnum++ +"]", false, m.presente(1)); 		
		m.inserisci(1);
		confronta("[T" + tnum++ +"]", true, m.presente(1)); 		
		confronta("[T" + tnum++ +"]", 1.0, m.percentuale(1)); 		
		m.inserisci(1);
		confronta("[T" + tnum++ +"]", 1.0, m.percentuale(1)); 		
		m.inserisci(2);
		confronta("[T" + tnum++ +"]", 2.0/3.0, m.percentuale(1));
		m.elimina(1);
		confronta("[T" + tnum++ +"]", true, m.presente(1));
		confronta("[T" + tnum++ +"]", true, m.presente(2));
		confronta("[T" + tnum++ +"]", 0.5, m.percentuale(1));
		confronta("[T" + tnum++ +"]", 0.5, m.percentuale(2));
		m.elimina(1);
		confronta("[T" + tnum++ +"]", false, m.presente(1));
		confronta("[T" + tnum++ +"]", true, m.presente(2));
		m.elimina(3);
		confronta("[T" + tnum++ +"]", true, m.presente(2));
		confronta("[T" + tnum++ +"]", 1.0, m.percentuale(2));
		m.elimina(2);
		confronta("[T" + tnum++ +"]", false, m.presente(2));
    }
	
}
