import java.util.*;

class Nodo{
	protected int info;
	protected Nodo next;
}


public class MultiInsieme{
	/* Da Completare */
}



