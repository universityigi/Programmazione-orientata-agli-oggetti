import java.util.*;


public class Biblioteca {
	private String nome;
	private String indirizzo;
	private  Scaffale[] scaffali;
	
	public String getNome(){		
		return nome;
	}

	public String getIndirizzo(){		
		return indirizzo;
	}
	
	
	public Biblioteca(String nome, String indirizzo, int nscaffali, int posizioni){
		this.nome = nome;
		this.indirizzo = indirizzo;
		this.scaffali = new Scaffale[nscaffali];
		
		for(int i = 0; i< scaffali.length; i++){
			scaffali[i] = new Scaffale(posizioni);
		}
		
	}
	
	public boolean aggiungiLibro(String titolo){
		for (int i = 0; i < scaffali.length; i++){
			if (scaffali[i].aggiungiLibro(titolo)){
				return true;
			}
		}
		return false;
	}
	
	public boolean rimuoviLibro(String titolo){
		for (int i = 0; i < scaffali.length; i++){
			if (scaffali[i].rimuoviLibro(titolo)){
				return true;
			}
		}
		return false;
	}	
	
	public int quanteCopieLibro(String titolo){
		int quanti=0;
		for (int i = 0; i < scaffali.length; i++){
			quanti += scaffali[i].quanteCopieLibro(titolo);
		}
		return quanti;			
	}
	
}