public class Scaffale{
	private Libro[] posizioni;
	
	public Scaffale(int nposizioni){
		this.posizioni = new Libro[nposizioni];
	}
	
	public boolean aggiungiLibro(String titolo){
		for (int i = 0; i < posizioni.length; i++){
			if (posizioni[i] == null){
				posizioni[i] = new Libro(titolo);
				return true;
			}
		}
		return false;
	}

	public boolean rimuoviLibro(String titolo){
		for (int i = 0; i < posizioni.length; i++){
			if (posizioni[i] != null && posizioni[i].getTitolo().equals(titolo)){
				posizioni[i] = null;
				return true;
			}
		}		
		return false;
	}
	
	public int quanteCopieLibro(String titolo){
		int quanti = 0;
		for (int i = 0; i < posizioni.length; i++){
			if (posizioni[i] != null && posizioni[i].getTitolo().equals(titolo)){
				quanti++;
			}
		}
		return quanti;
	}
}
