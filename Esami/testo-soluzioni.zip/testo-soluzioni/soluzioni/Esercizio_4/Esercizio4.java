import java.util.*;

public class Esercizio4{
	
	public static String creaStringa(List<Character> lista){
		if (lista.isEmpty()){
			return "";
		}
		return lista.get(0).toString() + creaStringa(lista.subList(1,lista.size()));
	}
	
	public static List<Character> creaLista(String s){
		if (s.equals("")){
			return new LinkedList<Character>();
		}
		LinkedList<Character> risultato = new LinkedList();
		risultato.add(s.charAt(0));
		risultato.addAll(creaLista(s.substring(1)));
		return risultato;
	}
}
