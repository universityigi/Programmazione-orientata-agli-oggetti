import java.util.*;

class Nodo{
	protected int info;
	protected Nodo next;
}


public class MultiInsieme{
	private Nodo init;
	
	public MultiInsieme(){
		init = null;
	}
	
	public void inserisci(int i){
		Nodo nuovo = new Nodo();
		nuovo.info = i;
		nuovo.next = init;
		init = nuovo;
	}
	
	public void elimina(int i){
		if (init==null){
			return;
		}		
		if (init.info == i){
			init = init.next;
			return;
		}
		Nodo cur = init;
		while (cur.next != null && cur.next.info != i){
			cur = cur.next;
		}
		if(cur.next != null){
			cur.next = cur.next.next;
		}
	}
	
	public boolean presente(int i){
		Nodo cur = init;
		while(cur != null){
			if (cur.info == i){
				return true;
			}
			cur = cur.next;
		}
		return false;
	}
	
	public double percentuale(int i){
		int occorrenze = 0;
		int totale = 0;
		Nodo cur = init;
		while(cur != null){
			if (cur.info == i){
				occorrenze++;
			}
			totale++;
			cur = cur.next;
		}
		return occorrenze/(double)totale;
	}
	
}



