package locali;

public class SalaRiunioni extends Locale{
	public SalaRiunioni(int piano, int nfinestre, int nporte, int capienza){
		super(piano, nfinestre, nporte, capienza);
	}		
	
	public boolean sicuro(){
		return (capienza/nfinestre <= 10 && capienza/nporte <= 5);
	}
	
}