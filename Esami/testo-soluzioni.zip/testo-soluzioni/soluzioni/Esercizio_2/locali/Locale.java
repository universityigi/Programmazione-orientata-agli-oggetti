package locali;
import java.util.*;


public abstract class Locale {
	protected int piano;
	protected int nfinestre;
	protected int nporte;
	protected int capienza;
	
	public Locale(int piano, int nfinestre, int nporte, int capienza){
		this.piano = piano;
		this.nfinestre = nfinestre;
		this.nporte = nporte;
		this.capienza = capienza;
	}
	
	public abstract boolean sicuro();
}

