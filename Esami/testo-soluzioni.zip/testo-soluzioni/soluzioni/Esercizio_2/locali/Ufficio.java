package locali;

public class Ufficio extends Locale{
	public Ufficio(int piano, int nfinestre, int nporte, int capienza){
		super(piano, nfinestre, nporte, capienza);
	}		
	
	public boolean sicuro(){
		return 
			(piano == 0 && (capienza/(nfinestre + nporte) <= 10)) || (capienza / nporte <= 8)	;
	}
}
