import java.io.*;
public class ProvaEsercizio3 extends TemplateProvaEserc {

    public static void main(String[] args) throws IOException {
	// prova parte ricorsiva
	ElementoElenco [] elementi= new ElementoElenco[5];
	elementi[elementi.length-1] = new ElementoElenco("A",null);
	for (int i =elementi.length-2; i>=0; i--){
	    elementi[i] =new ElementoElenco(""+i, elementi[i+1]);
	}
	
	int tn=1;

	// prova size
	for (int i=0; i<elementi.length; i++){
	    String testName = "T" + tn;
	    tn++;
	    confronta (testName, elementi.length - i, UtilitaElenco.sizeRicorsiva(elementi[i]));
	}

	// prova at
	for (int i=0; i<elementi.length; i++){
	    String testName = "T" + tn;
	    tn++;
	    if (UtilitaElenco.atRicorsivo(elementi[0], i)!=null){
		confronta (testName, elementi[i].info, UtilitaElenco.atRicorsivo(elementi[0], i).info);
	    } else {
		confronta (testName, elementi[i].info, null);
	    }
	}

	// prova elenco ordinato

	ElencoOrdinato s1=new ElencoOrdinato();
	confronta ("T"+ tn++, 0, s1.size());
	s1.inserisci("pippo");
	confronta ("T"+ tn++, 1, s1.size());
	s1.inserisci("pluto");
	confronta ("T"+ tn++, 2, s1.size());
	s1.inserisci("motozappa");
	confronta ("T"+ tn++, 0, s1.at(2).compareTo("pluto"));
	boolean bo = s1.inserisci("motozappa");
	confronta("T"+ tn++, false, bo);
	confronta("T"+ tn++, 3, s1.size());
	bo = s1.elimina("pippo");
	confronta("T"+ tn++, true, bo);
	confronta("T"+ tn++, 2, s1.size());
	s1.inserisci("nardi");
	s1.inserisci("iocchi");
	s1.inserisci("patrizi");
	confronta("T"+ tn++, 5, s1.size());
	String a[] = s1.toArray();
	confronta("T"+ tn++, 5, a.length);
	for (int i = 0; i< a.length; i++){
	    String testName = "T" + tn;
	    tn++;
	    confronta(testName, a[i], s1.at(i));
	}
	for (int i = 0; i< a.length-1; i++){
	    String testName = "T" + tn;
	    tn++;
	    confronta(testName, true, a[i].compareTo(a[i+1])<=0);
	}

	
    }
}
