import java.util.*;

public class Geometria {
	public static double calcolaSuperficieTotale(Set<FiguraPiana> composizione){
		double superficie = 0;
		Iterator it = composizione.iterator();
		while (it.hasNext()){
			FiguraPiana fp = (FiguraPiana) it.next(); 
			superficie += fp.superficie();
		}
		return superficie;
	}
}

