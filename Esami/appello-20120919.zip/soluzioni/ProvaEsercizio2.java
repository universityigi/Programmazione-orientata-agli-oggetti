import java.io.*;
public class ProvaEsercizio2 extends TemplateProvaEserc {
      
    public static void main(String[] args) throws IOException {
        int[][] m = MatriceSparsa.leggiMatriceSparsa("Matrice1.txt");
        confronta("[T1]", 0, m[0][0]);
        confronta("[T2]", 2, m[4][4]);
        confronta("[T3]", 1, MatriceSparsa.colonnaMaxNonNulli(m));
		
        m = MatriceSparsa.leggiMatriceSparsa("Matrice2.txt");
        confronta("[T4]", 5, m[0][0]);
        confronta("[T5]", 0, m[0][1]);
        confronta("[T6]", 4, m[2][1]);
        confronta("[T7]", 1, MatriceSparsa.colonnaMaxNonNulli(m));

		m = MatriceSparsa.leggiMatriceSparsa("Matrice3.txt");
        confronta("[T8]", 0, m[0][0]);
        confronta("[T9]", 2, m[3][2]);
        confronta("[T10]", 2, MatriceSparsa.colonnaMaxNonNulli(m));
	}
}
