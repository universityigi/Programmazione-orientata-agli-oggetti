public class ElencoOrdinato {
    public ElencoOrdinato() {
	init=null;
    }

    public int size() {
	 return UtilitaElenco.sizeRicorsiva(init);
    }


    public String at( int i ) {
	ElementoElenco e = UtilitaElenco.atRicorsivo(init, i);
	if (e==null)
	    return null;
	return e.info;
    }


    String [] toArray() {
	if (init == null)
	    return null;
	String [] arr = new String[size()];
	ElementoElenco e=init;
	int i=0;
	while (e!=null){
	    arr[i]=e.info;
	    i++;
	    e=e.next;
	}
	return arr;
    }

    boolean inserisci(String s){
	ElementoElenco e=new ElementoElenco(null, init);
	ElementoElenco newInit = e;
	while (e.next != null && s.compareTo(e.next.info)>0 ){
	    e=e.next;
	}
	if (e.next !=null && s.compareTo(e.next.info) == 0)
	    return false;
	if (e.next == null) {
	    e.next=new ElementoElenco(s);
	} else {
	    e.next = new ElementoElenco(s,e.next);
	}
	init = newInit.next;
	return true;
    }

    boolean elimina(String s){
	ElementoElenco e=new ElementoElenco(null, init);
	ElementoElenco newInit = e;
	while (e.next != null && s.compareTo(e.next.info)>0 ){
	    e=e.next;
	}
	if (e.next !=null && s.compareTo(e.next.info) == 0){
	    e.next = e.next.next;
	    init = newInit.next;
	    return true;
	}
	return false;
    }
    
    protected ElementoElenco init;
}