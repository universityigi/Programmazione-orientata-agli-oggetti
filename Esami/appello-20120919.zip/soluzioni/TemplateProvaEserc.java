import java.io.*;
import java.util.*;
import java.util.regex.*;

/**
 * template dei metodi di confronto
 */
public class TemplateProvaEserc {
    public static <T> List<T> asList(T... a) {
        return Arrays.asList(a);
    }

    public static void checkRicorsione(String msg, String filename) {
        //controlla che il file specificato non contenga cicli
        String match = "for[\\n\\r ]*\\(|while[\\n\\r ]*\\(|replace[\\n\\r ]*\\(|replaceAll[\\n\\r ]*\\(";
        if (filename == null)
            return;
        Pattern compile = Pattern.compile(match);

        StringBuffer fileData = new StringBuffer();
        String line;
        try {
            BufferedReader in = new BufferedReader(new FileReader(filename));
            while ((line = in.readLine()) != null) {
                fileData.append(line);
                fileData.append("\n");
            }
            in.close();
            Matcher matcher = compile.matcher(fileData);
            if (matcher.find()) {
                System.out.println("===============================================");
                System.out.printf("(*) TEST %s (verifica ricorsione)" +
                        "\n  > Sono presenti cicli iterativi in un metodo ricorsivo" +
                        "\n  >%s%n",
                        msg.toUpperCase(), " ############## [ERR] ##############");
            } else {
                System.out.println("===============================================");
                System.out.printf("(*) TEST %s (verifica ricorsione)" +
                        "\n  > Il metodo ricorsivo non presenta cicli%n" +
                        "  >%s%n",
                        msg.toUpperCase(), "[OK]");
            }
        } catch (Exception e) {
            System.out.println("===============================================");
            System.out.printf("(*) TEST %s (verifica ricorsione)" +
                    "\n  > Errore di lettura del file %s: %s" +
                    "\n  > Test non effettuato" +
                    "\n  >%s%n",
                    msg.toUpperCase(), filename, e.getMessage(), " ############## [SKIP] ##############");
        }
    }

    public static void confronta(String msg, int atteso, int valore) {
        System.out.println("===============================================");
        System.out.printf("(*) TEST %s" +
                "\n  > Valore calcolato:%d" +
                "\n  > Valore atteso   :%d" +
                "\n  >%s%n",
                msg.toUpperCase(), valore, atteso, valore == atteso ? " [OK]" : " ############## [ERR] ##############");
    }

    public static void confronta(String msg, boolean atteso, boolean valore) {
        System.out.println("===============================================");
        System.out.printf("(*) TEST %s" +
                "\n  > Valore calcolato:%s" +
                "\n  > Valore atteso   :%s" +
                "\n  >%s%n",
                msg.toUpperCase(), valore, atteso, valore == atteso ? " [OK]" : " ############## [ERR] ##############");
    }

    public static void confronta(String msg, double atteso, double valore) {
        System.out.println("===============================================");
        System.out.printf("(*) TEST %s" +
                "\n  > Valore calcolato:%s" +
                "\n  > Valore atteso   :%s" +
                "\n  >%s%n",
                msg.toUpperCase(), valore, atteso, valore == atteso ? " [OK]" : " ############## [ERR] ##############");
    }

    private static double round(double d, int cifre) {
        double pow = Math.pow(10, cifre);
        return (long) (d * pow) / pow;
    }

    public static void confronta(String msg, double atteso, double valore, int numCifre) {
        atteso = round(atteso, numCifre);
        valore = round(valore, numCifre);

        System.out.println("===============================================");
        System.out.printf("(*) TEST %s" +
                "\n  > Valore calcolato:%s" +
                "\n  > Valore atteso   :%s" +
                "\n  >%s%n",
                msg.toUpperCase(), valore, atteso, valore == atteso ? " [OK]" : " ############## [ERR] ##############");
    }

    public static void confronta(String msg, String atteso, String valore) {
        System.out.println("===============================================");
        System.out.printf("(*) TEST %s" +
                "\n  > Valore calcolato:%s" +
                "\n  > Valore atteso   :%s" +
                "\n  >%s%n",
                msg.toUpperCase(), valore, atteso,
                _safeEq(atteso, valore) ? " [OK]" : " ############## [ERR] ##############");
    }

    private static <T> boolean _safeEq(T t1, T t2) {
        if (t1 != null && t2 == null) return false;
        if (t1 == null && t2 != null) return false;
        if (t1 == null) return true;
        return t1.equals(t2);
    }

    public static void confronta(String msg, String[] atteso, String[] valore) {
        confronta(msg, Arrays.toString(atteso), Arrays.toString(valore));
    }

    public static <T> void confronta(String msg, List<T> atteso, List<T> valore) {
        confronta(msg, "" + atteso, "" + valore);
    }

    public static <T> void confronta(String msg, T[] atteso, List<T> valore) {
        confronta(msg, Arrays.asList(atteso), valore);
    }

    public static <T> void confronta(String msg, List<T> atteso, T[] valore) {
        confronta(msg, atteso, Arrays.asList(valore));
    }

    public static void confronta(String msg, int[] atteso, int[] valore) {
        confronta(msg, Arrays.toString(atteso), Arrays.toString(valore));
    }

    public static void confronta(String msg, char[] atteso, char[] valore) {
        confronta(msg, Arrays.toString(atteso), Arrays.toString(valore));
    }

    public static void confronta(String msg, double[] atteso, double[] valore) {
        confronta(msg, Arrays.toString(atteso), Arrays.toString(valore));
    }

    public static void confronta(String msg, int[][] atteso, int[][] valore) {
        confronta(msg, _toString(atteso), _toString(valore));
    }

    private static String _toString(int[][] A) {
        String r = "{";
        for (int[] aA : A) {
            r += Arrays.toString(aA);
            r += " ";
        }
        r += "}";
        return r;
    }

    private static void init() {
        System.out.println("Init eseguito");
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                System.out.flush();
                System.err.flush();
                System.err.println("===============================================");
                e.printStackTrace();
                System.err.println("-----------------------------------------------");
                System.err.println(
                        "E' stata generata una eccezione inattesa.\nIl test del programma e' stato interrotto.");
                System.err.println("===============================================");
                System.err.flush();
            }
        });
    }

    public static void verificaClasse(String msg, String className) {
        try {
            Class.forName(className);
            success(msg, "Classe " + className + " presente e posizionata nel package corretto");
        } catch (ClassNotFoundException e) {
            fail(msg, "Classe " + className + " non presente o posizionata nel package sbagliato");
        }
    }

    public static void success(String msg, String messaggio) {
        System.out.println("===============================================");
        System.out.printf("(*) TEST %s" +
                "\n  > %s" +
                "\n  > ESITO TEST:%s%n",
                msg.toUpperCase(), messaggio, "OK");
    }

    public static void fail(String msg, String messaggio) {
        System.out.println("===============================================");
        System.out.printf("(*) TEST %s" +
                "\n  > %s" +
                "\n  > ESITO TEST:%s%n",
                msg.toUpperCase(), messaggio, "############## [ERR] ##############");
    }

    static {
        init();
    }
}
