import java.io.*;
public class ProvaEsercizio1 extends TemplateProvaEserc {
    public static void main(String[] args) throws IOException {
	        
	
                
	String n1 = "La fucina della coltura";
	String i1 = "via le mani dal naso 8";

	String t1 = "Tutto sulle biciclette pieghevoli";
	String t2 = "Manuale di ansetsesia";
	String t3 = "Fondamenti 1, come ho passato l'esame";
	String t4 = "Volo, ma non sono Fabio";
	String t5 = "100 motivi per non bere la notte prima degli esami";
	String t6 = "100 motivi per bere la notte dopo degli esami";

	String a1 = "Fabio Patrizi";
	String a2 = "John Bighammer";
	String a3 = "Daniele Nardi";
	String a4 = "Giuseppe Santucci";
	String a5 = "Giorgio Grisetti";

	int tnum = 0;
	Biblioteca b = new Biblioteca(n1, i1);
	confronta("[T" + tnum++ +"]", b.getNome(), "La fucina della coltura"); 
	confronta("[T" + tnum++ +"]", b.getIndirizzo(), "via le mani dal naso 8"); 

	b.addLibro(t1, a1);
	Libro l = b.getLibro(t1, a1);
	confronta("[T" + tnum++ +"]", a1, l.getAutore()); 

	b.addLibro(t1, a1);
	l = b.getLibro(t1, a1);
	confronta("[T" + tnum++ +"]", 2, l.getNumeroCopie()); 

	b.addLibro(t2, a2);
	b.addLibro(t3, a3);
	b.addLibro(t4, a4);
	l = b.getLibro(t3, a3);
	confronta("[T" + tnum++ +"]", 1, l.getNumeroCopie()); 

	b.removeLibro(t3, a3);
	l = b.getLibro(t3, a3);
	confronta("[T" + tnum++ +"]", true, l==null); 

	confronta("[T" + tnum++ +"]", b.getNumeroLibri(), 4); 

	b.addLibro(t5, a5);
	b.addLibro(t6, a5);

	confronta("[T" + tnum++ +"]", b.contaTitoliAutore(a5), 2); 

	System.out.println("ok up to here");
	Libro [] laut=b.libriAutore(a5);
	confronta("[T" + tnum++ +"]", laut.length, 2); 
	confronta("[T" + tnum++ +"]", (laut[0].getTitolo().equals(t5) && laut[1].getTitolo().equals(t6)) || (laut[0].getTitolo().equals(t6) && laut[1].getTitolo().equals(t5)), true); 
    }
}
