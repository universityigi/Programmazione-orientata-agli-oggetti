import java.util.*;

public class Rettangolo extends FiguraPiana {
	private double base, altezza;
	
	public Rettangolo(double base, double altezza){
		this.base = base;
		this.altezza = altezza;
	}
	
	public double superficie(){
		return base * altezza;
	};
}

