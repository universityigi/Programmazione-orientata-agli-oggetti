import java.io.*;

public class MatriceSparsa {
	public  static int [][] leggiMatriceSparsa(String nomeFile)throws IOException{
		FileInputStream f = new FileInputStream (nomeFile);
		InputStreamReader is = new InputStreamReader(f);
        BufferedReader in = new BufferedReader(is);
		
		int righe=Integer.parseInt(in.readLine());
		if(righe==0) 
			return null;
		
		int colonne=Integer.parseInt(in.readLine());
		if(colonne==0) 
			return null;
		
		int[][] mat=new int[righe][colonne];         
		for(int i=0; i<righe; i++){
			for(int j=0; j <colonne; j++){
				mat[i][j]=0;
			}
		}
		
		String s = in.readLine();
        while (s != null){
			int i = Integer.parseInt(s);
			int j = Integer.parseInt(in.readLine());
			int v = Integer.parseInt(in.readLine());			
			mat[i][j]=v;
			s = in.readLine();
		}

		in.close();
		is.close();
		f.close();
		return mat;
    } 

    public static int colonnaMaxNonNulli(int [][] mat) {
		int colonna = 0;
		int nonNulli = 0;
		for(int j=0; j<mat[0].length; j++){
			int curNonNulli = 0;
			for(int i=0; i<mat.length; i++){
				if(mat[i][j] != 0){
					curNonNulli++;
				}
			}
			if(curNonNulli > nonNulli){
				nonNulli = curNonNulli;
				colonna = j;
			}
		}
		return colonna;
	}
}
