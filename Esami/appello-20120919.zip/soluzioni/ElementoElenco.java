public class ElementoElenco{
    public ElementoElenco(String info, ElementoElenco next){
        this.info = info;
        this.next = next;
    }
    public ElementoElenco(String info){
        this(info,null);
    }
    public String info;  // valore del carattere
    public ElementoElenco next; // prossimo elemento nella lista
}
