import java.util.*;

public class Biblioteca {
    public Biblioteca (String nome, String indirizzo) {
	this.nome = nome;
	this.indirizzo = indirizzo;
	libri = new HashSet<Libro>();
    }
    
    public String getNome() {
	return nome;
    }

    public String getIndirizzo() {
	return indirizzo;
    }

    public Libro getLibro(String titolo, String autore) {
	Iterator<Libro> it=libri.iterator();
	while (it.hasNext()){
	    Libro l = it.next();
	    if (l.getTitolo().equals(titolo) &&
		l.getAutore().equals(autore))
		return l;
	}
	return null;
    }

    public int getNumeroLibri() {
	int num = 0;
	Iterator<Libro> it=libri.iterator();
	while (it.hasNext()){
	    Libro l = it.next();
	    num += l.getNumeroCopie();
	}
	return num;
    }

    public void addLibro(String titolo, String autore){
	Libro old = getLibro(titolo, autore);
	if (old == null)
	    libri.add(new Libro(titolo, autore, 1));
	else
	    old.setNumeroCopie( old.getNumeroCopie() + 1);
    }
    
    public boolean removeLibro(String titolo, String autore){
	Libro old = getLibro(titolo, autore);
	if (old == null) {
	    return false;
	} else {
	    old.setNumeroCopie( old.getNumeroCopie() - 1);
	}

	if (old.getNumeroCopie()==0) 
	    libri.remove(old);
	return true;
    }

    
    public int contaTitoliAutore(String autore){
	int num = 0;
	Iterator<Libro> it=libri.iterator();
	while (it.hasNext()){
	    Libro l = it.next();
	    if (l.getAutore().equals(autore))
		num ++;
	}
	return num;
    }

    public Libro[] libriAutore(String autore){
	Libro [] laut = new Libro [contaTitoliAutore(autore)];
	int num = 0;
	Iterator<Libro> it=libri.iterator();
	while (it.hasNext()){
	    Libro l = it.next();
	    if (l.getAutore().equals(autore)) {
		laut[num] = l;
		num ++;
	    }
	}
	return laut;

    }
    
    protected HashSet<Libro> libri;
    protected String nome;
    protected String indirizzo;
}