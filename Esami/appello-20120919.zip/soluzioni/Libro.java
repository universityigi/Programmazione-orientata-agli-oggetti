public class Libro {
    
    private String titolo;
    private String autore;
    private int numeroCopie;

    public Libro(String titolo, String autore, int numeroCopie){
            this.titolo=titolo;
            this.autore=autore;
            this.numeroCopie=numeroCopie; // rappresenta il numero di copie del libro disponibili in biblioteca al momento
    }         
    public String getTitolo(){ 
            return titolo;
    }
    public String getAutore(){
            return autore;
    }                 
    public int getNumeroCopie(){
           return numeroCopie;
    }                 
    public void setNumeroCopie(int numeroCopie){
           this.numeroCopie = numeroCopie;
    }                 

}
