import java.util.*;

public abstract class FiguraPiana {
	public abstract double superficie();	
}

