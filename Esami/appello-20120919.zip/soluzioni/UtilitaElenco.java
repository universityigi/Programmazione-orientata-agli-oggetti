public class UtilitaElenco {
    public static ElementoElenco atRicorsivo(ElementoElenco e, int i) {
	if (e==null)
	    return null;
	if (i==0)
	    return e;
	return atRicorsivo(e.next, i-1);
    }

    public static int sizeRicorsiva(ElementoElenco e) {
	if (e==null)
	    return 0;
	return 1 + sizeRicorsiva(e.next);
    }
}