import java.io.*;
import java.util.*;

public class ProvaEsercizio4  extends TemplateProvaEserc{
	
	public static void main(String[] args)  throws IOException {
		Set<FiguraPiana> composizione = new HashSet<FiguraPiana>();
		confronta("[T1]", 0, Geometria.calcolaSuperficieTotale(composizione));
		
		composizione.add(new Rettangolo(3,3));
		confronta("[T2]", 9, Geometria.calcolaSuperficieTotale(composizione));
		
		composizione.add(new Circonferenza(5/Math.sqrt(Math.PI)));
		confronta("[T3]", 34, Geometria.calcolaSuperficieTotale(composizione));
		
	}
}
