import java.util.*;

public class Circonferenza extends FiguraPiana {
	private double raggio;
	
	public Circonferenza(double raggio){
		this.raggio = raggio;
	}
	
	public double superficie(){
		return Math.PI * Math.pow(raggio,2);
	};
}

