@SuppressWarnings({"unchecked"})
public class ProvaEserc1 extends TemplateProvaEserc {
    public static void main(String[] args) {
        //=========================================================================================
        {
            try {
                confronta("[T1]", 15, Eserc1.sommaIntervallo(new int[]{1, 2, 3, 4, 5}, 1, 5));
            } catch (InvalidRangeException e) {
                fail("[T1]", "Exception non corretta");
            }
        }
        //=========================================================================================
        {
            try {
                confronta("[T2]", 0, Eserc1.sommaIntervallo(new int[]{1, 2, 3, 4, 5}, 10, 15));
            } catch (InvalidRangeException e) {
                fail("[T2]", "Exception non corretta");
            }
        }
        //=========================================================================================
        {
            try {
                confronta("[T3]", 0, Eserc1.sommaIntervallo(new int[]{}, 1, 5));
            } catch (InvalidRangeException e) {
                fail("[T3]", "Exception non corretta");
            }
        }
        //=========================================================================================
        {
            try {
                confronta("[T4]", 3, Eserc1.sommaIntervallo(new int[]{1, 2, 10, 12}, 1, 5));
            } catch (InvalidRangeException e) {
                fail("[T4]", "Exception non corretta");
            }
        }
        //=========================================================================================
        {
            try {
                confronta("[T5]", -1, Eserc1.sommaIntervallo(new int[]{1, 2, 3, 4, 5, 20, 30, -1}, -11, -1));
            } catch (InvalidRangeException e) {
                fail("[T5]", "Exception non corretta");
            }
        }
        //=========================================================================================
        {
            try {
                int valore = Eserc1.sommaIntervallo(new int[]{1, 2, 3, 4, 5}, 5, 1);
                fail("[T6]", "Exception non rilanciata");
            } catch (InvalidRangeException e) {
                confronta("[T6]", "intervallo non valido", e.getMessage());
            }
        }
        //=========================================================================================
        {
            try {
                int valore = Eserc1.sommaIntervallo(new int[]{1, 2, 3, 4, 5}, 52, 6);
                fail("[T7]", "Exception non rilanciata");
            } catch (InvalidRangeException e) {
                confronta("[T7]", "intervallo non valido", e.getMessage());
            }
        }
        //=========================================================================================
        {
            try {
                int valore = Eserc1.sommaIntervallo(new int[]{}, 5, 1);
                fail("[T8]", "Exception non rilanciata");
            } catch (InvalidRangeException e) {
                confronta("[T8]", "intervallo non valido", e.getMessage());
            }
        }
        //=========================================================================================
        {
            try {
                int valore = Eserc1.sommaIntervallo(new int[]{}, -5, -171);
                fail("[T9]", "Exception non rilanciata");
            } catch (InvalidRangeException e) {
                confronta("[T9]", "intervallo non valido", e.getMessage());
            }
        }
        //=========================================================================================
        {
            try {
                confronta("[T10]", 20, Eserc1.sommaIntervallo(new int[]{10, 10}, 10, 10));
            } catch (InvalidRangeException e) {
                fail("[T10]", "Exception non corretta");
            }
        }
        //=========================================================================================
        {
            try {
                confronta("[T11]", 23, Eserc1.sommaIntervallo(new int[]{1, 2, 10, 10}, 1, 10));
            } catch (InvalidRangeException e) {
                fail("[T11]", "Exception non corretta");
            }
        }

        //=========================================================================================
        {
            try {
                confronta("[T12]", 0, Eserc1.sommaIntervallo(new int[]{10, 10, 10, 10}, 11, 100));
            } catch (InvalidRangeException e) {
                fail("[T12]", "Exception non corretta");
            }
        }

        //=========================================================================================
        {
            try {
                confronta("[T13]", 3, Eserc1.sommaIntervallo(
                        new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0},
                        -11, 1));
            } catch (InvalidRangeException e) {
                fail("[T13]", "Exception non corretta");
            }
        }

        //=========================================================================================
        {
            try {
                confronta("[T14]", 135, Eserc1.sommaIntervallo(
                        new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0},
                        -11, 90));
            } catch (InvalidRangeException e) {
                fail("[T14]", "Exception non corretta");
            }
        }

        //=========================================================================================
        {
            checkRicorsione("[T12]", "Eserc1.java");
        }
    }
}
