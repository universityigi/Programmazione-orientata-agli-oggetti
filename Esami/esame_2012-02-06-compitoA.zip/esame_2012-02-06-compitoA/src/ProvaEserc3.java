import java.io.*;

@SuppressWarnings({"unchecked"})
public class ProvaEserc3 extends TemplateProvaEserc {
    public static void main(String[] args) throws IOException {
        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInCoda(1, 1, 5);
            lp.aggiungiInCoda(2, 2, 6);
            lp.aggiungiInCoda(3, 3, 7);
            lp.aggiungiInCoda(4, 4, 8);
            confronta("[T1]", 4, lp.lunghezza());
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInCoda(1, 1, 5);
            lp.aggiungiInCoda(2, 2, 6);
            lp.aggiungiInCoda(3, 3, 7);
            lp.aggiungiInCoda(4, 4, 8);
            Double best = lp.altezzaMassima();
            confronta("[T2]", "" + 8.0, "" + best);
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            confronta("[T3]", "" + null, "" + lp.altezzaMassima());
        }
        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInCoda(1, 1, 5);
            lp.aggiungiInCoda(2, 2, 6);
            lp.aggiungiInCoda(3, 3, 7);
            lp.aggiungiInCoda(4, 4, 8);
            confronta("[T4]", "<1.0;1.0;5.0><2.0;2.0;6.0><3.0;3.0;7.0><4.0;4.0;8.0>", toString(lp.init));
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(2, 2, 6);
            lp.aggiungiInTesta(3, 3, 7);
            lp.aggiungiInTesta(4, 4, 8);
            confronta("[T5]", "<4.0;4.0;8.0><3.0;3.0;7.0><2.0;2.0;6.0><1.0;1.0;5.0>", toString(lp.init));
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.svuotaLista();
            confronta("[T6]", "", toString(lp.init));
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(2, 2, 6);
            lp.aggiungiInTesta(3, 3, 7);
            lp.aggiungiInTesta(4, 4, 8);
            lp.aggiungiInCoda(4, 4, 8);
            lp.aggiungiInCoda(4, 4, 8);
            lp.aggiungiInCoda(4, 4, 8);
            lp.aggiungiInCoda(4, 4, 8);
            lp.aggiungiInCoda(4, 4, 8);
            lp.svuotaLista();
            confronta("[T7]", "", toString(lp.init));
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInCoda(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInCoda(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInCoda(1, 1, 5);
            lp.aggiungiInCoda(1, 1, 5);
            confronta("[T8]",
                    "<1.0;1.0;5.0><1.0;1.0;5.0><1.0;1.0;5.0><1.0;1.0;5.0><1.0;1.0;5.0><1.0;1.0;5.0><1.0;1.0;5.0><1.0;1.0;5.0>",
                    toString(lp.init));
        }
        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            confronta("[T9]",
                    "<1.0;1.0;5.0><1.0;1.0;5.0><1.0;1.0;5.0><1.0;1.0;5.0><1.0;1.0;5.0><1.0;1.0;5.0><1.0;1.0;5.0><1.0;1.0;5.0><1.0;1.0;5.0><1.0;1.0;5.0><2.0;2.0;10.0><2.0;2.0;10.0><2.0;2.0;10.0><2.0;2.0;10.0><2.0;2.0;10.0><2.0;2.0;10.0><2.0;2.0;10.0><2.0;2.0;10.0><2.0;2.0;10.0><2.0;2.0;10.0><2.0;2.0;10.0>",
                    toString(lp.init));
        }
        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInTesta(1, 1, 5);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            lp.aggiungiInCoda(2, 2, 10);
            confronta("[T10]",
                    21,
                    lp.lunghezza());
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            confronta("[T11]", 0, lp.lunghezza());
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            for (int i = 0; i < 10; i++) {
                lp.aggiungiInCoda(2, 2, 10);
                lp.aggiungiInTesta(5, 8, 10);
                lp.aggiungiInCoda(3, 3, 10);
            }
            confronta("[T12]", 30, lp.lunghezza());
        }

        //=========================================================================================
        {
            ListaPunti lp = new ListaPunti();
            for (int i = 0; i < 5; i++) {
                lp.aggiungiInCoda(2, 2, 10);
                lp.aggiungiInTesta(5, 8, 10);
                lp.aggiungiInCoda(3, 3, 10);
            }
            confronta("[T13]", "<5.0;8.0;10.0><5.0;8.0;10.0><5.0;8.0;10.0><5.0;8.0;10.0><5.0;8.0;10.0><2.0;2.0;10.0><3.0;3.0;10.0><2.0;2.0;10.0><3.0;3.0;10.0><2.0;2.0;10.0><3.0;3.0;10.0><2.0;2.0;10.0><3.0;3.0;10.0><2.0;2.0;10.0><3.0;3.0;10.0>", toString(lp.init));
        }
    }

    private static String toString(NodoPunto p) {
        if (p == null) return "";
        return "<" + p.longitudine + ";" + p.latitudine + ";" + p.altezza + ">" + toString(p.next);
    }
}
