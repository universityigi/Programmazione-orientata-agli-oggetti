import login.*;
import login.impl.*;

import java.io.*;

@SuppressWarnings({"unchecked"})
public class ProvaEserc4 extends TemplateProvaEserc {

        private static final String ACCOUNT_TXT = "account.txt";
    private static final String ACCOUNT_VUOTO_TXT = "account-vuoto.txt";
    private static final String ACCOUNT_INESISTENTE_TXT = "account-xxx.txt";

    public static void main(String[] args) throws IOException {
        //=========================================================================================
        {
            verificaClasse("[T1]", "login.impl.Utility");
        }

        //=========================================================================================
        {
            verificaClasse("[T2]", "login.impl.PersistentLogin");
        }

        //=========================================================================================
        {
            verificaClasse("[T3]", "login.impl.InMemoryLogin");
        }

        //=========================================================================================
        {
            verificaClasse("[T5]", "login.Login");
        }

        //=========================================================================================
        {
            verificaClasse("[T6]", "login.Account");
        }

        //=========================================================================================
        {
            InMemoryLogin l = new InMemoryLogin();
            confronta("[T7]", "null", "" + l.login("pippo", ""));
        }

        //=========================================================================================
        {
            InMemoryLogin l = new InMemoryLogin();
            l.add("admin", "pass", "admin@email.it");
            confronta("[T8]", "admin;pass;admin@email.it", "" + l.login("admin", "pass"));
        }

        //=========================================================================================
        {
            InMemoryLogin l = new InMemoryLogin();
            l.add("admin", "pass", "admin@email.it");
            l.add("admin2", "pass2", "admin2@email.it");
            l.add("admin3", "pass3", "admin3@email.it");
            l.add("admin3", "pass4", "admin4@email.it");
            confronta("[T9]", "admin3;pass4;admin4@email.it", "" + l.login("admin3", "pass4"));
        }

        //=========================================================================================
        {
            InMemoryLogin l = new InMemoryLogin();
            l.add("admin", "pass", "admin@email.it");
            l.add("admin2", "pass2", "admin2@email.it");
            l.add("admin3", "pass3", "admin3@email.it");
            l.add("admin3", "pass4", "admin4@email.it");
            confronta("[T10]", "null", "" + l.login("admin3", "pass5"));
        }

        //=========================================================================================
        {
            InMemoryLogin l = new InMemoryLogin();
            confronta("[T11]", "null", "" + l.login("admin3", "pass5"));
        }

        //=========================================================================================
        {
            PersistentLogin l = new PersistentLogin(new File(ACCOUNT_TXT));
            confronta("[T12]", "null", "" + l.login("admin3", "pass5"));
        }

        //=========================================================================================
        {
            PersistentLogin l = new PersistentLogin(new File(ACCOUNT_TXT));
            //valeria;vale;valeria@email.com
            confronta("[T13]", "valeria;vale;valeria@email.com", "" + l.login("valeria", "vale"));
        }

        //=========================================================================================
        {
            PersistentLogin l = new PersistentLogin(new File(ACCOUNT_TXT));
            //valeria;vale;valeria@email.com
            confronta("[T14]", "null", "" + l.login("account", "pass"));
        }

        //=========================================================================================
        {
            PersistentLogin l = new PersistentLogin(new File(ACCOUNT_INESISTENTE_TXT));
            //valeria;vale;valeria@email.com
            confronta("[T15]", "null", "" + l.login("account", "pass"));
        }

        //=========================================================================================
        {
            PersistentLogin l = new PersistentLogin(new File(ACCOUNT_VUOTO_TXT));
            //valeria;vale;valeria@email.com
            confronta("[T16]", "null", "" + l.login("account", "pass"));
        }

        //=========================================================================================
        {
            InMemoryLogin l1 = new InMemoryLogin();
            l1.add("admin", "pass", "admin@email.it");
            l1.add("admin2", "pass2", "admin2@email.it");
            l1.add("admin3", "pass3", "admin3@email.it");
            l1.add("admin3", "pass4", "admin4@email.it");

            InMemoryLogin l2 = new InMemoryLogin();
            l2.add("pippo", "paperino", "pippo-paperino@email.com");

            PersistentLogin l3 = new PersistentLogin(new File(ACCOUNT_TXT));

            confronta("[T17]", true, Utility.login("admin", "adminadmin",
                    new Login[]{l3, l2, l1}) == l3);
        }

        //=========================================================================================
        {
            InMemoryLogin l1 = new InMemoryLogin();
            l1.add("admin", "pass", "admin@email.it");
            l1.add("admin2", "pass2", "admin2@email.it");
            l1.add("admin3", "pass3", "admin3@email.it");
            l1.add("admin3", "pass4", "admin4@email.it");

            InMemoryLogin l2 = new InMemoryLogin();
            l2.add("pippo", "paperino", "pippo-paperino@email.com");

            PersistentLogin l3 = new PersistentLogin(new File(ACCOUNT_TXT));

            confronta("[T18]", true, Utility.login("adminx", "adminadmin",
                    new Login[]{l3, l2, l1}) == null);
        }

        //=========================================================================================
        {
            InMemoryLogin l1 = new InMemoryLogin();
            l1.add("admin", "pass", "admin@email.it");
            l1.add("admin2", "pass2", "admin2@email.it");
            l1.add("admin3", "pass3", "admin3@email.it");
            l1.add("admin3", "pass4", "admin4@email.it");

            InMemoryLogin l2 = new InMemoryLogin();
            l2.add("pippo", "paperino", "pippo-paperino@email.com");

            PersistentLogin l3 = new PersistentLogin(new File(ACCOUNT_TXT));

            confronta("[T19]", true, Utility.login("admin2", "pass2",
                    new Login[]{l3, l2, l1}) == l1);
        }

        //=========================================================================================
        {
            InMemoryLogin l1 = new InMemoryLogin();
            l1.add("admin", "pass", "admin@email.it");
            l1.add("admin2", "pass2", "admin2@email.it");
            l1.add("admin3", "pass3", "admin3@email.it");
            l1.add("admin3", "pass4", "admin4@email.it");

            InMemoryLogin l2 = new InMemoryLogin();
            l2.add("pippo", "paperino", "pippo-paperino@email.com");

            PersistentLogin l3 = new PersistentLogin(new File(ACCOUNT_TXT));

            confronta("[T20]", true, Utility.login("pippo", "paperino",
                    new Login[]{l3, l2, l1}) == l2);
        }

    }

}
