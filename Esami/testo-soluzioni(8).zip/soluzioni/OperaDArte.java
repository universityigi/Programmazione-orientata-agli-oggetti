/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Silvia
 */
public abstract class OperaDArte {
    
    protected String titolo;
    protected String artista;
    
    
    public OperaDArte(){
        titolo=null;
        artista=null;
    }
    
    public OperaDArte(String t, String a){
        titolo=t;
        artista=a;
    }
    
    public abstract double calcolaOccupazione();
    
    public boolean equals(Object o){
        if(o!= null && o instanceof OperaDArte){
            OperaDArte op =(OperaDArte) o;
            if(this.titolo.equals(op.titolo) && this.artista.equals(op.artista)){
                return true;
            }
        }
        return false;
    }
    
}
