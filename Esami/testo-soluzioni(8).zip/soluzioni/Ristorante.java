/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.*;
import java.io.*;
import java.lang.*;
/**
 *
 * @author Silvia
 */
public class Ristorante {
    
    public List <Tavolo> tavoli;
    //public List <Ordine> cucina;
    
    public Ristorante(){
        tavoli= new ArrayList ();
        //cucina= new ArrayList();
        
    }
    
    public boolean tavoloDispobile(int coperti){
        ListIterator lit=this.tavoli.listIterator(this.tavoli.size()-1);
        boolean trovato=false;
        
        while(lit.hasPrevious() && !trovato){
            Tavolo current=(Tavolo)lit.previous();
            if(current.nCoperti>= coperti && !current.prenotato){
                current.prenotato=true;
                trovato=true;
                
                
            }
        }
        return trovato;
        
    }
    
    public void ordinazione(int tavolo, Ordine o) throws Exception{
        ListIterator lit=this.tavoli.listIterator();
        boolean trovato=false;
        while(lit.hasNext() && !trovato){
            Tavolo current=(Tavolo)lit.next();
            if(current.idTavolo==tavolo){
                current.ordine=o;
                trovato=true;
            }
        }
        if(!trovato){
            throw new Exception("Identificativo del Tavolo non esistente");
        }
    }
    
    
    
    public double calcolaConto(int id)throws Exception{
        double conto=0.0;
        ListIterator lit=this.tavoli.listIterator();
        boolean trovato=false;
        Tavolo current=null;
        while(lit.hasNext() && !trovato){
            current=(Tavolo)lit.next();
            if(current.idTavolo==id){
                trovato=true;
            }
        }
        if(trovato){
            if (current.ordine!=null && current.ordine.getBevande().size()>0){
                ListIterator litB=current.ordine.getBevande().listIterator();
                while(litB.hasNext()){
                    MenuItem item=(MenuItem)litB.next();
                    conto=conto+item.getPrezzo();
                }
            }
            if(current.ordine!=null && current.ordine.getPiatti().size()>0){
                ListIterator litP=current.ordine.getPiatti().listIterator();
                while(litP.hasNext()){
                    MenuItem item=(MenuItem)litP.next();
                    conto=conto+item.getPrezzo();
                }
            }
        }
        else{
            throw new Exception("Identificativo del Tavolo non esistente");
        }
        return conto;
    }
    
    
    
}
