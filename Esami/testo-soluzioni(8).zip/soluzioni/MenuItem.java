/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Silvia
 */
public class MenuItem {
    
    private String nome;
    private String tipo;
    private double prezzo;
    
    public MenuItem(String n, String t, double p){
        this.nome=n;
        this.tipo=t;
        this.prezzo=p;
    }
    
    public void setNome(String n){
        this.nome=n;
    }
    
    public String getNome(){
        return this.nome;
    }
    
    public void setTipo(String t){
        this.tipo=t;
    }
    
    public String getTipo(){
        return this.tipo;
    }
    
    public void setPrezzo(double p){
        this.prezzo=p;
    }
    
    public double getPrezzo(){
        return this.prezzo;
    }
    
    public String toString(){
        return tipo+": "+nome+" euro "+prezzo;
    }
    
}
