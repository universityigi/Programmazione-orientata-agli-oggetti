/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.*;

/**
 *
 * @author Silvia
 */
public class Ordine {
    
    private List <MenuItem> bevande;
    private List <MenuItem> piatto;
    
    
    public Ordine (){
        this.bevande=new ArrayList();
        this.piatto=new ArrayList();
    }
    
    public List<MenuItem> getBevande(){
        return this.bevande;
    }
    
    public List<MenuItem> getPiatti(){
        return this.piatto;
    }
    
    public void aggiungiItem(MenuItem it){
        if(it.getTipo().equals("bevanda")){
            this.bevande.add(it);
            return;
        }
        if(it.getTipo().equals("piatto")){
            this.piatto.add(it);
            return;
        }
        else{
            System.out.println("Item non Riconosciuto");
        }
    }
    
    
    
    public void rimuoviItem(MenuItem it){
        if(it.getTipo().equals("bevanda")){
            this.bevande.remove(it);
            return;
        }
        if(it.getTipo().equals("piatto")){
            this.piatto.remove(it);
            return;
        }
        else{
            System.out.println("Item non Riconosciuto");
        }
        
    }
    
    
    
    
}
