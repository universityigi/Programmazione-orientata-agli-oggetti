
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author Silvia
 */
public class ProvaEsercizio1 extends TemplateProvaEserc{
    
    public static void main (String[] args){
        
       
        
        
        
        String [][] matrix6= {
            {"aaaa", "aa", "a"},
            {"b", "bbb", "b"}
        };
        
        String [][] matrix7= {
            {"9"},
            {"0"},
            {"33"}
        };
        
        String [][] matrix8= {
            {"a", "cc", "bb"},
            {"bb", "cc", "a"}
        };
        
        String [][] matrix9= {};
        
       
        
        int res6=Esercizio1.colonnaConMinorNumeroCaratteri(matrix6);
        int res7=Esercizio1.colonnaConMinorNumeroCaratteri(matrix7);
        int res8=Esercizio1.colonnaConMinorNumeroCaratteri(matrix8);
        int res9=Esercizio1.colonnaConMinorNumeroCaratteri(matrix9);
        
        
        int testCounter =1;
        
        
        
        confronta("T"+testCounter, 2, res6);
        testCounter++;
        confronta("T"+testCounter, 0, res7);
        testCounter++;
        confronta("T"+testCounter, 2, res8);
        testCounter++;
        confronta("T"+testCounter, -1, res9);
        testCounter++;
        
        
    }
    
}
