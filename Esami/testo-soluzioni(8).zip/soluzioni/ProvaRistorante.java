/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.*;
import java.util.*;

/**
 *
 * @author Silvia
 */
public class ProvaRistorante extends TemplateProvaEserc{
    
    public static List <Tavolo> leggiTavoliDaFile (String nomeFile) throws IOException{
       FileReader f=new FileReader(nomeFile);
       BufferedReader br=new BufferedReader(f);
       List <Tavolo> lista=new ArrayList();
       String numero=br.readLine();
       String coperti=br.readLine();
       while(numero!=null){
            int num=Integer.parseInt(numero);
            int ncoperti=Integer.parseInt(coperti);
            Tavolo t =new Tavolo(num, ncoperti);
            lista.add(t);
            numero=br.readLine();
            coperti=br.readLine();
       }
       br.close();
       f.close();
       return lista;
   }
     
   public static Ordine leggiOrdineDaFile(String nomeFile) throws IOException{
       FileReader f=new FileReader(nomeFile);
       BufferedReader br=new BufferedReader(f);
       Ordine res=new Ordine();
       String linea=br.readLine();
       String tipo=linea;
       String nome= br.readLine();
       String prezzo=br.readLine();
       String qt=br.readLine();
       while(linea!=null && nome!=null && prezzo!=null && qt!=null){
           MenuItem item=new MenuItem(nome, tipo, Double.parseDouble(prezzo));
           //System.out.println(item.toString());
           for(int i=0; i<Integer.parseInt(qt); i++){
                res.aggiungiItem(item);
                //System.out.println(item.toString());
           }
            linea=br.readLine();
            if(linea==null) break;
            if(linea.equals("piatto") || linea.equals("bevanda")){
                tipo=linea;
                nome= br.readLine();
                prezzo=br.readLine();
                qt=br.readLine();
            }
            else{
                nome= linea;
                prezzo=br.readLine();
                qt=br.readLine();
            }
            
           
       }
       br.close();
       f.close();
       return res;
   }
    
    public static void main (String[] args) throws IOException, Exception{
        int testCounter =1;
        Ristorante r1=new Ristorante();
        r1.tavoli=ProvaRistorante.leggiTavoliDaFile("tavoli.txt");
        confronta("T"+testCounter, true, r1.tavoloDispobile(10));
        testCounter++;
        confronta("T"+testCounter, false, r1.tavoloDispobile(20));
        testCounter++;
        Ordine o=ProvaRistorante.leggiOrdineDaFile("ordine1.txt");
        try{
            r1.ordinazione(25, o);
        }
        catch(Exception e){
            String errore=e.getMessage();
            confronta("T"+testCounter, "Identificativo del Tavolo non esistente", errore);
            testCounter++;
            //System.out.println(errore);
        }
        r1.ordinazione(1, o);
        confronta("T"+testCounter, 49.0, r1.calcolaConto(1));
        testCounter++;
        confronta("T"+testCounter, 0.0, r1.calcolaConto(2));
        testCounter++;
        try{
            double conto=r1.calcolaConto(25);
        }
        catch(Exception e){
            String errore=e.getMessage();
            confronta("T"+testCounter, "Identificativo del Tavolo non esistente", errore);
            testCounter++;
            //System.out.println(errore);
        }
        
        
    }
    
}
