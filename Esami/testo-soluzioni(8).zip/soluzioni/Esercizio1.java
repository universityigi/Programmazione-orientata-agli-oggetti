/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Silvia
 */
public class Esercizio1 {
    
    
    
    public static int colonnaConMinorNumeroCaratteri(String [][] matrix){
        int min=Integer.MAX_VALUE;
        int minI=-1;
        if(matrix.length>0){
            int[] temp=new int[matrix[0].length];
            for(int j=0; j<matrix[0].length; j++){
                int somma=0;
                for(int i=0; i<matrix.length; i++){
                    somma=somma+matrix[i][j].length();
                }
                temp[j]=somma;
            }
            for(int k=0; k<temp.length; k++){
                if(temp[k]<=min){
                    min=temp[k];
                    minI=k;
                }
            }
        }
        
        return minI;
    }
    
    
}
