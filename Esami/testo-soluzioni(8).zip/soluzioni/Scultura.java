/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Silvia
 */
public class Scultura extends OperaDArte{
    
    public double altezza;
    public double larghezza;
    public double profondita;
    
    public Scultura(){
        super();
        altezza=0.0;
        larghezza=0.0;
        profondita=0.0;
    }
    
    public Scultura(String t, String a, double al, double l, double p){
        super(t, a);
        altezza=al;
        larghezza=l;
        profondita=p;
    }
    
    public double calcolaOccupazione(){
        return altezza*larghezza*profondita;
    }
    
    public boolean equals(Object o){
        if(super.equals(o)){
            if(o instanceof Scultura){
                Scultura q=(Scultura)o;
                if(this.altezza==q.altezza && this.larghezza==q.larghezza && this.profondita== q.profondita){
                    return true;
                }
            }
        }
        return false;
    }
    
}
