/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Silvia
 */
public class ProvaEsercizio2 extends TemplateProvaEserc{
    
    public static void main (String[] args){
        checkRicorsione("[Ammissibilita\' soluzione]", "Esercizio2.java");
        int testCounter=1;
        String [] lista = {"ciao", "ciccia", "ccc", "c"};
        String [] atteso = {"kiao", "kikkia", "kkk", "k"};
        Esercizio2.cambiaCarattere(lista, 'c', 'k');
        String parola="ciao";
        confronta("T"+testCounter, "miao", Esercizio2.rimpiazzaCarattere(parola, 'c', 'm'));
        testCounter++;
        parola="sasso";
        confronta("T"+testCounter, "sassi", Esercizio2.rimpiazzaCarattere(parola, 'o', 'i'));
        testCounter++;
        parola="AAA";
        confronta("T"+testCounter, "aaa", Esercizio2.rimpiazzaCarattere(parola, 'A', 'a'));
        testCounter++;
        parola="B";
        confronta("T"+testCounter, "C", Esercizio2.rimpiazzaCarattere(parola, 'B', 'C'));
        testCounter++;
        parola="";
        confronta("T"+testCounter, "", Esercizio2.rimpiazzaCarattere(parola, 'o', 'i'));
        testCounter++;
        String [] lista1 = {"ciao", "ciccia", "ccc", "c"};
        String [] atteso1 = {"ciao", "ciccia", "ccc", "c"};
        Esercizio2.cambiaCarattere(lista, 's', 'k');
        confronta("T"+testCounter, atteso1, lista1);
        testCounter++;
        String [] lista2 = {"ciao"};
        String [] atteso2 = {"cIao"};
        Esercizio2.cambiaCarattere(lista2, 'i', 'I');
        confronta("T"+testCounter, atteso2, lista2);
        testCounter++;
        String [] lista3 = {};
        String [] atteso3 = {};
        Esercizio2.cambiaCarattere(lista3, 'i', 'I');
        confronta("T"+testCounter, atteso3, lista3);
        testCounter++;
    }
    
}
