/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.*;
/**
 *
 * @author Silvia
 */
public class ProvaCollezione extends TemplateProvaEserc{
    
    public static void main (String[] args) {
        int testCounter =1;
        Quadro q1=new Quadro("Autoritratto", "Picasso", 80, 60);
        Quadro q2= new Quadro("Notte Stellata", "Van Gogh", 73, 92);
        Quadro q3=new Quadro("Autoritratto", "Picasso", 80, 60);
        Scultura s1= new Scultura("Il David", "Michelangelo", 415, 50, 50);
        Scultura s2= new Scultura ("Mose'", "Michelangelo", 235, 100, 100);
        Scultura s3= new Scultura("Il David", "Michelangelo", 415, 50, 50);
        Scultura s4= new Scultura("Notte Stellata", "Van Gogh", 410, 50, 60);
        OperaDArte o1=q2;
        OperaDArte o2=s4;
        confronta("T"+testCounter, 4800.0, q1.calcolaOccupazione());
        testCounter++;
        confronta("T"+testCounter, false, q1.equals(q2));
        testCounter++;
        confronta("T"+testCounter, true, q1.equals(q3));
        testCounter++;
        confronta("T"+testCounter, 1037500.0, s1.calcolaOccupazione());
        testCounter++;
        confronta("T"+testCounter, false, s1.equals(s2));
        testCounter++;
        confronta("T"+testCounter, true, s1.equals(s3));
        testCounter++;
        confronta("T"+testCounter, false, o1.equals(o2));
        testCounter++;
        confronta("T"+testCounter, false, o1.equals(q3));
        testCounter++;
        confronta("T"+testCounter, false, o2.equals(o1));
        testCounter++;
        confronta("T"+testCounter, false, q2.equals(s4));
        testCounter++;
        confronta("T"+testCounter, Scultura.class.toString(), s1.getClass().toString());
    }
    
}
