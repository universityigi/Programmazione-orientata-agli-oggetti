/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Silvia
 */
public class Quadro extends OperaDArte{
    
    public double altezza;
    public double larghezza;
    
    public Quadro(){
        super();
        altezza=0.0;
        larghezza=0.0;
    }
    
    public Quadro(String t, String ar, double l, double al){
        super(t, ar);
        altezza=al;
        larghezza=l;
    }
    
    
    
    public double calcolaOccupazione(){
        return altezza*larghezza;
    }
    
    public boolean equals(Object o){
        if(super.equals(o)){
            if(o instanceof Quadro){
                Quadro q=(Quadro)o;
                if(this.altezza==q.altezza && this.larghezza==q.larghezza){
                    return true;
                }
            }
        }
        return false;
    }
}
