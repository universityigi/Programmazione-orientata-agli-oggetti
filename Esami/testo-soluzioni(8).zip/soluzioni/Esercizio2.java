/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Silvia
 */
public class Esercizio2 {
    
    public static void cambiaCarattere(String [] lista, char vecchio, char nuovo){
        if(lista.length>0){
            cambiaCarattereinLista(lista, vecchio, nuovo, 0);
        }
    }
    
    public static String rimpiazzaCarattere(String parola, char vecchio, char nuovo){
        if(parola!=null && parola.length()>0){
            return cambiaCarattereInParola(parola, vecchio, nuovo, parola.length()-1);
        }
        if(parola.length()==0){
            return "";
        }
        return null;
    }
    
    private static String cambiaCarattereInParola(String parola, char vecchio, char nuovo, int pos){
        if(parola.charAt(pos)==vecchio){
            String prefix=parola.substring(0, pos);
            //System.out.println(prefix);
            String suffix=parola.substring(pos+1);
            //System.out.println(suffix);
            parola=prefix+nuovo+suffix;
            //System.out.println(parola);
        }
        if(pos==0){
            return parola;
        }
        else{
            return cambiaCarattereInParola(parola, vecchio, nuovo, pos-1);
        }
    }
    
    private static String[] cambiaCarattereinLista(String [] lista, char vecchio, char nuovo, int pos){
        lista[pos]=cambiaCarattereInParola(lista[pos], vecchio, nuovo, lista[pos].length()-1);
        if(pos==lista.length-1){
            return lista;
        }
        else{
            return cambiaCarattereinLista(lista, vecchio, nuovo, pos+1);
        }
        
    }
    
}
