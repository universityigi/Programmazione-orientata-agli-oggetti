/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.*;

/**
 *
 * @author Silvia
 */
public class Tavolo {
    
    public int idTavolo;
    public int nCoperti;
    public boolean prenotato;
    public Ordine ordine;

    
    
    public Tavolo(int id, int n){
        this.idTavolo=id;
        this.nCoperti=n;
        this.prenotato=false;
        this.ordine=null;
    }
    
    public Tavolo(){
        this.idTavolo=-1;
        this.nCoperti=0;
        this.prenotato=false;
        this.ordine=null;
    }
    
    
    
    
}
